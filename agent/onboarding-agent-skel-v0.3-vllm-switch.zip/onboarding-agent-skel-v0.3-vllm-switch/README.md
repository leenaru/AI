# Onboarding Agent – vLLM Switchable Server (v0.3)

This version introduces a **runtime-switchable LLM backend**:
- `LLM_BACKEND=ollama` → use local Ollama API (dev/edge)
- `LLM_BACKEND=vllm`   → use vLLM (OpenAI-compatible, prod)

Also includes: HQ‑RAG (in-memory or Qdrant), Appliance flows, Tickets, Graph GUI samples (in `../gui` from previous bundle).

## Quickstart (Docker)
```bash
cd server
cp .env.example .env

# 1) vLLM mode
# Edit .env: LLM_BACKEND=vllm, VLLM_MODEL=mistralai/Mistral-7B-Instruct-v0.3
docker compose up -d
# Pull a dev model for Ollama if you also want dev mode:
# docker exec -it ollama ollama pull llama3:instruct
# API: http://localhost:8080

# Test
curl -s http://localhost:8080/healthz
```

## Switch backends
- In `.env`: set `LLM_BACKEND=ollama` or `vllm`
- For vLLM, the server serves a **single model** (`VLLM_MODEL`), and the router returns that name.

## Chat example
```bash
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "text": "에어컨이 E5 에러가 떠요",
  "lang": "ko-KR",
  "product": {"brand":"Acme","model":"AC-1234"},
  "policy_context": {"country":"KR"}
}'
```

