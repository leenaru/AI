from typing import List, Dict, Optional
from datetime import datetime
import itertools

_id = itertools.count(1)

class InMemoryDocStore:
    def __init__(self):
        self.docs: List[Dict] = []

    def add(self, title: str, url: Optional[str], content: str, date: Optional[str] = None,
            tags: Optional[List[str]] = None, products: Optional[List[str]] = None) -> Dict:
        doc = {
            "id": str(next(_id)),
            "title": title,
            "url": url,
            "content": content,
            "date": date or datetime.now().date().isoformat(),
            "tags": tags or [],
            "products": products or []
        }
        self.docs.append(doc)
        return doc

    def upsert(self, doc: Dict) -> Dict:
        if not doc.get("id"):
            return self.add(doc.get("title","Untitled"), doc.get("url"), doc.get("content",""),
                            doc.get("date"), doc.get("tags"), doc.get("products"))
        for i, d in enumerate(self.docs):
            if d["id"] == doc["id"]:
                self.docs[i] = {**d, **doc}
                return self.docs[i]
        self.docs.append(doc)
        return doc

    def all(self) -> List[Dict]:
        return self.docs

docstore = InMemoryDocStore()

if not docstore.all():
    docstore.add("에어컨 설치 가이드(벽걸이)", "https://example.com/ac-install",
                 "실내기 브라켓 고정, 배수 경사 확인, 실외기 환기 공간 확보...",
                 tags=["guide","install"], products=["AC-1234"])
    docstore.add("에어컨 에러 E5 해결", "https://example.com/e5",
                 "E5는 통신 오류. 전원 재시작→실내외기 케이블 체결 확인→보드 점검 순서로 진행.",
                 tags=["troubleshooting","runbook"], products=["AC-1234"])
