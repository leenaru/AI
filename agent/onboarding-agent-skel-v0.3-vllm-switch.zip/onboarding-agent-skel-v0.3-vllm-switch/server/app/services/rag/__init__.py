from app.core.config import settings
from .service import RAGService as InMemRAG
try:
    from .service_qdrant import QdrantRAGService
    HAS_QDRANT = True
except Exception:
    HAS_QDRANT = False

if settings.qdrant_url and HAS_QDRANT:
    rag = QdrantRAGService()
else:
    rag = InMemRAG()
