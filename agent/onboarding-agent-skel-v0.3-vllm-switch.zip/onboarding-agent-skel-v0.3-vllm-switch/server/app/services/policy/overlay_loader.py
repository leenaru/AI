import yaml
from pathlib import Path
from typing import List, Dict

BASE = Path("graphs")

def load_overlays(ids: List[str]) -> Dict:
    result = {"rules": {}}
    for oid in ids:
        if oid.startswith("country:"):
            code = oid.split(":", 1)[1].lower()
            path = BASE / "overlays" / "country" / f"{code}.yaml"
        elif oid.startswith("policy:"):
            name = oid.split(":", 1)[1]
            path = BASE / "policies" / f"{name}.yaml"
        else:
            continue
        if path.exists():
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            result["rules"].update(data.get("rules", {}))
    return result
