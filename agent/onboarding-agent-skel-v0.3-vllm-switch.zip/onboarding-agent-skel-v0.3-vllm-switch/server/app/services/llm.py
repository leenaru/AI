import httpx, os
from app.core.config import settings

class OllamaClient:
    def __init__(self, base=None):
        self.base = base or settings.ollama_base_url
    async def chat(self, model: str, messages: list[dict]):
        async with httpx.AsyncClient(timeout=60) as cx:
            r = await cx.post(f"{self.base}/api/chat", json={"model": model, "messages": messages})
            r.raise_for_status()
            data = r.json()
            # Normalize to {"message":{"content": "..."}}
            content = (data.get("message") or {}).get("content") or data.get("response") or ""
            return {"message": {"content": content}}

class VLLMClient:
    def __init__(self, base=None, api_key=None):
        self.base = base or settings.vllm_base_url.rstrip("/")
        self.key  = api_key or settings.vllm_api_key
    async def chat(self, model: str, messages: list[dict]):
        payload = {"model": model or settings.vllm_model, "messages": messages, "stream": False}
        async with httpx.AsyncClient(timeout=60) as cx:
            r = await cx.post(f"{self.base}/chat/completions",
                              headers={"Authorization": f"Bearer {self.key}"},
                              json=payload)
            r.raise_for_status()
            data = r.json()
            # OpenAI-compatible: choices[0].message.content
            content = ""
            try:
                content = data["choices"][0]["message"]["content"]
            except Exception:
                content = str(data)
            return {"message": {"content": content}}

backend = settings.llm_backend.lower()
llm = VLLMClient() if backend == "vllm" else OllamaClient()
