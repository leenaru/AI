from typing import Optional
from app.core.config import settings

OLLAMA_LANG_MODEL_MAP = {
    "ko": "llama3:instruct",
    "en": "llama3:instruct",
}
# In vLLM mode we serve a single model (settings.vllm_model)
def choose_model(lang: str | None, policy_country: Optional[str]) -> str:
    if settings.llm_backend.lower() == "vllm":
        return settings.vllm_model
    if lang:
        key = lang.split("-")[0]
        if key in OLLAMA_LANG_MODEL_MAP:
            return OLLAMA_LANG_MODEL_MAP[key]
    return settings.default_model
