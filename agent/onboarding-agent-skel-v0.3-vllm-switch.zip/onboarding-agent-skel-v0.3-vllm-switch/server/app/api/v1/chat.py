from fastapi import APIRouter
from app.models.schemas import ChatRequest, Answer, Citation
from app.services.langgraph.graph_runner import get_runner

router = APIRouter()

@router.post("/chat", response_model=Answer)
async def chat(req: ChatRequest):
    runner = get_runner()
    state = req.model_dump()
    result = await runner.run(state)
    return Answer(
        answer=result.get("answer", ""),
        citations=[Citation(**c) for c in result.get("citations", [])],
        actions=result.get("actions")
    )
