from fastapi import APIRouter
from app.models.schemas import CameraEvent, Answer

router = APIRouter()

@router.post("/events/camera", response_model=Answer)
async def camera_event(ev: CameraEvent):
    actions = []
    if ev.event_type == "document_present" and ev.score >= 0.8:
        actions.append({
            "type": "client_action",
            "action": "OPEN_CAMERA",
            "params": {"mode": "document"},
            "safety": {"requires_user_confirm": True, "reason": "문서 촬영"}
        })
    return Answer(answer="이벤트 처리됨", citations=[], actions=actions)
