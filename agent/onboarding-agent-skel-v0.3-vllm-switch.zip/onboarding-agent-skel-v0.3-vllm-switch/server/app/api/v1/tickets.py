from fastapi import APIRouter, HTTPException
from typing import Dict
from app.models.schemas import Ticket, TicketResolve
from app.services.rag import rag

router = APIRouter()

TICKETS: Dict[str, Ticket] = {}

@router.post("/tickets")
async def create_ticket(t: Ticket):
    t.id = t.id or str(len(TICKETS) + 1)
    TICKETS[t.id] = t
    return {"ok": True, "ticket": t}

@router.get("/tickets/{tid}")
async def get_ticket(tid: str):
    if tid not in TICKETS:
        raise HTTPException(404, "not found")
    return TICKETS[tid]

@router.patch("/tickets/{tid}/resolve")
async def resolve_ticket(tid: str, body: TicketResolve):
    if tid not in TICKETS:
        raise HTTPException(404, "not found")
    t = TICKETS[tid]
    t.status = "resolved"
    t.notes.append(body.resolution)
    # Upsert into RAG (both impls covered)
    upsert = getattr(rag, "upsert")
    if upsert.__code__.co_argcount == 2:
        upsert([{
            "title": f"해결: {t.symptom}",
            "content": body.resolution,
            "url": body.url,
            "tags": body.tags,
            "products": [t.product.model] if (t.product and t.product.model) else body.products
        }])
    else:
        upsert(title=f"해결: {t.symptom}", content=body.resolution, url=body.url, tags=body.tags,
               products=[t.product.model] if (t.product and t.product.model) else body.products)
    return {"ok": True, "ticket": t}
