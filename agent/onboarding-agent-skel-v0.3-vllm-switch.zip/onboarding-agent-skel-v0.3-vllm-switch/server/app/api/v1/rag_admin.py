from fastapi import APIRouter
from app.models.schemas import RAGDocIngest
from app.services.rag import rag

router = APIRouter()

@router.post("/rag/ingest")
async def rag_ingest(doc: RAGDocIngest):
    # works for both in-memory and Qdrant implementations
    upsert = getattr(rag, "upsert")
    if upsert.__code__.co_argcount == 2:
        # Qdrant: expects a list of docs
        saved = upsert([{
            "title": doc.title, "content": doc.content, "url": doc.url,
            "tags": doc.tags, "products": doc.products, "date": doc.date
        }])
    else:
        saved = upsert(title=doc.title, content=doc.content, url=doc.url, tags=doc.tags, products=doc.products, date=doc.date)
    return {"ok": True, "doc": saved}
