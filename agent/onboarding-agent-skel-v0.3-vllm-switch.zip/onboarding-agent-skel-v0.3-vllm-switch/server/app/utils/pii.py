import re
PII_PATTERNS = [ re.compile(r"(\d{6}-?\d{7})") ]
def mask(text: str) -> str:
    out = text
    for p in PII_PATTERNS:
        out = p.sub("[민감정보]", out)
    return out
