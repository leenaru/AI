# Onboarding Agent – Server + GUI Skeleton (v0.2)

This bundle contains:
- **server/**: FastAPI + LangGraph runtime + Ollama model router + HQ‑RAG (with optional **Qdrant**).
- **gui/**: React Flow graph editor (YAML ⇄ GUI).
- **clients/**: Android/iOS **action orchestrator** samples.

## Quickstart (Server)

```bash
cd server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# (Optional) set GRAPH_FILE=graphs/appliance.yaml to try appliance scenario
uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
```

### Docker (Ollama + Qdrant included)
```bash
cd server
docker compose up -d
docker exec -it ollama ollama pull llama3:instruct
# API: http://localhost:8080
```

### Endpoints
- `POST /v1/chat` – main chat/intent (actions/citations)
- `POST /v1/events/camera` – camera proactive event ingest
- `POST /v1/tickets` / `PATCH /v1/tickets/{id}/resolve` – escalation + *RAG update* by agents
- `POST /v1/rag/ingest` – manual knowledge ingestion (operators)
- `GET /healthz`

### Curl demo (Troubleshooting → Escalation → Operator Resolve → RAG update)
```bash
curl -s http://localhost:8080/v1/chat -H 'Content-Type: application/json' -d '{
  "text": "에어컨이 E5 에러가 떠요",
  "lang": "ko-KR",
  "product": {"brand":"Acme","model":"AC-1234"},
  "policy_context": {"country":"KR"}
}'
```

## Quickstart (GUI)
```bash
cd gui
npm i
npm run dev
# http://localhost:5173
```

## Notes
- To switch to the **appliance** graph: set `GRAPH_FILE=graphs/appliance.yaml` in `.env`.
- If **Qdrant** is up (via docker-compose) the RAG automatically uses it, otherwise in‑memory.
