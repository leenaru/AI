// Minimal orchestrator sample for Android (Kotlin)
sealed class ClientAction {
    data class OpenCamera(val mode: String, val timeoutMs: Long?): ClientAction()
    data class RequestInfo(val fields: List<String>): ClientAction()
}
data class ServerAction(val name: String, val params: Map<String, Any?>)
data class ActionEnvelope(
    val clientActions: List<ClientAction> = emptyList(),
    val serverActions: List<ServerAction> = emptyList()
)
class ActionOrchestrator {
    suspend fun handle(envelope: ActionEnvelope) {
        // TODO: implement API calls, permission checks, CameraX capture, and uplink
    }
}
