// Minimal orchestrator sample for iOS (SwiftUI)
import SwiftUI
import AVFoundation

enum ClientAction {
    case openCamera(mode: String, timeoutMs: Int?)
    case requestInfo(fields: [String])
}
struct ActionEnvelope {
    var clientActions: [ClientAction] = []
    var serverActions: [(name: String, params: [String:Any])] = []
}
final class ActionOrchestrator: ObservableObject {
    @Published var showCamera = false
    func handle(_ env: ActionEnvelope) {
        // TODO: implement URLSession calls, permission checks and camera sheet
    }
}
