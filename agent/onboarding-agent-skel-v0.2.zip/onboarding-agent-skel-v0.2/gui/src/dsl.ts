import yaml from 'js-yaml'

export type Dsl = {
  graph: {
    id: string,
    nodes: {id: string, type: string}[],
    edges: {from: string, to: string}[],
  },
  metadata?: any
}

export function parseYaml(text: string): Dsl {
  return yaml.load(text) as Dsl
}

export function toYaml(dsl: Dsl): string {
  return yaml.dump(dsl)
}
