import React, { useCallback, useState } from 'react'
import ReactFlow, { Background, Controls, addEdge, Connection, Edge, Node } from 'reactflow'
import 'reactflow/dist/style.css'
import { Dsl } from './dsl'

export default function GraphEditor({ dsl, onChange }:{ dsl:Dsl, onChange:(d:Dsl)=>void }){
  const [nodes, setNodes] = useState<Node[]>(dsl.graph.nodes.map((n,i)=>({id:n.id, position:{x:120*i,y:100}, data:{label:`${n.id} (${n.type})`}})))
  const [edges, setEdges] = useState<Edge[]>(dsl.graph.edges.map(e=>({id:`${e.from}->${e.to}`, source:e.from, target:e.to})))

  const onConnect = useCallback((c:Connection)=> setEdges(eds=>addEdge(c, eds)), [])
  const addNode = () => {
    const id = `node_${nodes.length+1}`
    const n:Node = {id, position:{x:50,y:50}, data:{label:`${id} (llm)`}}
    setNodes(ns=>[...ns,n])
  }
  const exportDsl = () => {
    const d:Dsl = {
      graph:{
        id: dsl.graph.id,
        nodes: nodes.map(n=>({id:n.id, type: String(n.data?.label).split('(')[1]?.replace(')','') || 'llm'})),
        edges: edges.map(e=>({from:e.source as string, to:e.target as string}))
      },
      metadata: dsl.metadata
    }
    onChange(d)
  }

  return (
    <div style={{height:'80vh', border:'1px solid #eee', borderRadius:16, padding:8}}>
      <div style={{display:'flex', gap:8, marginBottom:8}}>
        <button onClick={addNode}>노드 추가</button>
        <button onClick={exportDsl}>YAML 업데이트</button>
      </div>
      <ReactFlow nodes={nodes} edges={edges} onConnect={onConnect} fitView>
        <Background />
        <Controls />
      </ReactFlow>
    </div>
  )
}
