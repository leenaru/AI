import React, { useState } from 'react'
import GraphEditor from './GraphEditor'
import { parseYaml, toYaml, Dsl } from './dsl'

const initText = `graph:
  id: core-v1
  nodes:
    - id: intent_router
      type: router
    - id: rag_answer
      type: llm
  edges:
    - from: intent_router
      to: rag_answer
`

export default function App(){
  const [yamlText, setYamlText] = useState(initText)
  const [dsl, setDsl] = useState<Dsl>(parseYaml(initText))
  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, padding:16}}>
      <div>
        <h3>YAML</h3>
        <textarea value={yamlText} onChange={(e)=>{ setYamlText(e.target.value); setDsl(parseYaml(e.target.value)) }} style={{width:'100%', height:'80vh'}}/>
      </div>
      <div>
        <h3>Graph</h3>
        <GraphEditor dsl={dsl} onChange={(d)=> setYamlText(toYaml(d)) }/>
        <h4>Exported YAML</h4>
        <pre style={{whiteSpace:'pre-wrap', background:'#fafafa', padding:8, borderRadius:8}}>{yamlText}</pre>
      </div>
    </div>
  )
}
