from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any

class DeviceContext(BaseModel):
    platform: Optional[str] = None
    network: Optional[str] = None
    battery: Optional[float] = None
    permissions: Optional[Dict[str, bool]] = None

class PolicyContext(BaseModel):
    country: Optional[str] = None
    age_mode: Optional[str] = "adult"

class MultimodalPayload(BaseModel):
    image_refs: Optional[List[str]] = None
    audio_ref: Optional[str] = None

class ProductInfo(BaseModel):
    brand: Optional[str] = None
    model: Optional[str] = None
    serial: Optional[str] = None

class TroubleshootContext(BaseModel):
    symptom: Optional[str] = None
    severity: Optional[str] = None  # info|warn|error|critical

class ChatRequest(BaseModel):
    type: str = Field("graph_query")
    lang: str = Field("ko-KR")
    text: Optional[str] = None
    channels: List[str] = ["text"]
    multimodal: Optional[MultimodalPayload] = None
    device_context: Optional[DeviceContext] = None
    policy_context: Optional[PolicyContext] = None
    overlays: Optional[List[str]] = None
    product: Optional[ProductInfo] = None
    troubleshoot: Optional[TroubleshootContext] = None

class Citation(BaseModel):
    title: str
    url: str | None = None
    date: Optional[str] = None

class Answer(BaseModel):
    answer: str
    citations: List[Citation] = []
    actions: Optional[List[Dict[str, Any]]] = None

class CameraEvent(BaseModel):
    user_id: str
    event_type: str
    score: float
    meta: Dict[str, Any] = {}

class RAGDocIngest(BaseModel):
    title: str
    url: Optional[str] = None
    content: str
    date: Optional[str] = None
    tags: List[str] = []
    products: List[str] = []

class Ticket(BaseModel):
    id: Optional[str] = None
    user_id: str
    product: Optional[ProductInfo] = None
    symptom: str
    status: str = "open"
    notes: List[str] = []

class TicketResolve(BaseModel):
    resolution: str
    add_to_rag: bool = True
    tags: List[str] = ["troubleshooting","verified"]
    url: Optional[str] = None
    products: List[str] = []
