from fastapi import FastAPI
from app.core.logging import setup_logging
from app.core.config import settings
from app.api.v1 import chat, events, rag_admin, tickets

setup_logging("INFO")
app = FastAPI(title="On-device + Server AI – API", version="0.2.0")

app.include_router(chat.router, prefix="/v1")
app.include_router(events.router, prefix="/v1")
app.include_router(rag_admin.router, prefix="/v1")
app.include_router(tickets.router, prefix="/v1")

@app.get("/healthz")
async def healthz():
    return {"status": "ok", "env": settings.app_env}
