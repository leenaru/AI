import httpx
from app.core.config import settings

class OllamaClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or settings.ollama_base_url
        self._client = httpx.AsyncClient(timeout=60)

    async def generate(self, model: str, prompt: str, **kwargs):
        url = f"{self.base_url}/api/generate"
        payload = {"model": model, "prompt": prompt, **kwargs}
        r = await self._client.post(url, json=payload)
        r.raise_for_status()
        return r.json()

    async def chat(self, model: str, messages: list[dict], **kwargs):
        url = f"{self.base_url}/api/chat"
        payload = {"model": model, "messages": messages, **kwargs}
        r = await self._client.post(url, json=payload)
        r.raise_for_status()
        return r.json()

ollama = OllamaClient()
