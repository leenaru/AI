from typing import Dict, List
from app.core.config import settings

SENSITIVE_TOKENS = ["주민등록번호", "여권번호"]

class PolicyEnforcer:
    def __init__(self, rules: Dict | None = None):
        self.rules = rules or {}

    def require_citations(self) -> bool:
        return bool(self.rules.get("require_citations", True))

    def mask_pii(self, text: str) -> str:
        masked = text
        for t in SENSITIVE_TOKENS:
            masked = masked.replace(t, "[민감정보]")
        return masked

    def filter_topics(self, text: str) -> str:
        prohibited = self.rules.get("prohibited_topics", [])
        for topic in prohibited:
            if topic in text:
                return "요청하신 내용은 정책상 제공할 수 없어요."
        return text

    def enforce(self, answer: str, citations: List[Dict]) -> tuple[str, List[Dict]]:
        out = self.mask_pii(answer) if settings.pii_masking == "strict" else answer
        out = self.filter_topics(out)
        if self.require_citations() and not citations:
            out += "\n\n(참고: 현재 답변에는 근거가 부족합니다.)"
        return out, citations
