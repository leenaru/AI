from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance, PointStruct
from app.core.config import settings
from .embeddings import embed

class QdrantIndexer:
    def __init__(self):
        self.client = QdrantClient(url=settings.qdrant_url) if settings.qdrant_url else None
        self.collection = settings.qdrant_collection

    def ensure_collection(self, dim: int):
        if not self.client:
            return
        names = [c.name for c in self.client.get_collections().collections]
        if self.collection not in names:
            self.client.recreate_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(size=dim, distance=Distance.COSINE)
            )

    def upsert(self, docs: list[dict]):
        if not self.client:
            return {"ok": False}
        if not docs:
            return {"ok": True, "count": 0}
        texts = [d.get("content","") or "" for d in docs]
        vecs = embed(texts, settings.embed_model)
        dim = len(vecs[0])
        self.ensure_collection(dim)
        points = []
        for i, d in enumerate(docs):
            points.append(PointStruct(
                id=int(d.get("id") or i+1),
                vector=vecs[i],
                payload={
                    "title": d.get("title"),
                    "url": d.get("url"),
                    "date": d.get("date"),
                    "tags": d.get("tags", []),
                    "products": d.get("products", []),
                }
            ))
        self.client.upsert(collection_name=self.collection, points=points)
        return {"ok": True, "count": len(points)}

    def search(self, query: str, limit: int = 5, filters: dict | None = None):
        if not self.client:
            return []
        qv = embed([query], settings.embed_model)[0]
        from qdrant_client.models import Filter, FieldCondition, MatchAny
        f = None
        if filters:
            conds = []
            if filters.get("tags"):
                conds.append(FieldCondition(key="tags", match=MatchAny(any=filters["tags"])))
            if filters.get("products"):
                conds.append(FieldCondition(key="products", match=MatchAny(any=filters["products"])))
            if conds:
                f = Filter(must=conds)
        res = self.client.search(collection_name=self.collection, query_vector=qv, limit=limit, query_filter=f)
        out = []
        for r in res:
            p = r.payload or {}
            out.append({
                "id": r.id, "score": r.score,
                "title": p.get("title"), "url": p.get("url"),
                "date": p.get("date"), "tags": p.get("tags", []),
                "products": p.get("products", []),
                "content": ""
            })
        return out

indexer = QdrantIndexer()
