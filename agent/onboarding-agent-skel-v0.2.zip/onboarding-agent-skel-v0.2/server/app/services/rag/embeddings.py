from sentence_transformers import SentenceTransformer
from functools import lru_cache

@lru_cache(maxsize=1)
def get_embedder(model_name: str):
    return SentenceTransformer(model_name)

def embed(texts: list[str], model_name: str) -> list[list[float]]:
    em = get_embedder(model_name)
    vecs = em.encode(texts, normalize_embeddings=True).tolist()
    return vecs
