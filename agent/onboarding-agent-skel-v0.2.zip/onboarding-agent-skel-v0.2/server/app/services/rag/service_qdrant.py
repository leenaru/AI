from datetime import datetime, timedelta
from typing import List, Dict
from app.core.config import settings
from .indexer_qdrant import indexer

class QdrantRAGService:
    def __init__(self):
        self.min_citations = settings.rag_min_citations
        self.freshness_days = settings.rag_freshness_days

    def retrieve(self, query: str, products: List[str] | None = None, tags: List[str] | None = None) -> List[Dict]:
        filters = {"products": products, "tags": tags}
        return indexer.search(query=query, limit=max(self.min_citations, 5), filters=filters)

    def enforce_citations(self, answer: str, retrieved: List[Dict]) -> List[Dict]:
        recent_cut = datetime.now().date() - timedelta(days=self.freshness_days)
        cites = []
        for d in retrieved:
            date = d.get("date")
            if date:
                try:
                    if datetime.fromisoformat(date).date() < recent_cut:
                        continue
                except Exception:
                    pass
            cites.append({"title": d.get("title",""), "url": d.get("url"), "date": d.get("date")})
        if len(cites) < self.min_citations:
            for d in retrieved:
                c = {"title": d.get("title",""), "url": d.get("url"), "date": d.get("date")}
                if c not in cites: cites.append(c)
                if len(cites) >= self.min_citations: break
        return cites[: max(self.min_citations, 2)]

    def upsert(self, docs: List[Dict]):
        return indexer.upsert(docs)

rag_qdrant = QdrantRAGService()
