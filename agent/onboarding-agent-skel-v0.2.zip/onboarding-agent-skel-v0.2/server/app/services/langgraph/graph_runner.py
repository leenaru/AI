from typing import Dict, Any
import yaml
from app.core.config import settings
from app.services.policy.overlay_loader import load_overlays
from app.services.policy.enforcer import PolicyEnforcer
from .nodes import (
    intent_router_node, rag_answer_node, llm_answer_node, action_suggester_node,
    require_product_context, install_flow_node, usage_flow_node,
    troubleshoot_flow_node, warranty_flow_node, service_flow_node
)

try:
    from langgraph.graph import StateGraph
    LANGGRAPH_AVAILABLE = True
except Exception:
    LANGGRAPH_AVAILABLE = False

class GraphRunner:
    def __init__(self, graph_file: str | None = None, overlays: list[str] | None = None):
        self.graph_cfg = yaml.safe_load(open(graph_file or settings.graph_file, "r", encoding="utf-8").read())
        self.overlays = overlays or settings.policy_overlays
        self.rules = load_overlays(self.overlays).get("rules", {})
        self.enforcer = PolicyEnforcer(self.rules)
        if LANGGRAPH_AVAILABLE:
            self._build_langgraph()

    def _build_langgraph(self):
        sg = StateGraph(dict)
        sg.add_node("intent_router", intent_router_node)
        sg.add_node("rag_answer", rag_answer_node)
        sg.add_node("llm_answer", llm_answer_node)
        sg.add_node("require_product", require_product_context)
        sg.add_node("install_flow", install_flow_node)
        sg.add_node("usage_flow", usage_flow_node)
        sg.add_node("troubleshoot_flow", troubleshoot_flow_node)
        sg.add_node("warranty_flow", warranty_flow_node)
        sg.add_node("service_flow", service_flow_node)
        sg.add_node("action_suggester", action_suggester_node)

        sg.set_entry_point("intent_router")
        # fan-out edges
        for tgt in ["rag_answer","llm_answer","require_product","warranty_flow","service_flow","install_flow","usage_flow","troubleshoot_flow"]:
            sg.add_edge("intent_router", tgt)
        # terminal mapping to action suggester
        for node in ["rag_answer","llm_answer","install_flow","usage_flow","troubleshoot_flow","warranty_flow","service_flow","require_product"]:
            sg.add_edge(node, "action_suggester")

        self.app = sg.compile()

    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        if state.get("policy_context", {}).get("country"):
            state["policy_country"] = state["policy_context"]["country"]
        state["lang"] = state.get("lang") or "ko-KR"

        if LANGGRAPH_AVAILABLE:
            result = await self.app.ainvoke(state)
        else:
            # minimal manual path
            result = await intent_router_node(state)
            route = result.get("route")
            if route == "rag_answer":
                result = await rag_answer_node(result)
            elif route == "install_flow":
                result = await require_product_context(result)
                result = await install_flow_node(result)
            elif route == "usage_flow":
                result = await require_product_context(result)
                result = await usage_flow_node(result)
            elif route == "troubleshoot_flow":
                result = await require_product_context(result)
                result = await troubleshoot_flow_node(result)
            elif route == "warranty_flow":
                result = await warranty_flow_node(result)
            elif route == "service_flow":
                result = await service_flow_node(result)
            else:
                result = await llm_answer_node(result)
            result = await action_suggester_node(result)

        ans, cites = self.enforcer.enforce(result.get("answer", ""), result.get("citations", []))
        result["answer"], result["citations"] = ans, cites
        return result

def get_runner() -> GraphRunner:
    return GraphRunner(graph_file=settings.graph_file, overlays=settings.policy_overlays)
