from typing import Dict, Any
from app.services.rag import rag
from app.services.model_router import choose_model
from app.services.ollama_client import ollama

async def intent_router_node(state: Dict[str, Any]) -> Dict[str, Any]:
    text = (state.get("text") or "").lower()
    if any(k in text for k in ["설치", "연결", "추가", "페어링"]):
        state["route"] = "install_flow"
    elif any(k in text for k in ["등록", "정품"]):
        state["route"] = "warranty_flow"
    elif any(k in text for k in ["사용법", "어떻게", "기능"]):
        state["route"] = "usage_flow"
    elif any(k in text for k in ["고장", "에러", "오류", "안됨", "소음", "누수"]):
        state["route"] = "troubleshoot_flow"
    elif any(k in text for k in ["as", "수리", "방문", "접수"]):
        state["route"] = "service_flow"
    elif any(k in text for k in ["무엇", "언제", "어디", "정의", "설명", "근거"]):
        state["route"] = "rag_answer"
    else:
        state["route"] = "llm_answer"
    return state

async def require_product_context(state: Dict[str, Any]) -> Dict[str, Any]:
    prod = state.get("product") or {}
    if not prod.get("model"):
        state.setdefault("actions", []).append({
            "type": "client_action",
            "action": "REQUEST_INFO",
            "params": {"fields": ["brand","model","serial"]},
            "safety": {"requires_user_confirm": False}
        })
        state["answer"] = "제품 모델명/시리얼을 알려주세요. 필요 시 제품 라벨 촬영을 도와드릴게요."
    return state

async def rag_answer_node(state: Dict[str, Any]) -> Dict[str, Any]:
    query = state.get("text") or ""
    retrieved = rag.retrieve(query)
    cites = rag.enforce_citations("", retrieved)
    model = choose_model(state.get("lang"), state.get("policy_country"))
    messages = [{"role": "user", "content": f"질문: {query}\n참고자료 제목: {[d.get('title') for d in retrieved]}\n간결히 요약 답변."}]
    llm = await ollama.chat(model=model, messages=messages)
    state["answer"] = llm.get("message", {}).get("content", "요약을 생성하지 못했습니다.")
    state["citations"] = cites
    return state

async def llm_answer_node(state: Dict[str, Any]) -> Dict[str, Any]:
    model = choose_model(state.get("lang"), state.get("policy_country"))
    messages = [{"role": "user", "content": state.get("text") or ""}]
    llm = await ollama.chat(model=model, messages=messages)
    state["answer"] = llm.get("message", {}).get("content", "응답을 생성하지 못했습니다.")
    state["citations"] = []
    return state

async def install_flow_node(state: Dict[str, Any]) -> Dict[str, Any]:
    prod_model = (state.get('product') or {}).get('model', '')
    q = f"설치 가이드 {prod_model}"
    retrieved = rag.retrieve(q, products=[prod_model] if prod_model else None, tags=["guide","install"])
    cites = rag.enforce_citations("", retrieved)
    model = choose_model(state.get("lang"), state.get("policy_country"))
    messages = [{"role":"user","content": f"다음 자료 기반으로 설치 절차를 단계별 bullet로 간결히 요약: {[d.get('title') for d in retrieved]}"}]
    llm = await ollama.chat(model=model, messages=messages)
    state["answer"] = llm.get("message",{}).get("content","설치 절차를 찾지 못했습니다.")
    state["citations"] = cites
    return state

async def usage_flow_node(state: Dict[str, Any]) -> Dict[str, Any]:
    prod_model = (state.get('product') or {}).get('model', '')
    q = f"사용법 {state.get('text','')} {prod_model}"
    retrieved = rag.retrieve(q, products=[prod_model] if prod_model else None, tags=["guide","faq"])
    cites = rag.enforce_citations("", retrieved)
    model = choose_model(state.get("lang"), state.get("policy_country"))
    messages = [{"role":"user","content": f"아래 문서를 근거로 사용법을 요약: {[d.get('title') for d in retrieved]}"}]
    llm = await ollama.chat(model=model, messages=messages)
    state["answer"] = llm.get("message",{}).get("content","도움을 찾지 못했습니다.")
    state["citations"] = cites
    return state

async def troubleshoot_flow_node(state: Dict[str, Any]) -> Dict[str, Any]:
    prod_model = (state.get('product') or {}).get('model')
    symptom = (state.get('troubleshoot') or {}).get('symptom') or state.get('text','')

    if not prod_model:
        state.setdefault("actions", []).append({
            "type":"client_action","action":"OPEN_CAMERA","params":{"mode":"label"},
            "safety":{"requires_user_confirm": True, "reason":"모델 라벨 인식"}
        })
    retrieved = rag.retrieve(symptom, products=[prod_model] if prod_model else None, tags=["troubleshooting","runbook"])
    cites = rag.enforce_citations("", retrieved)

    confidence = 0
    if any("verified" in (d.get("tags") or []) for d in retrieved): confidence += 1
    if prod_model and any(prod_model in (d.get("products") or []) for d in retrieved): confidence += 1
    if len(retrieved) >= 2: confidence += 1

    model = choose_model(state.get("lang"), state.get("policy_country"))
    prompt = (
        "당신은 가전 A/S 기술 문서 기반의 수리 가이드입니다.\n"
        "응답 형식:\n"
        "1) 원인 후보(우선순위)\n2) 안전 경고\n3) 단계별 조치(체크리스트)\n4) 검증 방법\n"
        "반드시 근거 문서의 범위를 벗어나지 말고, 모호하면 '확신 부족'으로 표시하세요."
    )
    titles = [d.get('title') for d in retrieved]
    messages = [
        {"role":"system","content": prompt},
        {"role":"user","content": f"증상: {symptom}\n제품: {prod_model}\n근거문서: {titles}"}
    ]
    llm = await ollama.chat(model=model, messages=messages)
    plan = llm.get("message",{}).get("content","근거에 기반한 절차를 생성하지 못했습니다.")

    state["answer"] = plan
    state["citations"] = cites

    if confidence < 2 or len(cites) < 1:
        state.setdefault("actions", []).append({
            "type":"server_action","action":"CREATE_TICKET",
            "params":{"symptom": symptom, "product": state.get('product',{}), "priority":"high"}
        })
        state["answer"] += "\n\n(정확한 해결을 위해 담당자에게 보고를 진행합니다.)"
    return state

async def warranty_flow_node(state: Dict[str, Any]) -> Dict[str, Any]:
    state.setdefault("actions", []).append({
        "type":"client_action","action":"REQUEST_INFO",
        "params":{"fields":["purchase_date","receipt_photo"],"tips":"영수증/구매내역 촬영 업로드"}
    })
    state["answer"] = "정품등록을 위해 구매일자와 영수증 이미지를 제출해주세요."
    state["citations"] = []
    return state

async def service_flow_node(state: Dict[str, Any]) -> Dict[str, Any]:
    state.setdefault("actions", []).append({
        "type":"server_action","action":"CREATE_TICKET",
        "params":{"symptom": state.get('text',''), "product": state.get('product',{}), "priority":"normal"}
    })
    state["answer"] = "A/S 접수를 진행했어요. 접수 번호는 추후 안내됩니다."
    state["citations"] = []
    return state

async def action_suggester_node(state: Dict[str, Any]) -> Dict[str, Any]:
    text = (state.get("text") or "").lower()
    actions = state.get("actions") or []
    if "스캔" in text or "촬영" in text:
        actions.append({
            "type": "client_action",
            "action": "OPEN_CAMERA",
            "params": {"mode": "document", "timeoutMs": 15000},
            "safety": {"requires_user_confirm": True, "reason": "개인정보 포함 가능"}
        })
    state["actions"] = actions
    return state
