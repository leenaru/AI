from typing import Optional
from app.core.config import settings

LANG_MODEL_MAP = {
    "ko": "llama3:instruct",
    "en": "llama3:instruct",
}

def choose_model(lang: str | None, policy_country: Optional[str]) -> str:
    if lang:
        key = lang.split("-")[0]
        if key in LANG_MODEL_MAP:
            return LANG_MODEL_MAP[key]
    return settings.default_model
