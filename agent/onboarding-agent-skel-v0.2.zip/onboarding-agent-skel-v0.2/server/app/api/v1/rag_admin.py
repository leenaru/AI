from fastapi import APIRouter
from app.models.schemas import RAGDocIngest
from app.services.rag import rag

router = APIRouter()

@router.post("/rag/ingest")
async def rag_ingest(doc: RAGDocIngest):
    saved = rag.upsert([{
        "title": doc.title,
        "content": doc.content,
        "url": doc.url,
        "tags": doc.tags,
        "products": doc.products,
        "date": doc.date
    }]) if hasattr(rag, "upsert") and callable(getattr(rag, "upsert")) and "Qdrant" in rag.__class__.__name__ else rag.upsert(
        title=doc.title, content=doc.content, url=doc.url, tags=doc.tags, products=doc.products, date=doc.date
    )
    return {"ok": True, "doc": saved}
