from fastapi.testclient import TestClient
from app.main import app

def test_healthz():
    c = TestClient(app)
    r = c.get("/healthz")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_chat():
    c = TestClient(app)
    req = {
        "text": "영수증을 스캔해서 경비처리해줘",
        "lang": "ko-KR",
        "policy_context": {"country": "KR"}
    }
    r = c.post("/v1/chat", json=req)
    assert r.status_code == 200
    assert "answer" in r.json()
