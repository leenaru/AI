# Server – LangGraph + Ollama (with optional Qdrant)

See top-level README for quickstart. This service exposes FastAPI endpoints for chat, events, tickets and RAG ingestion.
