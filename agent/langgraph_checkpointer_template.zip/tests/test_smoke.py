import os, asyncio, pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture(scope="session", autouse=True)
def _setup_env():
    # Ensure DB_URI exists for local testing
    os.environ.setdefault("DB_URI", "postgresql://postgres:postgres@localhost:5432/postgres")

def test_app_imports():
    assert app is not None
