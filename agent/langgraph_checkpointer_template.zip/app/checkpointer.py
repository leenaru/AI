from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.checkpoint.serde.encrypted import EncryptedSerializer
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

@asynccontextmanager
async def create_pg_checkpointer(db_uri: str, aes_key: Optional[str] = None) -> AsyncIterator[AsyncPostgresSaver]:
    # Choose serializer: encrypted if key present, else JsonPlusSerializer (default)
    serde = EncryptedSerializer.from_pycryptodome_aes(key=aes_key) if aes_key else JsonPlusSerializer()
    async with AsyncPostgresSaver.from_conn_string(db_uri, serde=serde) as saver:
        # Ensure tables exist (first run)
        await saver.setup()
        yield saver
