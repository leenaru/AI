from fastapi import FastAPI, Query, Body, HTTPException
from pydantic import BaseModel
from typing import Any
from app.config import DB_URI, LANGGRAPH_AES_KEY, APP_NAME, APP_VERSION
from app.graph import build_workflow, ChatState
from app.checkpointer import create_pg_checkpointer
from langgraph.graph import StateGraph

# These are created in lifespan so they can be shared
graph = None

class ChatIn(BaseModel):
    text: str

def compile_graph_with(saver) -> StateGraph:
    workflow = build_workflow()
    return workflow.compile(checkpointer=saver)

# FastAPI lifespan: open/close DB checkpointer and compile graph
from contextlib import AsyncExitStack

app = FastAPI(title=APP_NAME, version=APP_VERSION)
_stack = AsyncExitStack()

@app.on_event("startup")
async def on_startup():
    global graph
    saver_cm = create_pg_checkpointer(DB_URI, LANGGRAPH_AES_KEY or None)
    saver = await _stack.enter_async_context(saver_cm)
    graph = compile_graph_with(saver)

@app.on_event("shutdown")
async def on_shutdown():
    await _stack.aclose()

@app.post("/chat")
async def chat(
    payload: ChatIn,
    thread_id: str = Query(..., description="세션/스레드 식별자"),
):
    try:
        cfg = {"configurable": {"thread_id": thread_id}}
        # NOTE: Provide full state for first step
        result = graph.invoke(ChatState(user=payload.text, replies=[]), cfg)
        return {"ok": True, "latest": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/state")
async def get_state(thread_id: str = Query(...)):
    cfg = {"configurable": {"thread_id": thread_id}}
    snap = graph.get_state(cfg)
    if snap is None:
        return {"exists": False}
    return {"exists": True, "state": snap.values, "checkpoint_id": snap.config["configurable"]["checkpoint_id"]}

@app.get("/history")
async def get_history(thread_id: str = Query(...), limit: int = Query(10, ge=1, le=100)):
    cfg = {"configurable": {"thread_id": thread_id}}
    history = list(graph.get_state_history(cfg))
    history = history[:limit]
    return {
        "count": len(history),
        "checkpoints": [
            {
                "checkpoint_id": s.config["configurable"]["checkpoint_id"],
                "created_at": s.created_at,
                "values": s.values,
                "metadata": s.metadata,
            } for s in history
        ]
    }
