from typing import TypedDict, Annotated
from operator import add
from langgraph.graph import StateGraph, START, END

# --- State schema -------------------------------------------------------------
class ChatState(TypedDict):
    # last user text (overwrite)
    user: str
    # list of all replies (append)
    replies: Annotated[list[str], add]

# --- Nodes --------------------------------------------------------------------
def echo_node(state: ChatState) -> ChatState:
    user_text = state.get("user", "")
    reply = f"봇: 당신이 말한 것은 '{user_text}' 입니다."
    return {"replies": [reply]}

# --- Builder ------------------------------------------------------------------
def build_workflow():
    g = StateGraph(ChatState)
    g.add_node("echo", echo_node)
    g.add_edge(START, "echo")
    g.add_edge("echo", END)
    return g
