import os

DB_URI = os.getenv("DB_URI", "postgresql://postgres:postgres@localhost:5432/postgres")
# Optional: AES key for encrypting checkpoints. 32 bytes hex/base64 supported by helper.
# When set, we wrap saver with EncryptedSerializer.from_pycryptodome_aes()
LANGGRAPH_AES_KEY = os.getenv("LANGGRAPH_AES_KEY", "")
APP_NAME = os.getenv("APP_NAME", "LangGraph Checkpointer Demo")
APP_VERSION = os.getenv("APP_VERSION", "0.1.0")
