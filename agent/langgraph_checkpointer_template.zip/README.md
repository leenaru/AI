# LangGraph Checkpointer Template (PostgreSQL, optional Redis cache) + FastAPI

Production-ready skeleton showing how to persist LangGraph state with **AsyncPostgresSaver**
(and optional AES encryption), expose it via **FastAPI**, and retrieve **state/history**.

## Key features
- AsyncPostgresSaver with `.setup()` on startup
- `thread_id` + optional `checkpoint_id` support
- Endpoints: `/chat`, `/state`, `/history`
- Optional AES encryption (`LANGGRAPH_AES_KEY`)
- Docker Compose for Postgres
- Minimal dependencies

> Docs:
> - Persistence & Checkpointers (official): https://langchain-ai.github.io/langgraph/concepts/persistence/
> - API reference (Postgres/AsyncPostgresSaver): https://langchain-ai.github.io/langgraph/reference/checkpoints/
> - PyPI (langgraph-checkpoint-postgres): https://pypi.org/project/langgraph-checkpoint-postgres/

## Quick start

1) Copy `.env.example` to `.env` and edit if needed.
2) Start Postgres:
```bash
docker compose up -d postgres
```
3) Install deps (Python 3.10+ recommended):
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
4) Run API:
```bash
uvicorn app.main:app --reload
```
5) Try it:
- `POST /chat?thread_id=demo` with body `{"text":"안녕하세요"}`
- `GET  /state?thread_id=demo`
- `GET  /history?thread_id=demo`

