# Weaviate Bootstrap v0.1 (KR)

> **요약 (TL;DR)**  
> 이 패키지는 **Weaviate + FastAPI** 기반의 **하이브리드 검색·RAG 백엔드**를 신속히 기동하기 위한 부트스트랩입니다.  
> - **Docker Compose**: Weaviate 서버 + API 서비스(FASTAPI)  
> - **Schema & Ingestion**: Named Vectors 스키마 생성, 샘플 데이터 적재(BYO 임베딩 또는 해시기반 대체 임베딩)  
> - **API**: `/search`(하이브리드), `/bm25`, `/near`, `/health`  
> - **Helm Chart**: Kubernetes 배포 스켈레톤  
> - **튜너**: 하이브리드 `alpha` 등 기본 튜닝 스캐폴딩

---

## 요구사항
- Docker / Docker Compose
- (선택) Python 3.10+ (로컬에서 스크립트 실행 시)
- (선택) Sentence-Transformers (임베딩 모델 다운로드 필요) 또는 **오프라인 데모용 해시 임베더** 사용

## 빠른 시작
```bash
# 1) Docker Compose 기동
docker compose up -d

# 2) 스키마 생성
docker compose exec api python /app/scripts/init_schema.py

# 3) 샘플 데이터 적재
docker compose exec api python /app/scripts/ingest.py

# 4) 검색 테스트
curl "http://localhost:8000/health"
curl "http://localhost:8000/search?q=AC-X100%20E18%20%EC%97%90%EB%9F%AC%20%EB%B3%B5%EA%B5%AC&k=5&alpha=0.5"
```

> 기본적으로 API 컨테이너가 Weaviate(`weaviate:8080/50051`)에 연결합니다.  
> 임베딩은 **Sentence-Transformers**를 우선 시도하고, 실패하면 **해시기반 대체 임베딩**으로 동작합니다.

## 아키텍처 개요
```
[Mobile/Client] --HTTP--> [FastAPI API] --gRPC/HTTP--> [Weaviate]
                               |                            |
                           Ingestion/Schema             HNSW + BM25F
                           (scripts)                    Hybrid Search
```
- **Named Vectors**(예: `title_vec`, `body_vec`, `ko_vec`, `en_vec`)로 한 오브젝트에 다중 임베딩 저장  
- **하이브리드 검색**: BM25F + 벡터(`alpha` 가중)  
- **스키마 참조(Cross-References)**: `DeviceManual` —hasChunks→ `Chunk`, `ErrorCode` —resolvedBy→ `FixStep` 등

## 환경변수
- `WEAVIATE_SCHEME` (기본: `http`)
- `WEAVIATE_HOST` (기본: `weaviate`)
- `WEAVIATE_HTTP_PORT` (기본: `8080`)
- `WEAVIATE_GRPC_PORT` (기본: `50051`)
- `EMBED_MODEL_NAME` (예: `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`)
- `EMBED_LOCAL_PATH` (로컬 모델 경로, 선택)
- `EMBED_DIM` (기본 384; 해시 임베더도 동일 차원 사용)

`.env.example` 참고

## 엔드포인트
- `GET /health` : Weaviate 연결 상태
- `GET /search?q=...&k=5&alpha=0.5&target_vector=body_vec&device_model=AC-X100&locale=ko`
- `GET /bm25?q=...&k=5`
- `POST /near` : JSON `{ "vector": [..], "k": 5 }`

## 데이터/스키마
- 컬렉션: `DeviceManual`, `ErrorCode`, `FixStep`, `FAQ`, `Chunk`
- Named Vectors: `title_vec`, `body_vec`, `ko_vec`, `en_vec` (필요시 조정)
- 샘플: `data/sample/*.json`

## Kubernetes (Helm)
- `k8s/helm/` 하위에 API/Weaviate 배포 스켈레톤 템플릿 포함
- 실제 운영에서는 RBAC, 백업 모듈, 복제/일관성, 스토리지 클래스 설정 필요

## 라이선스
- 샘플 코드는 MIT. Weaviate 이미지 및 모델 라이선스는 각 프로젝트 정책을 따르세요.

---

## 다음 단계 지침
- 실제 도메인 데이터로 `scripts/ingest.py` 수정
- 멀티벡터/타겟 설정, 필터(`device_model`, `locale`) 최적화
- 재랭커(예: cross-encoder) 추가 및 상위 k 재정렬
- 백업/복제/RBAC 등 운영 설정 반영
