# Simple alpha tuner skeleton
import numpy as np
import weaviate

client = weaviate.connect_to_local()
col = client.collections.get("DeviceManual")

QUERIES = [
    ("AC-X100 E18 에러 복구", "ko"),
    ("outdoor unit noise fix", "en"),
    ("실내기 냄새 제거 방법", "ko"),
]

def eval_alpha(alpha: float, k=5):
    total = 0.0
    for q, _lang in QUERIES:
        res = col.query.hybrid(query=q, alpha=alpha, limit=k)
        # naive proxy: average score of top-k
        if not res.objects:
            continue
        avg = np.mean([o.metadata.score for o in res.objects])
        total += float(avg)
    return total / max(len(QUERIES), 1)

def main():
    candidates = [round(x, 2) for x in np.linspace(0.1, 0.9, 9)]
    best = None
    for a in candidates:
        score = eval_alpha(a)
        print(f"alpha={a:.2f} -> proxy={score:.4f}")
        if best is None or score > best[1]:
            best = (a, score)
    print(f"[BEST] alpha={best[0]:.2f} (proxy={best[1]:.4f})")

if __name__ == "__main__":
    main()
    client.close()
