import os, json, glob, numpy as np
import weaviate

from utils.embedder import get_embedder

client = weaviate.connect_to_local()
embedder = get_embedder()

DATA_DIR = "/app/data/sample"

def load_jsons():
    for p in glob.glob(os.path.join(DATA_DIR, "*.json")):
        with open(p, "r", encoding="utf-8") as f:
            yield json.load(f)

def ingest():
    manuals = client.collections.get("DeviceManual")
    with manuals.batch.dynamic() as batch:
        for obj in load_jsons():
            body = obj.get("body", "") or ""
            title = obj.get("title", "") or ""
            ko = body if obj.get("locale") == "ko" else title + " " + body
            en = body if obj.get("locale") == "en" else title + " " + body

            vectors = {
                "title_vec": embedder.encode(title),
                "body_vec":  embedder.encode(body),
                "ko_vec":    embedder.encode(ko),
                "en_vec":    embedder.encode(en),
            }
            batch.add_object(properties=obj, vectors=vectors)
    print("[✓] Ingested sample data.")

if __name__ == "__main__":
    ingest()
    client.close()
