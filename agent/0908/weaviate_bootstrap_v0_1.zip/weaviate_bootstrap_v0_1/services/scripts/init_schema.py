import weaviate
from weaviate.classes.config import Property, DataType, Configure, Tokenization, ReferenceProperty

client = weaviate.connect_to_local()

def ensure_collection(name: str, properties, vectorizer_config, inverted_index_config=None):
    if client.collections.exists(name):
        print(f"[=] Collection exists: {name}")
        return client.collections.get(name)
    col = client.collections.create(
        name=name,
        properties=properties,
        vectorizer_config=vectorizer_config,
        inverted_index_config=inverted_index_config or Configure.inverted_index()
    )
    print(f"[+] Created collection: {name}")
    return col

# DeviceManual
DeviceManual = ensure_collection(
    "DeviceManual",
    properties=[
        Property(name="title", data_type=DataType.TEXT, tokenization=Tokenization.WORD, index_searchable=True),
        Property(name="body", data_type=DataType.TEXT, tokenization=Tokenization.WORD, index_searchable=True),
        Property(name="device_model", data_type=DataType.TEXT, index_filterable=True),
        Property(name="locale", data_type=DataType.TEXT, index_filterable=True),
        Property(name="url", data_type=DataType.TEXT, index_filterable=True),
        Property(name="created_at", data_type=DataType.DATE, index_range_filters=True),
    ],
    vectorizer_config=Configure.NamedVectors.multi({
        "title_vec": Configure.Vectorizer.none(),
        "body_vec":  Configure.Vectorizer.none(),
        "ko_vec":    Configure.Vectorizer.none(),
        "en_vec":    Configure.Vectorizer.none(),
    }),
)

# Chunk
Chunk = ensure_collection(
    "Chunk",
    properties=[
        Property(name="body", data_type=DataType.TEXT, tokenization=Tokenization.WORD, index_searchable=True),
        Property(name="sequence", data_type=DataType.INT, index_filterable=True),
        Property(name="device_model", data_type=DataType.TEXT, index_filterable=True),
        Property(name="locale", data_type=DataType.TEXT, index_filterable=True),
    ],
    vectorizer_config=Configure.Vectorizer.none(),
)

# ErrorCode
ErrorCode = ensure_collection(
    "ErrorCode",
    properties=[
        Property(name="code", data_type=DataType.TEXT, index_filterable=True),
        Property(name="device_model", data_type=DataType.TEXT, index_filterable=True),
        Property(name="symptoms", data_type=DataType.TEXT, index_searchable=True),
        Property(name="cause", data_type=DataType.TEXT, index_searchable=True),
    ],
    vectorizer_config=Configure.NamedVectors.multi({
        "code_vec":  Configure.Vectorizer.none(),
        "cause_vec": Configure.Vectorizer.none(),
    }),
)

# FixStep
FixStep = ensure_collection(
    "FixStep",
    properties=[
        Property(name="step_title", data_type=DataType.TEXT, index_searchable=True),
        Property(name="step_body", data_type=DataType.TEXT, index_searchable=True),
        Property(name="image_url", data_type=DataType.TEXT, index_filterable=True),
    ],
    vectorizer_config=Configure.Vectorizer.none(),
)

# FAQ
FAQ = ensure_collection(
    "FAQ",
    properties=[
        Property(name="q", data_type=DataType.TEXT, index_searchable=True),
        Property(name="a", data_type=DataType.TEXT, index_searchable=True),
        Property(name="locale", data_type=DataType.TEXT, index_filterable=True),
    ],
    vectorizer_config=Configure.NamedVectors.multi({
        "q_vec": Configure.Vectorizer.none(),
        "a_vec": Configure.Vectorizer.none(),
    }),
)

# Cross references
DeviceManual.config.add_reference(ReferenceProperty(name="hasChunks", target_collection="Chunk"))
ErrorCode.config.add_reference(ReferenceProperty(name="resolvedBy", target_collection="FixStep"))
FAQ.config.add_reference(ReferenceProperty(name="referencesManual", target_collection="DeviceManual"))

print("[✓] Schema initialized.")
client.close()
