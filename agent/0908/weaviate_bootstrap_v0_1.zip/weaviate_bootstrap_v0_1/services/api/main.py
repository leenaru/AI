import os
import numpy as np
from fastapi import FastAPI, Query, Body
from pydantic import BaseModel
import weaviate

from utils.embedder import get_embedder

WEAVIATE_SCHEME = os.getenv("WEAVIATE_SCHEME", "http")
WEAVIATE_HOST = os.getenv("WEAVIATE_HOST", "weaviate")
WEAVIATE_HTTP_PORT = int(os.getenv("WEAVIATE_HTTP_PORT", "8080"))
WEAVIATE_GRPC_PORT = int(os.getenv("WEAVIATE_GRPC_PORT", "50051"))

app = FastAPI(title="Weaviate Bootstrap API", version="0.1")

client = weaviate.connect_to_custom(
    http_host=WEAVIATE_HOST,
    http_port=WEAVIATE_HTTP_PORT,
    http_secure=(WEAVIATE_SCHEME == "https"),
    grpc_host=WEAVIATE_HOST,
    grpc_port=WEAVIATE_GRPC_PORT,
    grpc_secure=(WEAVIATE_SCHEME == "https"),
)

embedder = get_embedder()

@app.get("/health")
def health():
    return {"weaviate_ready": client.is_ready()}

class SearchResult(BaseModel):
    uuid: str
    score: float
    properties: dict

@app.get("/search", response_model=list[SearchResult])
def search(
    q: str = Query(..., description="질의문"),
    k: int = 5,
    alpha: float = 0.5,
    target_vector: str | None = None,
    device_model: str | None = None,
    locale: str | None = None,
    collection: str = "DeviceManual"
):
    col = client.collections.get(collection)
    filters = []
    if device_model:
        filters.append(("device_model", "==", device_model))
    if locale:
        filters.append(("locale", "==", locale))

    where_filter = None
    if filters:
        # simple AND filter builder
        from weaviate.classes.query import Filter
        f = None
        for (prop, op, val) in filters:
            cur = Filter.by_property(prop).equal(val)
            f = cur if f is None else f & cur
        where_filter = f

    res = col.query.hybrid(
        query=q,
        alpha=alpha,
        target_vector=target_vector,
        where=where_filter,
        limit=k,
    )
    out = []
    for o in res.objects:
        out.append(SearchResult(uuid=o.uuid, score=o.metadata.score, properties=o.properties))
    return out

@app.get("/bm25", response_model=list[SearchResult])
def bm25(
    q: str,
    k: int = 5,
    collection: str = "DeviceManual"
):
    from weaviate.classes.query import BM25Operator
    col = client.collections.get(collection)
    res = col.query.bm25(query=q, operator=BM25Operator.and_(), limit=k)
    return [SearchResult(uuid=o.uuid, score=o.metadata.score, properties=o.properties) for o in res.objects]

class NearBody(BaseModel):
    vector: list[float]
    k: int = 5
    collection: str = "DeviceManual"

@app.post("/near", response_model=list[SearchResult])
def near(body: NearBody):
    col = client.collections.get(body.collection)
    vec = np.array(body.vector, dtype=np.float32)
    res = col.query.near_vector(near_vector=vec, limit=body.k)
    return [SearchResult(uuid=o.uuid, score=o.metadata.distance or o.metadata.score, properties=o.properties) for o in res.objects]

@app.get("/embed")
def embed(q: str):
    v = embedder.encode(q)
    return {"dim": len(v), "head": list(map(float, v[:8]))}
