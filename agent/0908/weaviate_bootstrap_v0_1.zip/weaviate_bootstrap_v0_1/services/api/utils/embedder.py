import os, numpy as np

EMBED_DIM = int(os.getenv("EMBED_DIM", "384"))
MODEL_NAME = os.getenv("EMBED_MODEL_NAME", "")
LOCAL_PATH = os.getenv("EMBED_LOCAL_PATH", "")

class HashEmbedder:
    """Very simple offline fallback embedding: bag-of-words hashed into fixed dims."""
    def __init__(self, dim: int = 384):
        self.dim = dim

    def encode(self, text: str) -> np.ndarray:
        import re, hashlib
        tokens = re.findall(r"\w+", text.lower())
        v = np.zeros(self.dim, dtype=np.float32)
        for t in tokens:
            h = int(hashlib.md5(t.encode("utf-8")).hexdigest(), 16)
            idx = h % self.dim
            sign = 1.0 if (h % 2 == 0) else -1.0
            v[idx] += sign
        # l2-normalize
        norm = np.linalg.norm(v) or 1.0
        return (v / norm).astype(np.float32)

try:
    from sentence_transformers import SentenceTransformer
    _sbert_model = None
    def get_embedder():
        global _sbert_model
        if MODEL_NAME or LOCAL_PATH:
            try:
                _sbert_model = SentenceTransformer(LOCAL_PATH or MODEL_NAME)
                return _SBertWrapper(_sbert_model)
            except Exception:
                pass
        # fallback
        return HashEmbedder(dim=EMBED_DIM)
    class _SBertWrapper:
        def __init__(self, model):
            self.model = model
        def encode(self, text: str) -> np.ndarray:
            v = self.model.encode(text)
            return np.array(v, dtype=np.float32)
except Exception:
    def get_embedder():
        return HashEmbedder(dim=EMBED_DIM)
