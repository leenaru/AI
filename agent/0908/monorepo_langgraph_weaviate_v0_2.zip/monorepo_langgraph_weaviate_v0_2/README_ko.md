# Monorepo v0.2 — Weaviate + LangGraph Orchestrator (KR)

본 레포는 귀하의 **모노레포/네이밍 컨벤션**에 맞춰 재정렬한 **검색 백엔드(Search-API)**와
**LangGraph 기반 오케스트레이터(Orchestrator-Graph)**를 포함합니다.

- apps/
  - **search-api**: Weaviate 하이브리드 검색 API (Named Vectors, 필터)
  - **orchestrator-graph**: LangGraph + FastAPI. 의도 → 검색 → (선택)생성/요약 → 응답
- packages/
  - **clients-weaviate**: Weaviate gRPC/HTTP 클라이언트 래퍼
  - **llm-system-service**: LLM 어댑터 (Ollama/에코 폴백)
  - **model-adapter**: 경량 Intent/Slot 추출 (규칙/키워드 기반; Gemma-3n 자리)
  - **rag-pipeline**: 검색/정규화/후처리 유틸
  - **schemas**: 공용 Pydantic 스키마
- infra: Docker Compose, Helm 스켈레톤
- data/sample: 샘플 문서

## 빠른 시작
```bash
docker compose up -d
# 스키마 초기화 & 샘플 적재
docker compose exec search-api python /workspace/apps/search-api/scripts/init_schema.py
docker compose exec search-api python /workspace/apps/search-api/scripts/ingest.py

# 검색 API
curl "http://localhost:8001/health"
curl "http://localhost:8001/search?q=AC-X100%20E18%20%EC%97%90%EB%9F%AC%20%EB%B3%B5%EA%B5%AC&k=5&alpha=0.5"

# 오케스트레이터 (LangGraph)
curl -X POST "http://localhost:8010/chat" -H "Content-Type: application/json"   -d '{"user_input":"AC-X100 E18 오류 해결해줘","device_model":"AC-X100","locale":"ko"}'
```
> LLM 연계는 기본 **Ollama**를 우선 시도하며(`OLLAMA_BASE_URL`), 없으면 **요약 에코 폴백**으로 동작합니다.

## 환경변수(.env.example)
- 공통: `WEAVIATE_HOST`=`weaviate`, `WEAVIATE_HTTP_PORT`=`8080`, `WEAVIATE_GRPC_PORT`=`50051`
- 임베딩: `EMBED_MODEL_NAME` (SBERT), `EMBED_DIM`(기본 384)
- LLM: `OLLAMA_BASE_URL` (예: `http://ollama:11434`), `OLLAMA_MODEL`(예: `llama3:instruct`)

## 포트
- search-api: **8001**
- orchestrator-graph: **8010**
- weaviate: 8080(http) / 50051(grpc)
- (옵션) ollama: 11434

## 참고
- 실제 운영 시 RBAC, 백업 모듈, 복제/일관성, 로그/모니터링 추가를 권장합니다.
