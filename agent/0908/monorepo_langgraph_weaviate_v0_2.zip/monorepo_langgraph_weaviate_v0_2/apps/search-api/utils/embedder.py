import os, numpy as np

EMBED_DIM = int(os.getenv("EMBED_DIM", "384"))
MODEL_NAME = os.getenv("EMBED_MODEL_NAME", "")

class HashEmbedder:
    def __init__(self, dim: int = 384):
        self.dim = dim
    def encode(self, text: str) -> np.ndarray:
        import re, hashlib
        tokens = re.findall(r"\w+", (text or "").lower())
        v = np.zeros(self.dim, dtype=np.float32)
        for t in tokens:
            h = int(hashlib.md5(t.encode("utf-8")).hexdigest(), 16)
            idx = h % self.dim
            sign = 1.0 if (h % 2 == 0) else -1.0
            v[idx] += sign
        n = np.linalg.norm(v) or 1.0
        return (v / n).astype(np.float32)

def get_embedder():
    try:
        from sentence_transformers import SentenceTransformer
        if MODEL_NAME:
            model = SentenceTransformer(MODEL_NAME)
            class _W:
                def encode(self, t: str):
                    import numpy as np
                    return np.array(model.encode(t), dtype=np.float32)
            return _W()
    except Exception:
        pass
    return HashEmbedder(dim=EMBED_DIM)
