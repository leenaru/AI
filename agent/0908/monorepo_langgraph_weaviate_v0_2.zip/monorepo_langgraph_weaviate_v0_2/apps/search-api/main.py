import os
from fastapi import FastAPI
from pydantic import BaseModel
from packages.clients-weaviate.weaviate_client import WeaviateClient
from packages.schemas.models import RetrievalItem
from apps.search-api.utils.embedder import get_embedder

app = FastAPI(title="Search-API", version="0.2")
wvc = WeaviateClient()
embedder = get_embedder()

@app.get("/health")
def health():
    return {"weaviate_ready": wvc.is_ready()}

@app.get("/search", response_model=list[RetrievalItem])
def search(q: str, k: int = 5, alpha: float = 0.5, target_vector: str | None = None,
           device_model: str | None = None, locale: str | None = None,
           collection: str = "DeviceManual"):
    objs = wvc.hybrid(collection, q, k, alpha, target_vector, device_model, locale)
    return [RetrievalItem(uuid=o.uuid, score=float(getattr(o.metadata, "score", 0.0) or 0.0), properties=o.properties) for o in objs]

@app.get("/bm25", response_model=list[RetrievalItem])
def bm25(q: str, k: int = 5, collection: str = "DeviceManual"):
    objs = wvc.bm25(collection, q, k)
    return [RetrievalItem(uuid=o.uuid, score=float(getattr(o.metadata, "score", 0.0) or 0.0), properties=o.properties) for o in objs]

class NearBody(BaseModel):
    vector: list[float]
    k: int = 5
    collection: str = "DeviceManual"

@app.post("/near", response_model=list[RetrievalItem])
def near(body: NearBody):
    objs = wvc.near_vector(body.collection, body.vector, body.k)
    # 'distance' may be used; map to score
    return [RetrievalItem(uuid=o.uuid, score=float(getattr(o.metadata, "distance", 0.0) or 0.0), properties=o.properties) for o in objs]
