from fastapi import FastAPI, Body
from packages.model-adapter.adapter import detect_intent, extract_slots
from packages.clients-weaviate.weaviate_client import WeaviateClient
from packages.llm-system-service.adapter import generate
from packages.schemas.models import ChatRequest, ChatResponse
from packages.rag-pipeline.utils import normalize_objects, format_sources

from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableLambda
from pydantic import BaseModel

app = FastAPI(title="Orchestrator-Graph", version="0.2")
wvc = WeaviateClient()

class State(BaseModel):
    user_input: str
    intent: str | None = None
    device_model: str | None = None
    locale: str | None = None
    k: int = 5
    alpha: float = 0.5
    target_vector: str | None = None
    retrieval: list[dict] = []

def node_intent(state: State) -> State:
    i = detect_intent(state.user_input)["intent"]
    slots = extract_slots(state.user_input)
    state.intent = i
    state.device_model = state.device_model or slots.get("device_model")
    state.locale = state.locale or slots.get("locale")
    return state

def node_retrieve(state: State) -> State:
    objs = wvc.hybrid(
        "DeviceManual",
        state.user_input,
        k=state.k,
        alpha=state.alpha,
        target_vector=state.target_vector,
        device_model=state.device_model,
        locale=state.locale,
    )
    state.retrieval = [ {"uuid": o.uuid, "score": float(getattr(o.metadata, "score", 0.0) or 0.0), "properties": o.properties} for o in objs ]
    return state

def node_answer(state: State) -> State:
    sources = normalize_objects(state.retrieval)
    src_txt = format_sources(sources)
    context = "\n\n".join([s.properties.get("body") or s.properties.get("a") or "" for s in sources])[:3000]
    system = "You are a bilingual (Korean/English) support agent for home appliances."
    prompt = f"""[User]
{state.user_input}

[Context]
{context}

[Sources]
{src_txt}

[Instruction]
- Answer succinctly in the user's language.
- Include numbered citations like [1], [2] mapping to Sources when relevant.
"""
    answer = generate(prompt, system=system)
    state_dict = state.dict()
    state_dict["answer"] = answer
    return State(**state_dict)

workflow = StateGraph(State)
workflow.add_node("intent", RunnableLambda(node_intent))
workflow.add_node("retrieve", RunnableLambda(node_retrieve))
workflow.add_node("answer", RunnableLambda(node_answer))
workflow.set_entry_point("intent")
workflow.add_edge("intent", "retrieve")
workflow.add_edge("retrieve", "answer")
workflow.add_edge("answer", END)
graph = workflow.compile()

@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest = Body(...)):
    state = State(
        user_input=req.user_input,
        device_model=req.device_model,
        locale=req.locale,
        k=req.k,
        alpha=req.alpha,
        target_vector=req.target_vector,
    )
    final = graph.invoke(state)
    sources = normalize_objects(final.retrieval)
    return ChatResponse(answer=getattr(final, "answer", ""), sources=sources, intent=final.intent or "retrieval")

@app.get("/health")
def health():
    return {"status": "ok", "weaviate_ready": wvc.is_ready()}
