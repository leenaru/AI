import os, requests

OLLAMA_BASE = os.getenv("OLLAMA_BASE_URL", "").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3:instruct")

def generate(prompt: str, system: str = "", temperature: float = 0.2) -> str:
    """
    Try Ollama; fallback to a deterministic summarizer/echo if unavailable.
    """
    if OLLAMA_BASE:
        try:
            resp = requests.post(f"{OLLAMA_BASE}/api/generate", json={
                "model": OLLAMA_MODEL,
                "prompt": (system + "\n" + prompt).strip(),
                "options": {"temperature": temperature}
            }, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            return (data.get("response", "") or "").strip() or "[empty]"
        except Exception:
            pass
    # Fallback: simple truncating echo/summarizer
    if len(prompt) > 1200:
        return prompt[:1000] + "\n\n...[truncated summary]"
    return prompt
