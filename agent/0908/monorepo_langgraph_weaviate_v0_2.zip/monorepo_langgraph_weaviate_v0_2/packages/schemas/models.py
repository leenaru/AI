from pydantic import BaseModel, Field
from typing import Any, List, Optional, Dict

class RetrievalItem(BaseModel):
    uuid: str
    score: float
    properties: Dict[str, Any]

class RetrievalRequest(BaseModel):
    query: str
    k: int = 5
    alpha: float = 0.5
    target_vector: Optional[str] = None
    device_model: Optional[str] = None
    locale: Optional[str] = None
    collection: str = "DeviceManual"

class ChatRequest(BaseModel):
    user_input: str
    device_model: Optional[str] = None
    locale: Optional[str] = "ko"
    k: int = 5
    alpha: float = 0.5
    target_vector: Optional[str] = None

class ChatResponse(BaseModel):
    answer: str
    sources: List[RetrievalItem] = Field(default_factory=list)
    intent: str = "retrieval"
