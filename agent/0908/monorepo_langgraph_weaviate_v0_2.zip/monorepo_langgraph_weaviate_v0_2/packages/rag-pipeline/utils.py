from typing import List
from packages.schemas.models import RetrievalItem

def normalize_objects(objs) -> List[RetrievalItem]:
    out = []
    for o in objs or []:
        out.append(RetrievalItem(uuid=o.uuid, score=float(getattr(o.metadata, "score", 0.0) or 0.0), properties=o.properties))
    return out

def format_sources(sources: List[RetrievalItem]) -> str:
    lines = []
    for i, s in enumerate(sources, 1):
        title = s.properties.get("title") or s.properties.get("step_title") or s.properties.get("q") or "untitled"
        url = s.properties.get("url", "")
        lines.append(f"[{i}] {title}  {('(' + url + ')') if url else ''}")
    return "\n".join(lines)
