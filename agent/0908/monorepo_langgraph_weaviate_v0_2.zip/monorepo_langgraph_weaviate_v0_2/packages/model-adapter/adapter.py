import re
from typing import Dict

def detect_intent(text: str) -> Dict[str, str]:
    t = (text or '').lower()
    if re.search(r"\b(e\d{2}|error|오류|고장|에러)\b", t):
        return {"intent": "troubleshoot"}
    if "설명" in t or "what is" in t or "explain" in t:
        return {"intent": "explain"}
    return {"intent": "retrieval"}

def extract_slots(text: str) -> Dict[str, str]:
    slots = {}
    m = re.search(r"\b([A-Z]{2,3}-[A-Z0-9]{2,6})\b", text or '')
    if m:
        slots["device_model"] = m.group(1)
    low = (text or '').lower()
    if "한국" in low or "한글" in low or " ko " in (" " + low + " "):
        slots["locale"] = "ko"
    elif "english" in low or " en " in (" " + low + " "):
        slots["locale"] = "en"
    return slots
