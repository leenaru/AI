import os
import weaviate
from weaviate.classes.query import BM25Operator, Filter

class WeaviateClient:
    def __init__(self):
        scheme = os.getenv("WEAVIATE_SCHEME", "http")
        host = os.getenv("WEAVIATE_HOST", "weaviate")
        http_port = int(os.getenv("WEAVIATE_HTTP_PORT", "8080"))
        grpc_port = int(os.getenv("WEAVIATE_GRPC_PORT", "50051"))
        self.client = weaviate.connect_to_custom(
            http_host=host, http_port=http_port, http_secure=(scheme=="https"),
            grpc_host=host, grpc_port=grpc_port, grpc_secure=(scheme=="https"),
        )

    def is_ready(self) -> bool:
        return self.client.is_ready()

    def collection(self, name: str):
        return self.client.collections.get(name)

    def hybrid(self, collection: str, query: str, k: int=5, alpha: float=0.5,
               target_vector: str|None=None, device_model: str|None=None,
               locale: str|None=None):
        col = self.collection(collection)
        where = None
        f = None
        if device_model:
            f = Filter.by_property("device_model").equal(device_model)
        if locale:
            cur = Filter.by_property("locale").equal(locale)
            f = cur if f is None else f & cur
        if f:
            where = f
        res = col.query.hybrid(query=query, alpha=alpha, target_vector=target_vector, where=where, limit=k)
        return res.objects

    def bm25(self, collection: str, query: str, k: int=5):
        col = self.collection(collection)
        res = col.query.bm25(query=query, operator=BM25Operator.and_(), limit=k)
        return res.objects

    def near_vector(self, collection: str, vec, k: int=5):
        import numpy as np
        col = self.collection(collection)
        res = col.query.near_vector(near_vector=np.array(vec, dtype=np.float32), limit=k)
        return res.objects

    def close(self):
        self.client.close()
