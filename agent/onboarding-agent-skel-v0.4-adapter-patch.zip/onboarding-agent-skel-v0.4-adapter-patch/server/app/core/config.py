from pydantic import BaseSettings, Field
from typing import List
import os

class Settings(BaseSettings):
    app_env: str = Field(default=os.getenv("APP_ENV", "dev"))
    api_port: int = Field(default=int(os.getenv("API_PORT", 8080)))
    llm_backend: str = Field(default=os.getenv("LLM_BACKEND", "vllm"))
    vllm_base_url: str = Field(default=os.getenv("VLLM_BASE_URL", "http://localhost:8000/v1"))
    vllm_api_key: str = Field(default=os.getenv("VLLM_API_KEY", "EMPTY"))
    vllm_model: str = Field(default=os.getenv("VLLM_MODEL", "mistralai/Mistral-7B-Instruct-v0.3"))
    ollama_base_url: str = Field(default=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    ollama_default_model: str = Field(default=os.getenv("OLLAMA_DEFAULT_MODEL", "llama3:instruct"))
    openai_base_url: str = Field(default=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    openai_api_key: str = Field(default=os.getenv("OPENAI_API_KEY", ""))
    openai_model: str = Field(default=os.getenv("OPENAI_MODEL", "gpt-4o"))
    tgi_base_url: str = Field(default=os.getenv("TGI_BASE_URL", "http://localhost:8080"))
    tgi_model: str = Field(default=os.getenv("TGI_MODEL", "meta-llama/Meta-Llama-3-8B-Instruct"))
    rag_min_citations: int = Field(default=int(os.getenv("RAG_MIN_CITATIONS", 2)))
    rag_freshness_days: int = Field(default=int(os.getenv("RAG_FRESHNESS_DAYS", 60)))
    policy_overlays: List[str] = Field(default_factory=lambda: os.getenv("POLICY_OVERLAYS", "").split(",") if os.getenv("POLICY_OVERLAYS") else [])
    pii_masking: str = Field(default=os.getenv("PII_MASKING", "strict"))
    graph_file: str = Field(default=os.getenv("GRAPH_FILE", "graphs/core.yaml"))
    qdrant_url: str = Field(default=os.getenv("QDRANT_URL", ""))
    qdrant_collection: str = Field(default=os.getenv("QDRANT_COLLECTION", "kb_docs"))
    embed_model: str = Field(default=os.getenv("EMBED_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"))
    class Config:
        env_file = ".env"

settings = Settings()
