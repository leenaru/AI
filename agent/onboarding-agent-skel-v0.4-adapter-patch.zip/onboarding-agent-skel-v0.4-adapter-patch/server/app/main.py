from fastapi import FastAPI
from app.core.logging import setup_logging
from app.core.config import settings

setup_logging("INFO")
app = FastAPI(title="On-device + Server AI – API", version="0.4.1")

@app.get("/healthz")
async def healthz():
    return {"status": "ok", "env": settings.app_env, "backend": settings.llm_backend}
