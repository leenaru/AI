import math
import yaml
from typing import Dict, Any, Tuple
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"  # server/config

def _load_yaml(name: str) -> dict:
    with open(CONFIG_DIR / name, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

_PROFILES = _load_yaml("model_profiles.yaml")
_POLICY = _load_yaml("router_policy.yaml")

def _score_model(req: Dict[str, Any], model: Dict[str, Any], weights: Dict[str, float]) -> float:
    s = 0.0
    req_lang = (req.get("lang") or "en").split("-")[0]
    langs = model.get("langs", [])
    if "*" in langs or req_lang in langs:
        s += weights.get("lang_match", 0.0)
    need_caps = set(req.get("capabilities") or [])
    has_caps = set(model.get("capabilities") or [])
    s += weights.get("capability_match", 0.0) * len(need_caps & has_caps)
    need_ctx = int(req.get("context_need", 4096))
    if int(model.get("max_context", 8192)) >= need_ctx:
        s += weights.get("max_context_need", 0.0)
    cost = float(model.get("cost", 1.0))
    s -= weights.get("cost_penalty", 0.0) * max(cost - 1.0, 0.0)
    return s

def _match_hard_rules(req: Dict[str, Any]) -> Tuple[str, str] | None:
    for rule in _POLICY.get("routing", {}).get("hard_rules", []):
        cond = rule.get("when", {})
        if all(req.get(k) == v for k, v in cond.items()):
            backend_id = rule["prefer"]
            be = next((b for b in _PROFILES.get("backends", []) if b["id"] == backend_id), None)
            if be and be.get("models"):
                return backend_id, be["models"][0]["name"]
    return None

def choose_backend_and_model(req: Dict[str, Any]) -> Dict[str, str]:
    hard = _match_hard_rules(req)
    if hard:
        return {"backend": hard[0], "model": hard[1]}

    weights = _POLICY.get("routing", {}).get("soft_weights", {})
    candidates = []
    for be in _PROFILES.get("backends", []):
        for m in be.get("models", []):
            candidates.append((be["id"], m["name"], _score_model(req, m, weights)))
    candidates.sort(key=lambda x: x[2], reverse=True)

    if candidates:
        be_id, model_name, _ = candidates[0]
        return {"backend": be_id, "model": model_name}

    default_be = _POLICY.get("routing", {}).get("default_backend")
    be = next((b for b in _PROFILES.get("backends", []) if b["id"] == default_be), None)
    if be and be.get("models"):
        return {"backend": default_be, "model": be["models"][0]["name"]}
    return {"backend": "ollama_pool", "model": "llama3:instruct"}
