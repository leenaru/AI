import httpx
from typing import List, Dict, Any
from app.core.config import settings

class TGIAdapter:
    def __init__(self, base: str | None = None):
        self.base = (base or settings.tgi_base_url).rstrip("/")
    async def chat(self, model: str, messages: List[Dict[str, Any]], **kwargs) -> Dict[str, Any]:
        prompt = "\n".join([m.get("content","") for m in messages])
        async with httpx.AsyncClient(timeout=60) as cx:
            r = await cx.post(f"{self.base}/generate", json={"inputs": prompt, "parameters": {}})
            r.raise_for_status(); data = r.json()
            text = data.get("generated_text") or (data[0].get("generated_text") if isinstance(data, list) else "")
            return {"message": {"content": text or ""}}
