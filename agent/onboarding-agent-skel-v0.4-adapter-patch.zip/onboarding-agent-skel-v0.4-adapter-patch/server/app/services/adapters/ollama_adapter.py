import httpx
from typing import List, Dict, Any
from app.core.config import settings

class OllamaAdapter:
    def __init__(self, base: str | None = None):
        self.base = base or settings.ollama_base_url
    async def chat(self, model: str, messages: List[Dict[str, Any]], **kwargs) -> Dict[str, Any]:
        payload = {"model": model or settings.ollama_default_model, "messages": messages}
        async with httpx.AsyncClient(timeout=60) as cx:
            r = await cx.post(f"{self.base}/api/chat", json=payload); r.raise_for_status()
            data = r.json()
            content = (data.get("message") or {}).get("content") or data.get("response") or ""
            return {"message": {"content": content}}
