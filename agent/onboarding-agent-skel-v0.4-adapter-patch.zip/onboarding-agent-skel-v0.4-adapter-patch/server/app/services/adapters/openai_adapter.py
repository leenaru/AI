import httpx
from typing import List, Dict, Any
from app.core.config import settings

class OpenAIAdapter:
    def __init__(self, base: str | None = None, api_key: str | None = None):
        self.base = (base or settings.openai_base_url).rstrip("/")
        self.key  = api_key or settings.openai_api_key
    async def chat(self, model: str, messages: List[Dict[str, Any]], **kwargs) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=60) as cx:
            r = await cx.post(f"{self.base}/chat/completions",
                headers={"Authorization": f"Bearer {self.key}"},
                json={"model": model or settings.openai_model, "messages": messages, "stream": False})
            r.raise_for_status(); data = r.json()
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
            return {"message": {"content": content}}
