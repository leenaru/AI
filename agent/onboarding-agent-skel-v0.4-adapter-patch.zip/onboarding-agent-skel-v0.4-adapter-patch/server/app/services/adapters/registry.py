from typing import Dict
import yaml
from pathlib import Path
from app.services.adapters.ollama_adapter import OllamaAdapter
from app.services.adapters.vllm_adapter import VLLMAdapter
from app.services.adapters.openai_adapter import OpenAIAdapter
from app.services.adapters.tgi_adapter import TGIAdapter

CONFIG_DIR = Path(__file__).resolve().parents[3] / "config"  # server/config

def _load_profiles() -> dict:
    with open(CONFIG_DIR / "model_profiles.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

_PROFILES = _load_profiles()
_CACHE: Dict[str, object] = {}

def get_adapter(backend_id: str | None = None):
    if backend_id is None:
        backend_id = (_PROFILES.get("backends") or [{}])[0].get("id", "ollama_pool")

    if backend_id in _CACHE:
        return _CACHE[backend_id]

    be = next((b for b in _PROFILES.get("backends", []) if b["id"] == backend_id), None)
    if not be:
        be = next((b for b in _PROFILES.get("backends", []) if b["id"] == "ollama_pool"), None)

    t = (be or {}).get("type", "ollama")
    base_url = (be or {}).get("base_url")
    api_key = (be or {}).get("api_key")

    if t == "vllm":
        adapter = VLLMAdapter(base=base_url, api_key=api_key)
    elif t == "openai":
        adapter = OpenAIAdapter(base=base_url, api_key=api_key)
    elif t == "tgi":
        adapter = TGIAdapter(base=base_url)
    else:
        adapter = OllamaAdapter(base=base_url)

    _CACHE[backend_id] = adapter
    return adapter

llm_adapter = get_adapter()
