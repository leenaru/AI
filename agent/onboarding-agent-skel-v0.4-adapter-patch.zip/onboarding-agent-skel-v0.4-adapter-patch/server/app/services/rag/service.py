from typing import List, Dict, Tuple
from datetime import datetime, timedelta
from .memory_store import docstore

def _keyword_score(q: str, text: str) -> int:
    s = 0
    for w in set(q.lower().split()):
        if len(w) >= 2: s += text.lower().count(w)
    return s

class RAGService:
    def __init__(self, min_citations: int = 2, freshness_days: int = 60):
        self.min_citations = min_citations
        self.freshness_days = freshness_days

    def retrieve(self, query: str, products: List[str] | None = None, tags: List[str] | None = None) -> List[Dict]:
        q = query or ""; hits: List[Tuple[int, Dict]] = []
        for d in docstore.all():
            score = _keyword_score(q, d["content"] + " " + d["title"])
            if products and d.get("products") and any(p in d["products"] for p in products): score += 3
            if tags and d.get("tags") and any(t in d["tags"] for t in tags): score += 2
            hits.append((score, d))
        hits.sort(key=lambda x: x[0], reverse=True)
        return [h[1] for h in hits if h[0] > 0][:5]

    def enforce_citations(self, answer: str, retrieved: List[Dict]) -> List[Dict]:
        recent_cut = datetime.now().date() - timedelta(days=self.freshness_days)
        cites = []
        for d in retrieved:
            date = d.get("date")
            if date:
                try:
                    if datetime.fromisoformat(date).date() < recent_cut: continue
                except Exception: pass
            cites.append({"title": d["title"], "url": d.get("url"), "date": d.get("date")})
        if len(cites) < self.min_citations:
            for d in retrieved:
                c = {"title": d["title"], "url": d.get("url"), "date": d.get("date")}
                if c not in cites: cites.append(c)
                if len(cites) >= self.min_citations: break
        return cites[: max(self.min_citations, 2)]

rag = RAGService()
