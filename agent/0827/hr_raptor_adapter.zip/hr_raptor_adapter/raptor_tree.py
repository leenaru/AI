# -*- coding: utf-8 -*-
import os, re, json, argparse, uuid, numpy as np, faiss
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
from tqdm import tqdm
from sentence_transformers import SentenceTransformer
from adapters.model_adapter import build_client

def read_docs(docs_dir):
    docs=[]
    for fn in sorted(os.listdir(docs_dir)):
        if not fn.lower().endswith((".md",".txt")): continue
        text=open(os.path.join(docs_dir,fn),"r",encoding="utf-8").read()
        docs.append({"doc_id":fn,"title":fn,"text":text})
    return docs

def split_chunks(text, chunk_words=120, stride_words=40):
    words=re.findall(r"\S+", text); chunks=[]; i=0; step=max(1, chunk_words-stride_words)
    while i < len(words):
        ch=" ".join(words[i:i+chunk_words]).strip()
        if ch: chunks.append(ch)
        i+=step
    return chunks

@dataclass
class Node:
    node_id: str; level: int; text: str; children: list; parent: str; meta: dict

def summarize(texts, backend, base_url, api_key, model):
    if backend=="none" or not texts:
        head=" ".join(t.split("\n")[0] for t in texts)
        import re as _re; return _re.sub(r"\s+"," ", head)[:400]
    system="Summarize the following into 4-6 sentences (KO or EN), keep procedures and key terms."
    user="\n\n".join(f"- {t[:1200]}" for t in texts)
    client=build_client(backend, base_url, api_key)
    out=client.generate(system, user, model=model, temperature=0.2, max_tokens=256)
    return out.text or texts[0][:400]

class Builder:
    def __init__(self, emb_model="BAAI/bge-m3", branch=6, levels=3, backend="none", base_url="", api_key="", model=""):
        self.emb=SentenceTransformer(emb_model); self.branch=branch; self.levels=levels
        self.backend, self.base_url, self.api_key, self.model = backend, base_url, api_key, model

    def build(self, docs, out_dir, chunk_words=120, stride_words=40):
        os.makedirs(out_dir, exist_ok=True)
        leafs=[]
        for d in docs:
            for ch in split_chunks(d["text"], chunk_words, stride_words):
                leafs.append(Node(node_id=str(uuid.uuid4()), level=0, text=ch, children=[], parent="", meta={"doc_id":d["doc_id"],"title":d["title"]}))
        levels=[leafs]
        for lvl in range(1, self.levels):
            prev=levels[-1]; groups=[prev[i:i+self.branch] for i in range(0,len(prev), self.branch)]; cur=[]
            for g in tqdm(groups, desc=f"Summarizing level {lvl}"):
                s=summarize([n.text for n in g], self.backend, self.base_url, self.api_key, self.model)
                nid=str(uuid.uuid4()); parent=Node(nid, lvl, s, [n.node_id for n in g], "", {"agg_size":len(g)})
                for n in g: n.parent=nid
                cur.append(parent)
            levels.append(cur)
        for lvl, nodes in enumerate(levels):
            open(os.path.join(out_dir, f"nodes_level{lvl}.jsonl"),"w",encoding="utf-8").write("\n".join(json.dumps(asdict(n),ensure_ascii=False) for n in nodes))
            texts=[n.text for n in nodes]; X=self.emb.encode(texts, normalize_embeddings=True, show_progress_bar=True); import numpy as _np
            X=_np.array(X, dtype="float32"); _np.save(os.path.join(out_dir,f"emb_level{lvl}.npy"), X)
            idx=faiss.IndexFlatIP(X.shape[1]); idx.add(X); faiss.write_index(idx, os.path.join(out_dir,f"faiss_level{lvl}.index"))
        json.dump({"levels":self.levels,"branch_factor":self.branch,"emb_model":str(self.emb)}, open(os.path.join(out_dir,"tree_meta.json"),"w",encoding="utf-8"), ensure_ascii=False, indent=2)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--docs_dir", required=True); ap.add_argument("--out_dir", required=True)
    ap.add_argument("--branch_factor", type=int, default=6); ap.add_argument("--levels", type=int, default=3)
    ap.add_argument("--chunk_words", type=int, default=120); ap.add_argument("--stride_words", type=int, default=40)
    ap.add_argument("--emb_model", default="BAAI/bge-m3")
    ap.add_argument("--llm_backend", choices=["none","ollama","openai","vllm","openai_compat","openai-compatible"], default="none")
    ap.add_argument("--llm_model", default=""); ap.add_argument("--llm_base_url", default=""); ap.add_argument("--llm_api_key", default="")
    args=ap.parse_args()
    b=Builder(args.emb_model, args.branch_factor, args.levels, args.llm_backend, args.llm_base_url, args.llm_api_key, args.llm_model)
    b.build(read_docs(args.docs_dir), args.out_dir, args.chunk_words, args.stride_words)
