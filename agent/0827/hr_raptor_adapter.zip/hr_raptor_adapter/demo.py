# -*- coding: utf-8 -*-
import argparse, json
from typing import List
from sentence_transformers import CrossEncoder
from retrieval_pipeline import HierarchicalRetriever
from selfrag_gating import selfrag_gate
from adapters.model_adapter import build_client

def optimize_bs(pairs: List[List[str]], max_bs=64):
    avg=sum(len(a)+len(b) for a,b in pairs)/max(1,len(pairs))
    return 8 if avg>4000 else 16 if avg>2000 else 32 if avg>1000 else min(64,max_bs)

def run(args):
    gate={"need_search":True,"k":8,"rewrites":[args.query]}
    if args.use_selfrag:
        gate=selfrag_gate(args.query, backend=args.selfrag_backend, llm_model=args.llm_model, llm_base_url=args.llm_base_url, llm_api_key=args.llm_api_key)
    print("[Self-RAG Gate]", json.dumps(gate, ensure_ascii=False))

    retr=HierarchicalRetriever(args.artifacts)
    if not gate["need_search"]:
        print("검색 생략."); return

    all_hits={}
    for q in gate["rewrites"]:
        for idx,score in retr.search(q, top_sections=args.top_sections, top_leaf=gate.get("k", args.top_leaf)):
            all_hits[idx]=max(all_hits.get(idx,0.0), score)
    topN=sorted(all_hits.items(), key=lambda x:x[1], reverse=True)[:gate.get("k", args.top_leaf)]
    leafs=[{"idx":i,"text":retr.get_leaf(i)["text"],"score":s} for i,s in topN]

    if args.use_cross and leafs:
        pairs=[[args.query, L["text"]] for L in leafs]; bs=optimize_bs(pairs)
        ce=CrossEncoder(args.cross_model); ce_scores=ce.predict(pairs, batch_size=bs)
        for L,s in zip(leafs, ce_scores): L["ce_score"]=float(s)
        leafs=sorted(leafs, key=lambda x:x.get("ce_score",0.0), reverse=True)

    print("\n=== 최종 후보 문단 ===")
    for r,L in enumerate(leafs,1):
        print(f"#{r} idx={L['idx']} rrf={L['score']:.4f} ce={L.get('ce_score','-')}")
        print("  ", (L["text"][:300]+('...' if len(L['text'])>300 else '')))

    if args.do_generate and leafs:
        ctx="\n\n".join(f"- {L['text']}" for L in leafs)
        system="You are a helpful assistant. Answer in Korean with citations from bullets."
        user=f"질문: {args.query}\n\n근거:\n{ctx}\n\n한국어로 정확하게 답하세요."
        client=build_client(args.gen_backend, args.llm_base_url, args.llm_api_key)
        out=client.generate(system, user, model=args.llm_model, temperature=0.2, max_tokens=512)
        print("\n=== 생성 답변(데모) ===\n", out.text)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--artifacts", required=True); ap.add_argument("--query", required=True)
    ap.add_argument("--top_sections", type=int, default=5); ap.add_argument("--top_leaf", type=int, default=20)
    ap.add_argument("--use_selfrag", action="store_true"); ap.add_argument("--selfrag_backend", choices=["heuristic","ollama","openai"], default="heuristic")
    ap.add_argument("--llm_model", default=""); ap.add_argument("--llm_base_url", default=""); ap.add_argument("--llm_api_key", default="")
    ap.add_argument("--use_cross", action="store_true"); ap.add_argument("--cross_model", default="cross-encoder/ms-marco-MiniLM-L-6-v2")
    ap.add_argument("--do_generate", action="store_true"); ap.add_argument("--gen_backend", choices=["ollama","openai","heuristic"], default="ollama")
    args=ap.parse_args(); run(args)
