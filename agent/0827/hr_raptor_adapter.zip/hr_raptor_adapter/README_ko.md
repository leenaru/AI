# 계층형 Retrieval + RAPTOR + Self-RAG + Cross-리랭커 (Ollama/vLLM 어댑터)

설치: `pip install -r requirements.txt`

요약 트리:
```
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120 --llm_backend none
# Ollama
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120   --llm_backend ollama --llm_model llama3:instruct --llm_base_url http://127.0.0.1:11434
# vLLM(OpenAI 호환)
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120   --llm_backend openai --llm_model qwen2.5-7b-instruct   --llm_base_url http://127.0.0.1:8000/v1 --llm_api_key sk-xxx
```

질의 실행:
```
python demo.py --artifacts ./artifacts --query "E23 오류..."   --use_selfrag --selfrag_backend heuristic   --use_cross --cross_model cross-encoder/ms-marco-MiniLM-L-6-v2
```
