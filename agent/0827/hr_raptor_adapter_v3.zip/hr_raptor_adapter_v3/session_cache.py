# -*- coding: utf-8 -*-
import time, hashlib
from typing import Any, Dict, Optional

class SessionCache:
    def __init__(self, ttl_sec: int = 600, max_items: int = 512):
        self.ttl = ttl_sec; self.max_items = max_items; self.store: Dict[str, Any] = {}
    def _now(self): return int(time.time())
    def _key(self, q: str) -> str: return hashlib.sha1(q.strip().encode('utf-8')).hexdigest()
    def get(self, query: str) -> Optional[Dict]:
        k = self._key(query); v = self.store.get(k)
        if not v: return None
        if self._now() - v["ts"] > self.ttl: del self.store[k]; return None
        return v["val"]
    def set(self, query: str, value: Dict):
        if len(self.store) >= self.max_items:
            old_k = min(self.store.keys(), key=lambda kk: self.store[kk]["ts"]); self.store.pop(old_k, None)
        self.store[self._key(query)] = {"ts": self._now(), "val": value}
