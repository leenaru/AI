# 계층형 Retrieval + RAPTOR + Self-RAG + Cross-리랭커 (Ollama/vLLM 어댑터, 튜너/HyDE/캐시/정책)

## 설치
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 1) 요약 트리 생성 (RAPTOR)
```bash
# LLM 미사용(간이 요약)
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120 --llm_backend none

# Ollama
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120   --llm_backend ollama --llm_model llama3:instruct --llm_base_url http://127.0.0.1:11434

# vLLM(OpenAI-호환)
python raptor_tree.py --docs_dir ./sample_docs --out_dir ./artifacts   --branch_factor 6 --levels 3 --chunk_words 120   --llm_backend openai --llm_model qwen2.5-7b-instruct   --llm_base_url http://127.0.0.1:8000/v1 --llm_api_key sk-xxx
```

## 2) 하이브리드 가중치 튜너(Grid/Hyperband)
```bash
python tuner.py --artifacts ./artifacts --eval_file ./eval_set.jsonl --out_file tuner_results.json
# demo.py 실행 시 튜너 결과 자동 반영(method/weights)
```

## 3) 질의 실행 (게이트+HR+HyDE/다중질의+캐시+Cross-리랭크)
```bash
python demo.py --artifacts ./artifacts   --query "E23 오류로 Wi-Fi 페어링이 중단될 때 어떻게 재시도하나요?"   --use_selfrag --selfrag_backend heuristic   --use_hyde --multiquery_n 2   --use_cache --cache_ttl 600   --fusion weighted --dense_w 0.6 --bm25_w 0.4   --use_cross --cross_model cross-encoder/ms-marco-MiniLM-L-6-v2
```

## 4) 생성 + 안전 라우팅(국가별 정책) + 툴 프롬프트(OpenAI-호환)
```bash
python demo.py --artifacts ./artifacts   --query "E23 오류..."   --use_selfrag --selfrag_backend openai   --llm_model qwen2.5-7b-instruct --llm_base_url http://127.0.0.1:8000/v1 --llm_api_key sk-xxx   --use_hyde --multiquery_n 2 --use_cache   --do_generate --gen_backend openai   --policy_overlays ./policies/policy_overlays.yaml --country_code KR
```
