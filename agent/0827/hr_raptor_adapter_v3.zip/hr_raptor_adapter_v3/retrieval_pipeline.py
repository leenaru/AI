# -*- coding: utf-8 -*-
import os, re, json, argparse, numpy as np, faiss
from typing import List, Dict, Any, Tuple
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer, CrossEncoder

def load_nodes(p): return [json.loads(l) for l in open(p,"r",encoding="utf-8")]
def rrf_fuse(rank_lists, k=60):
    s={}
    for ranks in rank_lists:
        for r, idx in enumerate(ranks): s[idx]=s.get(idx,0.0)+1.0/(k+r+1)
    return s
def zscore(scores: Dict[int, float]) -> Dict[int, float]:
    if not scores: return scores
    vals = np.array(list(scores.values()), dtype="float32")
    mu, std = vals.mean(), (vals.std() or 1.0)
    return {k: (v - mu) / std for k,v in scores.items()}

class HierarchicalRetriever:
    def __init__(self, artifacts_dir, emb_model="BAAI/bge-m3"):
        self.dir=artifacts_dir; self.emb=SentenceTransformer(emb_model)
        meta=json.load(open(os.path.join(self.dir,"tree_meta.json"),"r",encoding="utf-8"))
        self.levels=meta["levels"]; self.level_nodes=[]; self.level_embs=[]; self.level_idx=[]
        for lvl in range(self.levels):
            self.level_nodes.append(load_nodes(os.path.join(self.dir,f"nodes_level{lvl}.jsonl")))
            X=np.load(os.path.join(self.dir,f"emb_level{lvl}.npy")); self.level_embs.append(X)
            self.level_idx.append(faiss.read_index(os.path.join(self.dir,f"faiss_level{lvl}.index")))
        self.leaf_texts=[n["text"] for n in self.level_nodes[0]]
        toks=[re.findall(r"\w+", t.lower()) for t in self.leaf_texts]; self.bm25=BM25Okapi(toks)

    def search(self, query, top_sections=5, top_leaf=20, fusion="rrf", dense_w=0.5, bm25_w=0.5):
        qv=self.emb.encode([query], normalize_embeddings=True).astype("float32")
        cur_ids=None
        for lvl in reversed(range(1,self.levels)):
            D,I=self.level_idx[lvl].search(qv, top_sections); cand=set(I[0].tolist())
            child_ids=set(); cmap={n["node_id"]:i for i,n in enumerate(self.level_nodes[lvl-1])}
            for idx in cand:
                node=self.level_nodes[lvl][idx]
                for ch in node["children"]:
                    if ch in cmap: child_ids.add(cmap[ch])
            cur_ids=list(child_ids)
        if not cur_ids: cur_ids=list(range(len(self.level_nodes[0])))

        # Dense on leaf subset
        leaf_X=self.level_embs[0]; sub=leaf_X[cur_ids]
        idx_tmp=faiss.IndexFlatIP(sub.shape[1]); idx_tmp.add(sub)
        D2,I2=idx_tmp.search(qv, min(top_leaf*5, len(cur_ids)))
        dense_rank=[cur_ids[i] for i in I2[0].tolist()]
        dense_scores={dense_rank[i]: float(D2[0][i]) for i in range(len(dense_rank))}

        # BM25 on leaf subset
        toks=re.findall(r"\w+", query.lower()); bm_scores=self.bm25.get_scores(toks)
        bm_pairs=[(i,bm_scores[i]) for i in cur_ids]
        bm_rank=[i for i,_ in sorted(bm_pairs, key=lambda x:x[1], reverse=True)][:min(top_leaf*5, len(cur_ids))]
        bm_sel_scores={i: float([v for j,v in bm_pairs if j==i][0]) for i in bm_rank]

        if fusion=="rrf":
            fused=rrf_fuse([dense_rank, bm_rank], k=60)
        else:
            dz=zscore(dense_scores); bz=zscore(bm_sel_scores)
            keys=set(list(dz.keys())+list(bz.keys()))
            fused={k: dense_w*dz.get(k,0.0)+bm25_w*bz.get(k,0.0) for k in keys}

        fused_rank=[i for i,_ in sorted(fused.items(), key=lambda x:x[1], reverse=True)][:min(top_leaf, len(fused))]
        return [(i,fused[i]) for i in fused_rank]

    def get_leaf(self, idx): return self.level_nodes[0][idx]
