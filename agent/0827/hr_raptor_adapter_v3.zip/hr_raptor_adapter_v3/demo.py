# -*- coding: utf-8 -*-
import argparse, json, os
from typing import List
from sentence_transformers import CrossEncoder
from retrieval_pipeline import HierarchicalRetriever
from selfrag_gating import selfrag_gate
from hyde_multiquery import hyde_generate
from session_cache import SessionCache
from adapters.model_adapter import build_client, SafetyRouter

def optimize_bs(pairs: List[List[str]], max_bs=64):
    avg=sum(len(a)+len(b) for a,b in pairs)/max(1,len(pairs))
    return 8 if avg>4000 else 16 if avg>2000 else 32 if avg>1000 else min(64,max_bs)

def run(args):
    cache = SessionCache(ttl_sec=args.cache_ttl)
    # 1) 게이트 + 임계값
    gate = {"need_search": True, "k": args.top_leaf, "rewrites": [args.query]}
    if args.use_selfrag:
        g = selfrag_gate(args.query, backend=args.selfrag_backend,
                         llm_model=args.llm_model, llm_base_url=args.llm_base_url, llm_api_key=args.llm_api_key)
        if args.gate_threshold is not None and isinstance(g.get("k",0), int):
            g["need_search"] = (g["k"] >= args.gate_threshold)
        gate = g
    print("[Self-RAG Gate]", json.dumps(gate, ensure_ascii=False))

    # HyDE/다중 질의
    rewrites = list(gate.get("rewrites", []))
    if args.use_hyde:
        hy = hyde_generate(args.query, backend=args.selfrag_backend if args.selfrag_backend!="heuristic" else "heuristic",
                           model=args.llm_model, base_url=args.llm_base_url, api_key=args.llm_api_key, n=args.multiquery_n)
        rewrites.extend(hy)
    rewrites = list(dict.fromkeys([w.strip() for w in rewrites if w.strip()]))

    # 2) 검색 (세션 캐시)
    retr = HierarchicalRetriever(args.artifacts)
    cache_key = "|".join(sorted(rewrites))
    results = cache.get(cache_key) if args.use_cache else None
    if not results:
        if not gate["need_search"]:
            print("검색 생략. (여기서 바로 생성 LLM 호출)")
            results = []
        else:
            all_hits = {}
            for q in rewrites:
                hits = retr.search(q, top_sections=args.top_sections, top_leaf=gate.get("k", args.top_leaf),
                                   fusion=args.fusion, dense_w=args.dense_w, bm25_w=args.bm25_w)
                for idx, score in hits:
                    all_hits[idx] = max(all_hits.get(idx, 0.0), score)
            topN = sorted(all_hits.items(), key=lambda x: x[1], reverse=True)[:gate.get("k", args.top_leaf)]
            results = [{"idx": i, "text": retr.get_leaf(i)["text"], "score": s} for i, s in topN]
            if args.use_cache: cache.set(cache_key, results)

    # 3) Cross-리랭크
    leafs = results
    if args.use_cross and leafs:
        pairs = [[args.query, L["text"]] for L in leafs]
        bs = optimize_bs(pairs)
        ce = CrossEncoder(args.cross_model)
        ce_scores = ce.predict(pairs, batch_size=bs)
        for L, s in zip(leafs, ce_scores): L["ce_score"] = float(s)
        leafs = sorted(leafs, key=lambda x: x.get("ce_score", 0.0), reverse=True)

    print("\n=== 최종 후보 문단 ===")
    for r, L in enumerate(leafs, 1):
        print(f"#{r} idx={L['idx']} score={L['score']:.4f} ce={L.get('ce_score','-')}")
        print("  ", (L["text"][:300] + ('...' if len(L['text'])>300 else '')))

    # 4) 생성 + 정책 오버레이 + 툴 프롬프트(OpenAI-호환)
    if args.do_generate and leafs:
        ctx = "\n\n".join([f"- {L['text']}" for L in leafs])
        safety = SafetyRouter(args.policy_overlays)
        sys_prefix = safety.system_prefix(args.country_code)
        blocked = safety.blocked_tools(args.country_code)
        system = (sys_prefix + "\n\n" if sys_prefix else "") + "You are a helpful assistant. Answer in Korean with citations from bullets."
        user = f"질문: {args.query}\n\n근거:\n{ctx}\n\n한국어로 정확하게 답하세요."
        client = build_client(args.gen_backend, args.llm_base_url, args.llm_api_key)

        tools = [{
            "type": "function",
            "function": {
                "name": "open_url",
                "description": "Open a reference URL (viewer)",
                "parameters": {"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}
            }
        }]
        tools = [t for t in tools if t.get("function",{}).get("name") not in blocked]

        resp = client.generate(system, user, model=args.llm_model, temperature=0.2, max_tokens=512,
                               tools=tools, tool_choice="auto")
        print("\n=== 생성 답변(데모) ===\n", resp.text)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifacts", required=True)
    ap.add_argument("--query", required=True)
    ap.add_argument("--top_sections", type=int, default=5)
    ap.add_argument("--top_leaf", type=int, default=20)

    # Fusion/tuning
    ap.add_argument("--fusion", choices=["rrf","weighted"], default="rrf")
    ap.add_argument("--dense_w", type=float, default=0.5)
    ap.add_argument("--bm25_w", type=float, default=0.5)

    # Gate & cache & hyde
    ap.add_argument("--use_selfrag", action="store_true")
    ap.add_argument("--selfrag_backend", choices=["heuristic","ollama","openai"], default="heuristic")
    ap.add_argument("--gate_threshold", type=int, default=None)
    ap.add_argument("--use_cache", action="store_true")
    ap.add_argument("--cache_ttl", type=int, default=600)
    ap.add_argument("--use_hyde", action="store_true")
    ap.add_argument("--multiquery_n", type=int, default=2)

    # LLM config
    ap.add_argument("--llm_model", default="")
    ap.add_argument("--llm_base_url", default="")
    ap.add_argument("--llm_api_key", default="")

    # Cross rerank
    ap.add_argument("--use_cross", action="store_true")
    ap.add_argument("--cross_model", default="cross-encoder/ms-marco-MiniLM-L-6-v2")

    # Generation & safety overlays
    ap.add_argument("--do_generate", action="store_true")
    ap.add_argument("--gen_backend", choices=["ollama","openai","heuristic"], default="ollama")
    ap.add_argument("--policy_overlays", default="./policies/policy_overlays.yaml")
    ap.add_argument("--country_code", default="KR")

    args = ap.parse_args()
    # 튜너 결과 자동 반영
    tuner_file = os.path.join(os.getcwd(), "tuner_results.json")
    if os.path.exists(tuner_file) and args.fusion == "rrf":
        try:
            best = json.load(open(tuner_file,"r",encoding="utf-8"))
            args.fusion = best.get("method", args.fusion)
            args.dense_w = float(best.get("dense_w", args.dense_w))
            args.bm25_w = float(best.get("bm25_w", args.bm25_w))
            print("[Tuner] Using best:", best)
        except Exception:
            pass
    run(args)

if __name__ == "__main__":
    main()
