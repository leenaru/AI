# -*- coding: utf-8 -*-
import os, json, argparse
from typing import List, Dict, Any
from retrieval_pipeline import HierarchicalRetriever

def eval_sample(retr: HierarchicalRetriever, sample: Dict[str, Any], dense_w: float, bm25_w: float, method: str) -> int:
    hits = retr.search(sample["query"], top_sections=5, top_leaf=20, fusion=method, dense_w=dense_w, bm25_w=bm25_w)
    if not hits: return 0
    top_idx = hits[0][0]
    text = retr.get_leaf(top_idx)["text"].lower()
    return int(any(kw.lower() in text for kw in sample.get("keywords", [])))

def grid_search(retr, evalset, alphas: List[float], methods: List[str]):
    best = {"score": -1, "dense_w": 0.5, "bm25_w": 0.5, "method": "rrf"}
    for m in methods:
        for a in alphas:
            dw, bw = a, 1.0 - a
            total = sum(eval_sample(retr, s, dw, bw, m) for s in evalset)
            if total > best["score"]:
                best = {"score": total, "dense_w": dw, "bm25_w": bw, "method": m}
    return best

def hyperband(retr, evalset):
    coarse = [0.0, 0.25, 0.5, 0.75, 1.0]
    methods = ["rrf","weighted"]
    best = grid_search(retr, evalset, coarse, methods)
    a = best["dense_w"]
    fine = sorted(set([max(0.0, a - 0.2), max(0.0, a - 0.1), a, min(1.0, a + 0.1), min(1.0, a + 0.2)]))
    best2 = grid_search(retr, evalset, fine, [best["method"]])
    return best2 if best2["score"] >= best["score"] else best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifacts", required=True)
    ap.add_argument("--eval_file", default="eval_set.jsonl")
    ap.add_argument("--out_file", default="tuner_results.json")
    args = ap.parse_args()
    retr = HierarchicalRetriever(args.artifacts)
    evalset = [json.loads(l) for l in open(args.eval_file,"r",encoding="utf-8")]
    best = hyperband(retr, evalset)
    json.dump(best, open(args.out_file,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
    print("[BEST]", best)

if __name__ == "__main__":
    main()
