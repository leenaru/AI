# -*- coding: utf-8 -*-
import re, json
from adapters.model_adapter import build_client

SYS=("You are a retrieval planner. Return STRICT JSON: {need_search: bool, k: int, rewrites: [str,...]}. "
     "If outdated/name/version/code/link/procedure or verification is needed, need_search=true. k in [3,12].")

def _parse_json(text):
    m=re.search(r"\{.*\}", text, flags=re.S)
    if not m: return None
    try: return json.loads(m.group(0))
    except: return None

def heuristic(query):
    triggers=["error","오류","버전","version","E2","E3","E23","Wi-Fi","최신","link","URL","절차","코드"]
    need=any(t.lower() in query.lower() for t in triggers) or bool(re.search(r"\b\d{2,}\b", query))
    k=6 if need else 0; rw=[query]
    tokens=re.findall(r"[A-Za-z0-9\-]+", query)[:6]
    if tokens and need: rw.append(" ".join(tokens))
    return {"need_search":need,"k":k,"rewrites":rw}

def selfrag_gate(query, backend="heuristic", llm_model="", llm_base_url="", llm_api_key=""):
    b=(backend or "heuristic").lower()
    if b=="heuristic": return heuristic(query)
    client=build_client("ollama" if b=="ollama" else "openai", llm_base_url, llm_api_key)
    user=f"Query: {query}\nReturn JSON ONLY."
    try:
        out=client.generate(SYS, user, model=llm_model, temperature=0.2, max_tokens=128, response_format="json_object")
        data=_parse_json(out.text) or heuristic(query)
        if not isinstance(data.get("rewrites",[]), list): data["rewrites"]=[query]
        data.setdefault("k",6); data.setdefault("need_search", True); return data
    except Exception: return heuristic(query)
