# -*- coding: utf-8 -*-
from typing import List
from adapters.model_adapter import build_client

HYDE_SYS = (
    "You generate hypothetical passages that would answer the query. "
    "Return 1-3 concise bullet paragraphs (KO or EN)."
)

def hyde_generate(query: str, backend: str, model: str, base_url: str, api_key: str, n: int = 2) -> List[str]:
    if backend == "heuristic" or not model:
        return [query, query.replace("오류","에러").replace("error","issue")]
    client = build_client("ollama" if backend=="ollama" else "openai", base_url, api_key)
    user = f"Query: {query}\nWrite {n} bullets."
    resp = client.generate(HYDE_SYS, user, model=model, temperature=0.3, max_tokens=256)
    txt = resp.text.strip()
    lines = [l.strip("-• ").strip() for l in txt.splitlines() if l.strip()]
    out = [l for l in lines if len(l) > 3][:max(1,n)]
    return out or [query]
