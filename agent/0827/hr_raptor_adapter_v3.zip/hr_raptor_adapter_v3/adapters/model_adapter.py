# -*- coding: utf-8 -*-
import os, json, requests, yaml
from typing import Optional, Dict, Any, List

class LLMResponse:
    def __init__(self, text: str, raw=None): self.text, self.raw = text, (raw or {})

class BaseLLM:
    def generate(self, system: Optional[str], user: str, model: str, **kw) -> LLMResponse:
        raise NotImplementedError

class OllamaClient(BaseLLM):
    def __init__(self, base_url="http://127.0.0.1:11434"): self.base_url = base_url.rstrip("/")
    def generate(self, system, user, model, **kw):
        prompt = (f"[System]\n{system}\n\n" if system else "") + f"[User]\n{user}"
        body = {"model": model, "prompt": prompt, "stream": False}
        if "temperature" in kw: body["options"]={"temperature":kw["temperature"]}
        if "max_tokens" in kw: body["max_tokens"]=kw["max_tokens"]
        r = requests.post(f"{self.base_url}/api/generate", json=body, timeout=120); r.raise_for_status()
        j = r.json(); return LLMResponse(j.get("response","").strip(), j)

class OpenAICompatClient(BaseLLM):
    def __init__(self, base_url, api_key=""):
        self.base_url, self.api_key = base_url.rstrip("/"), api_key or os.getenv("OPENAI_API_KEY","")
    def generate(self, system, user, model, **kw):
        headers={"Content-Type":"application/json"}; 
        if self.api_key: headers["Authorization"]=f"Bearer {self.api_key}"
        msgs=[]; 
        if system: msgs.append({"role":"system","content":system})
        msgs.append({"role":"user","content":user})
        body={"model":model,"messages":msgs,"temperature":kw.get("temperature",0.2)}
        if kw.get("response_format")=="json_object": body["response_format"]={"type":"json_object"}
        if "max_tokens" in kw: body["max_tokens"]=kw["max_tokens"]
        # tools/tool_choice passthrough
        if "tools" in kw and kw["tools"]:
            body["tools"] = kw["tools"]
            if "tool_choice" in kw: body["tool_choice"] = kw["tool_choice"]
        r = requests.post(f"{self.base_url}/chat/completions", json=body, headers=headers, timeout=120); r.raise_for_status()
        j=r.json(); text=j.get("choices",[{}])[0].get("message",{}).get("content","") or ""
        return LLMResponse(text.strip(), j)

def build_client(backend: str, base_url: str="", api_key: str=""):
    b=(backend or "none").lower()
    if b=="ollama": return OllamaClient(base_url or "http://127.0.0.1:11434")
    if b in ("openai","vllm","openai_compat","openai-compatible"): return OpenAICompatClient(base_url or "http://127.0.0.1:8000/v1", api_key)
    class NullClient(BaseLLM):
        def generate(self, system, user, model, **kw): return LLMResponse("")
    return NullClient()

class SafetyRouter:
    def __init__(self, overlays_path: str = ""):
        self.data = {}
        if overlays_path and os.path.exists(overlays_path):
            with open(overlays_path,"r",encoding="utf-8") as f:
                self.data = yaml.safe_load(f) or {}
    def system_prefix(self, country_code: str) -> str:
        cc=(country_code or "KR").upper(); node=self.data.get(cc, {})
        return node.get("system_prefix","")
    def blocked_tools(self, country_code: str):
        cc=(country_code or "KR").upper(); node=self.data.get(cc, {})
        return set(node.get("blocked_tools",[]) or [])
    def safe_topics(self, country_code: str):
        cc=(country_code or "KR").upper(); node=self.data.get(cc, {})
        return node.get("safe_topics",[]) or []

def tool_message_for_openai(tools: list) -> dict:
    return {"tools": tools, "tool_choice": "auto"}
