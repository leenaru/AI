# Air Conditioner Wi-Fi Setup

E23 indicates AP isolation. Reboot router, disable WPS, retry.
