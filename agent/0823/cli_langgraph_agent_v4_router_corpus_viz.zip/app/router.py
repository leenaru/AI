from __future__ import annotations
import os, re, yaml
from typing import Literal, Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState, Intent

RULES_PATH = os.getenv("ROUTING_RULES", os.path.join(os.path.dirname(__file__), "../data/routing/rules.yaml"))

def get_llm():
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=False)

def _load_rules() -> Dict[str, Any]:
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {"labels": {}}

def rules_score(text: str) -> Intent:
    cfg = _load_rules()
    labels = cfg.get("labels", {})
    w = cfg.get("weights", {"keyword":1.0, "regex":2.0, "bonus_all":0.5})
    threshold = float(cfg.get("threshold", 1.0))
    best_label = "other"
    best_score = 0.0
    t = text.lower()
    for label, spec in labels.items():
        score = 0.0
        kws = [k.lower() for k in spec.get("keywords", [])]
        if kws:
            hit_any = False
            for k in kws:
                if k in t:
                    score += w.get("keyword",1.0)
                    hit_any = True
            if hit_any and len(kws) > 1:
                score += w.get("bonus_all",0.5)
        for pattern in spec.get("regex", []):
            try:
                if re.search(pattern, text, re.IGNORECASE):
                    score += w.get("regex",2.0)
            except re.error:
                pass
        if score > best_score:
            best_score = score
            best_label = label
    if best_score >= threshold:
        return best_label  # type: ignore
    return "other"

SMART_SYS = SystemMessage(content=(
    "You are a smart intent classifier for a multi-agent system (doctor, travel, movie, other). "
    "Read the user's Korean/English message and return strict JSON: {\"intent\":\"doctor|travel|movie|other\",\"confidence\":0.0-1.0}. "
    "Guidelines: medical symptoms/diagnosis/medications -> doctor; trip planning/itineraries/countries/dates -> travel; "
    "film preferences/tickets -> movie; else other. Prefer 'doctor' if symptoms/medications predominate, 'travel' if destinations/dates predominate."
))

def smart_llm_route(text: str) -> Intent:
    llm = get_llm()
    out = llm.invoke([SMART_SYS, HumanMessage(content=text)]).content.strip()
    # best-effort JSON parse
    import json, re
    m = re.search(r"\{[\s\S]*\}", out)
    label = "other"
    if m:
        try:
            data = json.loads(m.group(0))
            cand = (data.get("intent") or "").lower()
            if cand in ("doctor","travel","movie","other"):
                label = cand
        except Exception:
            pass
    else:
        # fallback to simple label
        s = out.lower()
        for cand in ("doctor","travel","movie","other"):
            if cand in s:
                label = cand; break
    return label  # type: ignore

def route_node(state: AgentState) -> AgentState:
    if state.get("intent_locked") and state.get("intent"):
        return state
    last = state["messages"][-1]
    user_txt = last.content if hasattr(last, "content") else str(last)

    mode = os.getenv("ROUTER_MODE", "hybrid")  # rules | llm | hybrid
    if mode == "rules":
        intent: Intent = rules_score(user_txt)
        out = dict(state); out["intent"] = intent; return out
    elif mode == "llm":
        intent = smart_llm_route(user_txt)
        out = dict(state); out["intent"] = intent; return out
    else:
        # hybrid: rules 우선, 미달이면 LLM
        intent = rules_score(user_txt)
        if intent == "other":
            intent = smart_llm_route(user_txt)
        out = dict(state); out["intent"] = intent; return out

def branch(state: AgentState) -> Literal["doctor_collect","travel_collect","movie_collect","other"]:
    it = state.get("intent","other")
    if it == "doctor": return "doctor_collect"
    if it == "travel": return "travel_collect"
    if it == "movie": return "movie_collect"
    return "other"
