from __future__ import annotations
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def _key(it: Retrieved) -> str:
    return (it.url or "") + "|" + (it.title or "") + "|" + (it.text[:32] if it.text else "")

def _normalize(items: List[Retrieved]) -> Dict[str, float]:
    if not items: return {}
    vals = [it.score for it in items]
    lo, hi = min(vals), max(vals)
    norm = {}
    for it in items:
        if hi > lo:
            norm[_key(it)] = (it.score - lo) / (hi - lo)
        else:
            norm[_key(it)] = 0.0
    return norm

def fuse_weighted(faiss: List[Retrieved], bm25: List[Retrieved], graphrag: List[Retrieved], w_f=0.5, w_b=0.3, w_g=0.2, topn: int = 6) -> List[Retrieved]:
    fused, _ = fuse_weighted_debug(faiss, bm25, graphrag, w_f, w_b, w_g, topn)
    return fused

def fuse_weighted_debug(faiss: List[Retrieved], bm25: List[Retrieved], graphrag: List[Retrieved], w_f=0.5, w_b=0.3, w_g=0.2, topn: int = 6) -> Tuple[List[Retrieved], Dict[str, Dict[str, float]]]:
    nf, nb, ng = _normalize(faiss), _normalize(bm25), _normalize(graphrag)
    pool: Dict[str, Retrieved] = {}
    debug: Dict[str, Dict[str, float]] = {}
    for lst in (faiss, bm25, graphrag):
        for it in lst:
            k = _key(it); pool[k] = it
    for k in pool.keys():
        f, b, g = nf.get(k,0.0), nb.get(k,0.0), ng.get(k,0.0)
        final = w_f*f + w_b*b + w_g*g
        debug[k] = {"faiss": f, "bm25": b, "graph": g, "final": final}
    ranked = sorted(pool.values(), key=lambda it: debug[_key(it)]["final"], reverse=True)[:topn]
    return ranked, debug
