# CLI 기반 멀티‑역할 AI Agent (LangChain + LangGraph)

> **요약**
> - 하나의 루트 Agent 안에 **의사/여행사/영화 추천** 서브에이전트를 **LangGraph 분기/서브그래프/체크포인트**로 구성했습니다.  
> - **로컬 LLM(Ollama)** 를 통해 **스트리밍 출력**을 지원합니다.  
> - **RAG**: 도메인별 **FAISS**(로컬 인덱스) + (옵션) **Microsoft GraphRAG** 결과를 **RRF** 방식으로 융합. **문장별 출처 표기**를 합니다.  
> - 완전한 **오픈소스 스택**만 사용합니다.

## 설치

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3:8b   # 또는 qwen2.5:7b 등
```

## 실행

```bash
export OLLAMA_MODEL=llama3:8b
export USE_GRAPHRAG=0                 # 1이면 GraphRAG 융합
export GRAPHRAG_MODE=http             # http | cli
export GRAPHRAG_URL=http://localhost:8010/query
export GRAPHRAG_CLI="python -m graphrag.query"
export CHECKPOINT_DB=.checkpoints/agent.db

python -m app.main --session demo
```

## 구조
```
app/
  main.py
  state.py
  router.py
  agents/
    doctor.py
    travel.py
    movie.py
  rag/
    faiss_store.py
    graphrag_client.py
  utils/
    streaming.py
    citation.py
data/
  docs/
    medical/*.md
    travel/*.md
  movies.json
requirements.txt
```


---

## v3 확장 사항
- **BM25** 인덱스 추가(`rank-bm25`) 및 **FAISS + BM25 + GraphRAG 가중 융합**:
  - 가중치: `HYBRID_WEIGHTS="faiss:0.5,bm25:0.3,graph:0.2"` (CLI `--weights`로 덮어쓰기)
  - 검색 모드: `--retriever faiss|graphrag|hybrid` (hybrid가 기본)
- **슬롯 검증기**: 나이/성별/기간/날짜/장르/러닝타임 등 **정규화 & 검사** 후 **오류/누락**을 바탕으로 **질문 생성**
- **국가별 정책 오버레이(YAML)**: `data/policies/{KR,JP,AU}.yaml` 예제 포함
  - 의료/여행/영화 등급 가이드라인을 **답변 문맥에 삽입**
- **CLI 옵션**
  ```bash
  python -m app.main --session demo --retriever hybrid --weights "faiss:0.6,bm25:0.25,graph:0.15" --overlay KR
  ```


---

## v4 확장 사항
1) **라우팅 확장**
   - `data/routing/rules.yaml` 기반의 **키워드/정규식 규칙** 라우터(`ROUTER_MODE=rules`)
   - **스마트 LLM 라우터**(JSON 반환) (`ROUTER_MODE=llm`)
   - **하이브리드**: 규칙 점수가 임계치 미만이면 LLM로 보완 (`ROUTER_MODE=hybrid`, 기본값)
   - 규칙 파일은 YAML로 손쉽게 **추가/삭제** 가능

2) **국가 정책 오버레이 확장**
   - KR/JP/AU + **US/GB/SG** 예시 추가 (`data/policies/*.yaml`)

3) **문서 코퍼스 확장**
   - 의료: `covid19.md`, `otc_cough.md`
   - 여행: `uk_london.md`, `fr_paris.md`, `us_nyc.md`

4) **BM25 토크나이저 교체**
   - `BM25_TOKENIZER=ngram`(기본) → 한글 등 CJK에 **2/3-gram** + 영문 **단어 토큰** 혼합
   - `BM25_TOKENIZER=simple` → 기존 단어 토큰 방식

5) **신뢰도 스코어링 시각화**
   - `VIS_CONFIDENCE=1` 설정 시, **Rich 테이블**로 FAISS/BM25/GraphRAG/최종 스코어(정규화) 시각화

### 실행 예시
```bash
export ROUTER_MODE=hybrid
export BM25_TOKENIZER=ngram
export VIS_CONFIDENCE=1
export HYBRID_WEIGHTS="faiss:0.6,bm25:0.25,graph:0.15"
python -m app.main --session demo --retriever hybrid --overlay JP
```
