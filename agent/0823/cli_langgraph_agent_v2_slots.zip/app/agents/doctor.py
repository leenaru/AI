from __future__ import annotations
import os
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.rag.faiss_store import FaissDomainStores, rrf_fuse, Retrieved
from app.rag.graphrag_client import GraphRAGClient
from app.utils.citation import split_sentences, assign_sentence_citations
from app.utils.streaming import ConsoleStreamCallback
from app.utils.slot_utils import extract_json_block

SYS_EXTRACT = SystemMessage(content=(
    "You are an information extractor. Read the last user message (Korean allowed) and extract medical intake slots as JSON. "
    "Keys: age (int|None), sex ('male'|'female'|'other'|None), symptoms (list[str]), duration_days (int|None), "
    "chronic_conditions (list[str]), medications (list[str]), allergies (list[str]), pregnancy (bool|None). "
    "Return ONLY valid JSON."
))

SYS_ASKER = SystemMessage(content=(
    "You are a careful medical intake assistant. Ask only for missing or critical fields, "
    "grouping 2~3 items per question max, in Korean, concise and polite."
))

SYS_ANSWER = SystemMessage(content=(
    "You are a cautious medical assistant. Use the provided context to hypothesize possible conditions (not a diagnosis), "
    "list red flags, and suggest OTC/home care when appropriate. ALWAYS include a disclaimer to consult a professional. "
    "Answer in Korean, concise but structured."
))

REQUIRED = ["age","sex","symptoms","duration_days"]

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def _merge_slots(old: Dict[str,Any], new: Dict[str,Any]) -> Dict[str,Any]:
    out = dict(old or {})
    for k,v in (new or {}).items():
        if v in (None, "", [], {}): continue
        out[k] = v
    return out

def doctor_collect(state: AgentState) -> AgentState:
    # intent 고정
    state = dict(state); state["intent"] = "doctor"; state["intent_locked"] = True
    # 최근 사용자 발화에서 슬롯 추출
    llm = get_llm(streaming=False)
    user_text = state["messages"][-1].content
    raw = llm.invoke([SYS_EXTRACT, HumanMessage(content=user_text)]).content
    slots = extract_json_block(raw)
    merged = _merge_slots(state.get("doctor_slots", {}), slots)

    # 빠진 슬롯 확인
    missing = []
    for k in REQUIRED:
        if k not in merged or merged[k] in (None, "", [], {}):
            missing.append(k)

    if missing:
        # 물어볼 질문 구성
        ask_llm = get_llm(streaming=False)
        q = ask_llm.invoke([
            SYS_ASKER,
            HumanMessage(content=f"현재 확보된 정보: {merged}. 부족한 항목: {missing}. 한국어로 한 번에 2~3개만 정중히 질문하세요.")
        ]).content.strip()

        # 다음 턴을 위해 AIMessage를 messages에 추가하고, 외부 루프가 사용자 입력을 받도록 신호
        out = dict(state)
        out["doctor_slots"] = merged
        out["needs_more_info"] = True
        out["followup_question"] = q
        out.setdefault("messages", []).append(AIMessage(content=q))
        return out

    # 모두 채워졌으면 다음 단계(답변 생성)에서 사용
    out = dict(state)
    out["doctor_slots"] = merged
    out["needs_more_info"] = False
    return out

def doctor_answer(state: AgentState, stores: FaissDomainStores) -> AgentState:
    state = dict(state); state["intent"] = "doctor"; state["intent_locked"] = False
    question = state["messages"][-1].content
    # 컨텍스트 생성(RAG)
    faiss_hits = stores.search("medical", question, k=6)
    hits = faiss_hits; retriever_used = "faiss"
    if os.getenv("USE_GRAPHRAG","0") == "1":
        gr = GraphRAGClient().query(question, top_k=6)
        gr_hits: List[Retrieved] = []
        if faiss_hits:
            T = type(faiss_hits[0])
            for g in gr:
                gr_hits.append(T(text=g["text"], url=g["url"] or "GraphRAG", title=g["title"] or "GraphRAG", score=g["score"], id=g["id"]))
            hits = rrf_fuse(faiss_hits, gr_hits); retriever_used = "hybrid"

    context = "\n\n---\n\n".join([f"[{i+1}] {h.title} ({h.url})\n{h.text}" for i,h in enumerate(hits)])
    slots = state.get("doctor_slots", {})
    prompt = HumanMessage(content=(
        f"사용자 질문: {question}\n슬롯: {slots}\n\n참고 문서:\n{context}\n\n"
        "위 정보를 바탕으로 한국어로 간결하고 구조적으로 답변하세요. 문장마다 신뢰 근거에 의존하도록 하세요."
    ))

    llm = get_llm(streaming=True)
    resp = llm.invoke([SYS_ANSWER, prompt]).content

    embedder = stores.embed
    doc_chunks = [dict(text=h.text, url=h.url, title=h.title, id=h.id, embedding=None) for h in hits]
    sents = split_sentences(resp)
    marked, srcs = assign_sentence_citations(sents, doc_chunks, embedder)

    out = dict(state)
    out["result_text"] = marked
    out["sources"] = srcs
    out["retriever_used"] = retriever_used
    return out
