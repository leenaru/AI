from __future__ import annotations
import os
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.rag.faiss_store import FaissDomainStores, rrf_fuse, Retrieved
from app.rag.graphrag_client import GraphRAGClient
from app.utils.citation import split_sentences, assign_sentence_citations
from app.utils.streaming import ConsoleStreamCallback
from app.utils.slot_utils import extract_json_block

SYS_EXTRACT = SystemMessage(content=(
    "Extract travel planning slots as JSON from the user's last message (Korean allowed). "
    "Keys: country (str|None), city (str|None), start_date (str|None), end_date (str|None), nights (int|None), "
    "travelers (int|None), kids_ages (list[int]), budget_level ('low'|'mid'|'high'|None), interests (list[str]). "
    "Return ONLY JSON."
))

SYS_ASKER = SystemMessage(content=(
    "You are a travel intake assistant. Ask only for missing/critical items (2~3 at once), in polite Korean."
))

SYS_ANSWER = SystemMessage(content=(
    "You are a precise travel planner. Use the provided context about destination to propose a day-by-day plan, "
    "including logistics, food, kid-friendly options, and budget tips. Answer in Korean."
))

REQUIRED = ["country","nights","travelers"]

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def _merge_slots(old: Dict[str,Any], new: Dict[str,Any]) -> Dict[str,Any]:
    out = dict(old or {})
    for k,v in (new or {}).items():
        if v in (None, "", [], {}): continue
        out[k] = v
    return out

def travel_collect(state: AgentState) -> AgentState:
    state = dict(state); state["intent"] = "travel"; state["intent_locked"] = True
    llm = get_llm(streaming=False)
    user_text = state["messages"][-1].content
    raw = llm.invoke([SYS_EXTRACT, HumanMessage(content=user_text)]).content
    slots = extract_json_block(raw)
    merged = _merge_slots(state.get("travel_slots", {}), slots)

    missing = [k for k in REQUIRED if k not in merged or merged[k] in (None,"",[],{})]
    if missing:
        ask_llm = get_llm(streaming=False)
        q = ask_llm.invoke([SYS_ASKER, HumanMessage(content=f"현재 확보된 정보: {merged}. 부족 항목: {missing}. 한국어로 간결히 질문.")]).content.strip()
        out = dict(state)
        out["travel_slots"] = merged
        out["needs_more_info"] = True
        out["followup_question"] = q
        out.setdefault("messages", []).append(AIMessage(content=q))
        return out

    out = dict(state)
    out["travel_slots"] = merged
    out["needs_more_info"] = False
    return out

def travel_answer(state: AgentState, stores: FaissDomainStores) -> AgentState:
    state = dict(state); state["intent"] = "travel"; state["intent_locked"] = False
    question = state["messages"][-1].content

    faiss_hits = stores.search("travel", question, k=6)
    hits = faiss_hits; retriever_used = "faiss"
    if os.getenv("USE_GRAPHRAG","0") == "1":
        gr = GraphRAGClient().query(question, top_k=6)
        gr_hits: List[Retrieved] = []
        if faiss_hits:
            T = type(faiss_hits[0])
            for g in gr:
                gr_hits.append(T(text=g["text"], url=g["url"] or "GraphRAG", title=g["title"] or "GraphRAG", score=g["score"], id=g["id"]))
            hits = rrf_fuse(faiss_hits, gr_hits); retriever_used = "hybrid"

    context = "\n\n---\n\n".join([f"[{i+1}] {h.title} ({h.url})\n{h.text}" for i,h in enumerate(hits)])
    slots = state.get("travel_slots", {})
    prompt = HumanMessage(content=(
        f"사용자 요청: {question}\n슬롯: {slots}\n\n참고 자료:\n{context}\n\n"
        "위 정보를 참고하여 날짜별 일정표, 교통/음식/아이 동반/예산 팁을 포함해 제안하세요."
    ))

    llm = get_llm(streaming=True)
    resp = llm.invoke([SYS_ANSWER, prompt]).content

    embedder = stores.embed
    doc_chunks = [dict(text=h.text, url=h.url, title=h.title, id=h.id, embedding=None) for h in hits]
    sents = split_sentences(resp)
    marked, srcs = assign_sentence_citations(sents, doc_chunks, embedder)

    out = dict(state)
    out["result_text"] = marked
    out["sources"] = srcs
    out["retriever_used"] = retriever_used
    return out
