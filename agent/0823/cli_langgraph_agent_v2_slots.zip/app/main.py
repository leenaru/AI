from __future__ import annotations
import argparse, os
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from app.state import AgentState
from app.router import route_node, branch
from app.agents.doctor import doctor_collect, doctor_answer
from app.agents.travel import travel_collect, travel_answer
from app.agents.movie import movie_collect, movie_answer
from app.rag.faiss_store import FaissDomainStores
from app.utils.streaming import stream_print

def build_graph(stores: FaissDomainStores):
    g = StateGraph(AgentState)

    # 라우팅
    g.add_node("route", route_node)

    # 의사
    g.add_node("doctor_collect", doctor_collect)
    g.add_node("doctor_answer", lambda s: doctor_answer(s, stores))

    # 여행
    g.add_node("travel_collect", travel_collect)
    g.add_node("travel_answer", lambda s: travel_answer(s, stores))

    # 영화
    g.add_node("movie_collect", movie_collect)
    g.add_node("movie_answer", movie_answer)

    # 기타
    g.add_node("other", lambda s: {**s, "result_text": "죄송합니다. 해당 요청은 현재 범위를 벗어납니다. 질문을 보다 구체화하여 다시 요청해 주세요.", "sources": []})

    # 흐름
    g.add_edge(START, "route")
    g.add_conditional_edges("route", branch, {
        "doctor_collect": "doctor_collect",
        "travel_collect": "travel_collect",
        "movie_collect": "movie_collect",
        "other": "other"
    })
    # collect 결과에 따라 answer 또는 종료(추가 질문을 위해)
    g.add_conditional_edges("doctor_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "doctor_answer"
    })
    g.add_edge("doctor_answer", END)

    g.add_conditional_edges("travel_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "travel_answer"
    })
    g.add_edge("travel_answer", END)

    g.add_conditional_edges("movie_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "movie_answer"
    })
    g.add_edge("movie_answer", END)

    # 체크포인트
    db_path = os.getenv("CHECKPOINT_DB", ".checkpoints/agent.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    memory = SqliteSaver(db_path)
    return g.compile(checkpointer=memory)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=str, default="default", help="세션/대화 ID (체크포인트 키)")
    ap.add_argument("--no-stream", action="store_true", help="스트리밍 비활성화")
    ap.add_argument("--retriever", type=str, default="hybrid", choices=["faiss","graphrag","hybrid"], help="검색기 선택")
    args = ap.parse_args()

    os.environ["USE_GRAPHRAG"] = "1" if args.retriever in ("graphrag","hybrid") else "0"

    stores = FaissDomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../data/docs"))
    graph = build_graph(stores)

    print("=== CLI 멀티-역할 에이전트 (LangChain + LangGraph / Multi-turn Slot Filling) ===")
    print("세션:", args.session)
    print("모델:", os.getenv("OLLAMA_MODEL", "llama3:8b"))
    print("검색기:", args.retriever)
    print("")

    while True:
        try:
            user = input("> 사용자 질문(또는 exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n종료합니다.")
            break
        if user.lower() in ("exit","quit","q"):
            print("종료합니다.")
            break

        config = {"configurable": {"thread_id": args.session}}
        state_in = {"messages": [HumanMessage(content=user)]}

        # 멀티턴 루프: 필요한 정보가 있을 때까지 반복
        while True:
            out = graph.invoke(state_in, config=config)

            # follow-up 질문이 있으면 우선 출력하고 사용자 답을 받음
            if out.get("needs_more_info"):
                q = out.get("followup_question", "추가 정보가 필요합니다.")
                print("\n[추가 질문]")
                stream_print(q, enabled=not args.no_stream)
                try:
                    ans = input("> 추가정보: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\n종료합니다."); return
                # 다음 턴: 이전 대화에 사용자 답변 추가
                state_in = {"messages": [HumanMessage(content=ans)]}
                continue

            # 최종 답변
            print("\n▼ 답변")
            if args.no_stream: print(out.get("result_text",""))
            else: stream_print(out.get("result_text",""), enabled=True)

            # 출처
            sources = out.get("sources",[]) or []
            if sources:
                print("\n[출처]")
                for s in sources:
                    print(f"[{s.get('idx')}] {s.get('title','')} — {s.get('url','')}")
            print("")
            break

if __name__ == "__main__":
    main()
