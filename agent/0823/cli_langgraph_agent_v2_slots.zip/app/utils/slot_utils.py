import json, re
from typing import Dict, Any

def extract_json_block(text: str) -> Dict[str, Any]:
    # 가장 큰 JSON 블록 추출
    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        return {}
    block = m.group(0)
    try:
        return json.loads(block)
    except Exception:
        # 작은 오류 보정
        block = block.replace("\t", " ").replace("\n", " ")
        block = re.sub(r",\s*([}\]])", r"\1", block)
        try:
            return json.loads(block)
        except Exception:
            return {}
