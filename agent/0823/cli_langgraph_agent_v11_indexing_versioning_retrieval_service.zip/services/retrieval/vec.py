
from __future__ import annotations
import re, numpy as np, hashlib
from typing import List

def tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9가-힣]+", (text or "").lower())

def hash_embed(texts: List[str], dim: int = 768) -> "np.ndarray":
    X = np.zeros((len(texts), dim), dtype="float32")
    for i, t in enumerate(texts):
        for tok in tokenize(t):
            h = int(hashlib.blake2b(tok.encode("utf-8"), digest_size=8).hexdigest(), 16)
            j = h % dim
            X[i, j] += 1.0
        n = np.linalg.norm(X[i])
        if n > 0: X[i] /= n
    return X
