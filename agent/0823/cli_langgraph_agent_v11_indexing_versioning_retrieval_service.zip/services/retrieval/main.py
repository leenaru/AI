
from __future__ import annotations
import os, glob
from typing import List, Dict, Any, Optional
from fastapi import FastAPI
from pydantic import BaseModel
from rank_bm25 import BM25Okapi

CORPUS_DIR = os.getenv("CORPUS_DIR", "data/corpus")
app = FastAPI(title="Retrieval Service", version="0.1-bm25")

def current_version() -> str:
    p = os.path.join(CORPUS_DIR, "current_version.txt")
    return open(p,"r",encoding="utf-8").read().strip() if os.path.exists(p) else ""

def read_docs(version: str, domain: str) -> List[str]:
    root = os.path.join(CORPUS_DIR, version, domain)
    texts = []
    for md in glob.glob(os.path.join(root, "*.md")):
        try:
            s = open(md, "r", encoding="utf-8", errors="ignore").read()
            chunks = [ln.strip("- ").strip() for ln in s.splitlines() if ln.strip().startswith("- ")]
            texts.extend(chunks or [s])
        except: pass
    return texts

class SearchReq(BaseModel):
    domain: str
    query: str
    k: int = 6
    version: Optional[str] = None

BM25_INDEX: Dict[str, Any] = {}

def key(ver, dom): return f"{ver}:{dom}"

def ensure_bm25(ver, dom):
    k = key(ver, dom)
    if k in BM25_INDEX: return
    docs = read_docs(ver, dom)
    tokenized = [d.lower().split() for d in docs]
    BM25_INDEX[k] = {"docs": docs, "bm25": BM25Okapi(tokenized)}

@app.get("/health")
def health():
    return {"ok": True, "version": current_version()}

@app.post("/search")
def search(req: SearchReq):
    ver = req.version or current_version()
    if not ver: return {"items": []}
    ensure_bm25(ver, req.domain)
    idx = BM25_INDEX[key(ver, req.domain)]
    scores = idx["bm25"].get_scores(req.query.lower().split())
    import numpy as np
    order = np.argsort(scores)[-req.k:][::-1]
    return {"items": [{"rank":i+1,"text":idx["docs"][int(j)],"score":float(scores[int(j)])} for i,j in enumerate(order)]}
