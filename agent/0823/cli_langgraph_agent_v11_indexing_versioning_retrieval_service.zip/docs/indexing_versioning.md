# v11 Indexing & Versioning — 사용법 요약
(생략된 내용은 이전 답변 참고)