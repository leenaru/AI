
# Retrieval Hybrid Tuner (Service-Integrated)

- `/search`: FAISS+BM25 가중 융합 검색
- `/config/weights` (GET/POST): 버전/도메인별 가중치 관리
- `/tune/start`: Hyperband로 최적 가중치 탐색 (qrels 기반)
- `/tune/status`: 진행/결과 확인

## Quick Demo
```bash
python -m app.indexing.versioner publish --stage data/stage --corpus data/corpus --move
export CORPUS_DIR=data/corpus
uvicorn services.retrieval.main:app --host 0.0.0.0 --port 8081

curl -X POST http://localhost:8081/tune/start -H "Content-Type: application/json" -d '{"qrels_path":"data/tuning/sample_qrels.yaml"}'
curl http://localhost:8081/tune/status
curl "http://localhost:8081/config/weights?domain=travel"
```
