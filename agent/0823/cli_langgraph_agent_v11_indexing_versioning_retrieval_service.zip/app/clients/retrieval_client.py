
from __future__ import annotations
import os, requests
RETRIEVAL_URL = os.getenv("RETRIEVAL_URL", "http://localhost:8081")
def search(domain: str, query: str, k: int = 6, version: str | None = None) -> list[dict]:
    payload = {"domain": domain, "query": query, "k": k}
    if version: payload["version"] = version
    r = requests.post(f"{RETRIEVAL_URL}/search", json=payload, timeout=20)
    r.raise_for_status()
    return r.json().get("items", [])
