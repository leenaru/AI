
from __future__ import annotations
import os, re, json, hashlib
from pathlib import Path
from datetime import datetime

HEADER_RE = re.compile(r'<!--(.*?)-->', re.DOTALL)
def sha256_bytes(b: bytes) -> str: return hashlib.sha256(b).hexdigest()

def parse_meta(text: str):
    m = HEADER_RE.search(text)
    if not m: return {}
    body = m.group(1).strip(); meta = {}
    for part in body.split("|"):
        if ":" in part:
            k,v = part.split(":",1); meta[k.strip()] = v.strip()
    return meta

def infer_domain(path: Path, meta):
    if "domain" in meta: return meta["domain"]
    for p in path.parts[::-1]:
        if p in ("travel","medical","movie","other"): return p
    return "other"

def publish(stage: str, corpus: str, version: str | None = None, move: bool = False):
    stage_p = Path(stage); corpus_p = Path(corpus)
    version = version or datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    root = corpus_p / version; root.mkdir(parents=True, exist_ok=True)
    manifest = {"version": version, "docs": []}
    for src in stage_p.rglob("*.md"):
        text = src.read_text(encoding="utf-8", errors="ignore")
        meta = parse_meta(text); domain = infer_domain(src, meta)
        etag = sha256_bytes(text.encode("utf-8"))
        header = f"<!-- { ' | '.join([f'{k}: {v}' for k,v in meta.items()]) } | etag: {etag} | corpus_version: {version} -->\n"
        if not text.lstrip().startswith('<!--'):
            text = header + text
        else:
            text = re.sub(r'^<!--.*?-->', header, text, count=1, flags=re.DOTALL)
        dst = root / domain / src.name; dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(text, encoding="utf-8")
        manifest["docs"].append({"relpath": f"{domain}/{src.name}", "etag": etag})
        if move:
            try: src.unlink()
            except: pass
    (corpus_p/'current_version.txt').write_text(version, encoding='utf-8')
    (root/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    (root/'surrogate.key').write_text(f"corpus:{version}", encoding='utf-8')
    print(json.dumps({"published_version": version, "count": len(manifest["docs"])}))

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["publish"])
    ap.add_argument("--stage", required=True)
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--version", default=None)
    ap.add_argument("--move", action="store_true")
    args = ap.parse_args()
    if args.cmd=="publish":
        publish(args.stage, args.corpus, args.version, args.move)
