from __future__ import annotations
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
import os

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def _key(it: Retrieved) -> str:
    return (it.url or "") + "|" + (it.title or "") + "|" + (it.text[:32] if it.text else "")

def _normalize(vals: Dict[str, float]) -> Dict[str, float]:
    if not vals: return {}
    lo, hi = min(vals.values()), max(vals.values())
    if hi <= lo:
        return {k:0.0 for k in vals}
    return {k:(v-lo)/(hi-lo) for k,v in vals.items()}

def _normalize_list(items: List[Retrieved]) -> Dict[str, float]:
    if not items: return {}
    lo, hi = min(i.score for i in items), max(i.score for i in items)
    if hi <= lo:
        return {_key(i):0.0 for i in items}
    return {_key(i):(i.score-lo)/(hi-lo) for i in items}

def _graph_meta_map(items: List[Retrieved], nodes: List[Dict[str,Any]]) -> Dict[str, Dict[str,Any]]:
    meta = {}
    by_id = {str(n.get("id")): n for n in (nodes or [])}
    by_title = {str(n.get("title") or n.get("name","")): n for n in (nodes or [])}
    for it in items:
        k = _key(it)
        cand = by_id.get(str(getattr(it,"id",""))) or by_title.get(it.title) or {}
        cent = cand.get("centrality") or cand.get("pagerank") or cand.get("score") or 0.0
        comm = cand.get("community") or cand.get("cluster") or cand.get("modularity_class")
        meta[k] = {"centrality": float(cent or 0.0), "community": comm}
    cent_norm = _normalize({k:v["centrality"] for k,v in meta.items()})
    for k in meta:
        meta[k]["centrality"] = cent_norm.get(k, 0.0)
    return meta

def fuse_weighted_graphmeta_debug(
    faiss: List[Retrieved],
    bm25: List[Retrieved],
    graphrag: List[Retrieved],
    nodes: List[Dict[str,Any]] | None,
    edges: List[Dict[str,Any]] | None,
    w_f: float = 0.5, w_b: float = 0.3, w_g: float = 0.2,
    w_centrality: float = None, w_diversity: float = None,
    topn: int = 6
) -> Tuple[List[Retrieved], Dict[str, Dict[str, float]]]:
    if w_centrality is None:
        w_centrality = float(os.getenv("GRAPH_META_WEIGHT", "0.15"))
    if w_diversity is None:
        w_diversity = float(os.getenv("COMMUNITY_DIVERSITY_WEIGHT", "0.05"))

    nf = _normalize_list(faiss)
    nb = _normalize_list(bm25)
    ng = _normalize_list(graphrag)

    pool: Dict[str, Retrieved] = {}
    debug: Dict[str, Dict[str, float]] = {}
    for lst in (faiss, bm25, graphrag):
        for it in lst:
            pool[_key(it)] = it

    base: Dict[str, float] = {}
    for k, it in pool.items():
        base[k] = w_f*nf.get(k,0.0) + w_b*nb.get(k,0.0) + w_g*ng.get(k,0.0)

    meta = _graph_meta_map(list(pool.values()), nodes or [])
    selected: List[Retrieved] = []
    comm_count: Dict[str, int] = {}

    while len(selected) < min(topn, len(pool)):
        best_k, best_total, best_item = None, -1e9, None
        for k, it in pool.items():
            if any(_key(si)==k for si in selected): continue
            centr = meta.get(k,{}).get("centrality", 0.0)
            comm = meta.get(k,{}).get("community", None)
            penalty = w_diversity * (comm_count.get(str(comm),0))
            total = base[k] + w_centrality*centr - penalty
            if total > best_total:
                best_k, best_total, best_item = k, total, it
        if best_k is None: break
        selected.append(best_item)
        comm = meta.get(best_k,{}).get("community", None)
        comm_count[str(comm)] = comm_count.get(str(comm),0) + 1
        debug[best_k] = {
            "faiss": nf.get(best_k,0.0),
            "bm25": nb.get(best_k,0.0),
            "graph": ng.get(best_k,0.0),
            "centrality": meta.get(best_k,{}).get("centrality",0.0),
            "diversity_penalty": w_diversity * (comm_count.get(str(comm),1)-1),
            "final": base.get(best_k,0.0),
            "final_plus": best_total
        }
    return selected, debug
