import os, subprocess, json, shlex, requests
from typing import List, Dict, Any

class GraphRAGClient:
    def __init__(self):
        self.mode = os.getenv("GRAPHRAG_MODE", "http").lower()  # http | cli
        self.url = os.getenv("GRAPHRAG_URL", "http://localhost:8010/query")
        self.cli = os.getenv("GRAPHRAG_CLI", "python -m graphrag.query")

    def query(self, text: str, top_k: int = 5) -> Dict[str, Any]:
        if self.mode == "http":
            try:
                r = requests.post(self.url, json={"query": text, "top_k": top_k}, timeout=30)
                r.raise_for_status()
                data = r.json()
                return self._parse_http(data)
            except Exception:
                return {"items": [], "nodes": [], "edges": []}
        else:
            cmd = f"{self.cli} --query {shlex.quote(text)} --limit {top_k} --format json"
            try:
                out = subprocess.check_output(cmd, shell=True, timeout=60, text=True)
                data = json.loads(out)
                return self._parse_cli(data)
            except Exception:
                return {"items": [], "nodes": [], "edges": []}

    def _parse_http(self, data: Any) -> Dict[str, Any]:
        # 기대 형태: {'results':[], 'nodes':[], 'edges':[]}
        items = []
        for i, d in enumerate((data.get("results") or [])):
            items.append({
                "text": d.get("text", ""),
                "url": d.get("url", d.get("source", "")),
                "title": d.get("title", "GraphRAG"),
                "score": float(d.get("score", 0.0)),
                "id": d.get("id", f"gr-{i}"),
            })
        nodes = data.get("nodes") or []
        edges = data.get("edges") or []
        return {"items": items, "nodes": nodes, "edges": edges}

    def _parse_cli(self, data: Any) -> Dict[str, Any]:
        items = []
        for i, d in enumerate((data.get("results") or [])):
            items.append({
                "text": d.get("text", ""),
                "url": d.get("url", d.get("source", "")),
                "title": d.get("title", "GraphRAG"),
                "score": float(d.get("score", 0.0)),
                "id": d.get("id", f"gr-{i}"),
            })
        nodes = data.get("nodes") or []
        edges = data.get("edges") or []
        return {"items": items, "nodes": nodes, "edges": edges}
