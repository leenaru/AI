from __future__ import annotations
from typing import TypedDict, Literal, Dict, Any, List
from typing_extensions import Annotated
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage

Intent = Literal["doctor", "travel", "movie", "other"]

class AgentState(TypedDict, total=False):
    # LangGraph reducer로 누적 저장
    messages: Annotated[List[BaseMessage], add_messages]
    intent: Intent
    intent_locked: bool
    # 제너레이션 결과
    result_text: str
    sources: List[Dict[str, Any]]
    retriever_used: Literal["faiss", "graphrag", "hybrid", "none"]
    # 멀티턴 질의 수집
    needs_more_info: bool
    followup_question: str
    # 슬롯(에이전트별)
    doctor_slots: Dict[str, Any]
    travel_slots: Dict[str, Any]
    movie_slots: Dict[str, Any]
