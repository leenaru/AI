from __future__ import annotations
import os, yaml, random, math, time
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from app.rag.faiss_store import FaissDomainStores
from app.rag.bm25_store import BM25DomainStores
from app.rag.graphrag_client import GraphRAGClient
from app.rag.hybrid import fuse_weighted_graphmeta_debug, Retrieved
from app.utils import ret_cache

@dataclass
class Qrel:
    query: str
    domain: str
    relevant_titles: List[str]

def load_qrels(path: str) -> List[Qrel]:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or []
    out = []
    for row in data:
        out.append(Qrel(query=row["query"], domain=row["domain"], relevant_titles=row["relevant_titles"]))
    return out

def hit_at_k(ranked: List[Retrieved], gold_titles: List[str], k: int = 5) -> float:
    titles = set([t.lower() for t in gold_titles])
    for i, it in enumerate(ranked[:k]):
        if it.title.lower() in titles:
            return 1.0
    return 0.0

def ndcg_at_k(ranked: List[Retrieved], gold_titles: List[str], k: int = 5) -> float:
    titles = [t.lower() for t in gold_titles]
    dcg = 0.0
    for i, it in enumerate(ranked[:k], start=1):
        rel = 1.0 if it.title.lower() in titles else 0.0
        dcg += rel / math.log2(i+1)
    idcg = sum([1.0 / math.log2(i+1) for i in range(1, min(k, len(gold_titles))+1)])
    return dcg / idcg if idcg > 0 else 0.0

def evaluate(weights: Dict[str,float], qrels: List[Qrel], stores: FaissDomainStores, bm25: BM25DomainStores) -> Tuple[float,float]:
    ws = (weights.get("faiss",0.5), weights.get("bm25",0.3), weights.get("graph",0.2))
    h, n, cnt = 0.0, 0.0, 0
    for qr in qrels:
        q = qr.query; dom = qr.domain
        cached = ret_cache.get(dom, q)
        if cached:
            from app.rag.hybrid import Retrieved as HRetrieved
            faiss_hits = [Retrieved(**h) for h in cached.get("faiss",[])]
            bm25_hits  = [Retrieved(**h) for h in cached.get("bm25",[])]
            gr_items   = [HRetrieved(**h) for h in cached.get("graph",[])]
            nodes, edges = cached.get("nodes",[]), cached.get("edges",[])
        else:
            faiss_hits = [Retrieved(**vars(h)) for h in stores.search(dom, q, k=10)]
            bm25_hits  = [Retrieved(**vars(h)) for h in bm25.search(dom, q, k=10)]
            gr_items, nodes, edges = [], [], []
            if os.getenv("USE_GRAPHRAG","0") == "1":
                gr = GraphRAGClient().query(q, top_k=10)
                items = gr.get("items") if isinstance(gr, dict) else gr
                nodes = gr.get("nodes", []) if isinstance(gr, dict) else []
                edges = gr.get("edges", []) if isinstance(gr, dict) else []
                from app.rag.hybrid import Retrieved as HRetrieved
                for g in items:
                    gr_items.append(HRetrieved(text=g["text"], url=g.get("url") or "GraphRAG", title=g.get("title") or "GraphRAG", score=g.get("score",0.0), id=g.get("id","gr")))
            ret_cache.put(dom, q, {"faiss":[vars(x) for x in faiss_hits],"bm25":[vars(x) for x in bm25_hits],"graph":[vars(x) for x in gr_items],"nodes":nodes,"edges":edges})
        fused, debug = fuse_weighted_graphmeta_debug(faiss_hits, bm25_hits, gr_items, nodes, edges, w_f=ws[0], w_b=ws[1], w_g=ws[2], topn=5)
        h += hit_at_k(fused, qr.relevant_titles, k=5)
        n += ndcg_at_k(fused, qr.relevant_titles, k=5)
        cnt += 1
    return h/cnt, n/cnt

def random_search(qrels, stores, bm25, trials=20):
    best = (None, -1, -1, {})
    for t in range(trials):
        import random
        w_f = random.uniform(0.2, 0.8)
        w_b = random.uniform(0.1, 0.6)
        w_g = max(0.0, 1.0 - w_f - w_b)
        weights = {"faiss":w_f,"bm25":w_b,"graph":w_g}
        hit, nd = evaluate(weights, qrels, stores, bm25)
        score = 0.6*hit + 0.4*nd
        if score > best[1]:
            best = (t, score, hit, weights)
            print(f"[best@{t}] score={score:.3f} hit={hit:.3f} ndcg={nd:.3f} weights={weights}")
    return best

def bayes_opt(qrels, stores, bm25, trials=30):
    try:
        from skopt import gp_minimize
        from skopt.space import Real
        def objective(x):
            w_f, w_b = x
            w_g = max(0.0, 1.0 - w_f - w_b)
            weights = {"faiss":w_f,"bm25":w_b,"graph":w_g}
            hit, nd = evaluate(weights, qrels, stores, bm25)
            score = -(0.6*hit + 0.4*nd)  # minimize
            return score
        res = gp_minimize(objective, [Real(0.2,0.8,name="w_f"), Real(0.1,0.6,name="w_b")], n_calls=trials, random_state=0)
        w_f, w_b = res.x
        w_g = max(0.0, 1.0 - w_f - w_b)
        best_weights = {"faiss":w_f,"bm25":w_b,"graph":w_g}
        hit, nd = evaluate(best_weights, qrels, stores, bm25)
        return (None, 0.6*hit+0.4*nd, hit, best_weights)
    except Exception as e:
        print("BayesOpt not available, fallback to random search:", e)
        return random_search(qrels, stores, bm25, trials=trials)

def hyperband(qrels, stores, bm25, max_iter=27, eta=3):
    import math, random
    s_max = int(math.log(max_iter, eta))
    B = (s_max + 1) * max_iter
    best = (None, -1, -1, {})
    for s in reversed(range(s_max + 1)):
        n = int(math.ceil(B / max_iter / (s+1) * eta**s))
        r = max_iter * eta**(-s)
        configs = []
        for i in range(n):
            w_f = random.uniform(0.2, 0.8)
            w_b = random.uniform(0.1, 0.6)
            w_g = max(0.0, 1.0 - w_f - w_b)
            configs.append({"faiss":w_f,"bm25":w_b,"graph":w_g})
        for i in range(s+1):
            m = int(n * eta**(-i))
            scores = []
            for cfg in configs:
                hit, nd = evaluate(cfg, qrels, stores, bm25)
                score = 0.6*hit + 0.4*nd
                scores.append((score, cfg))
            scores.sort(key=lambda x:x[0], reverse=True)
            configs = [cfg for _, cfg in scores[:max(1, m//eta)]]
            if scores and scores[0][0] > best[1]:
                best = (None, scores[0][0], None, scores[0][1])
    return best

def main():
    import argparse, os, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=str, default="data/tuning/sample_qrels.yaml")
    ap.add_argument("--algo", type=str, default="bayes", choices=["bayes","random","hyperband"])
    ap.add_argument("--trials", type=int, default=30)
    args = ap.parse_args()

    stores = FaissDomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../../data/docs"))
    bm25 = BM25DomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../../data/docs"))
    qrels = load_qrels(args.dataset)

    if args.algo == "bayes":
        best = bayes_opt(qrels, stores, bm25, trials=args.trials)
    elif args.algo == "hyperband":
        best = hyperband(qrels, stores, bm25, max_iter=args.trials, eta=3)
    else:
        best = random_search(qrels, stores, bm25, trials=args.trials)

    print("Best:", best)
    if best and best[-1]:
        weights = best[-1]
        print("Suggested HYBRID_WEIGHTS:", f'faiss:{weights["faiss"]:.3f},bm25:{weights["bm25"]:.3f},graph:{weights["graph"]:.3f}')

if __name__ == "__main__":
    main()
