from __future__ import annotations
import os, math, random, time, yaml, json
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from app.rag.faiss_store import FaissDomainStores
from app.rag.bm25_store import BM25DomainStores
from app.rag.graphrag_client import GraphRAGClient
from app.rag.hybrid_coverage import fuse_coverage_mmr_debug, Retrieved
from app.utils import ret_cache

@dataclass
class Qrel:
    query: str
    domain: str
    relevant_titles: List[str]

def load_qrels(path: str) -> List[Qrel]:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or []
    return [Qrel(**row) for row in data]

def _subset_qrels(qrels: List[Qrel], budget: int) -> List[Qrel]:
    if budget >= len(qrels): return qrels
    import random
    return random.sample(qrels, budget)

def metrics(ranked: List[Retrieved], gold_titles: List[str], k: int = 5) -> Dict[str,float]:
    titles = set([t.lower() for t in gold_titles])
    # Hit@k
    hit = 0.0
    for it in ranked[:k]:
        if it.title.lower() in titles:
            hit = 1.0; break
    # nDCG@k
    import math
    dcg = 0.0
    for i, it in enumerate(ranked[:k], start=1):
        rel = 1.0 if it.title.lower() in titles else 0.0
        dcg += rel / math.log2(i+1)
    idcg = sum([1.0 / math.log2(i+1) for i in range(1, min(k, len(titles))+1)]) or 1.0
    ndcg = dcg / idcg

    return {"hit": hit, "ndcg": ndcg}

def evaluate(weights: Dict[str,float], qrels: List[Qrel], stores: FaissDomainStores, bm25: BM25DomainStores, budget: int = None) -> Dict[str,float]:
    qs = _subset_qrels(qrels, budget or len(qrels))
    acc_hit, acc_ndcg, total_time = 0.0, 0.0, 0.0
    for qr in qs:
        start = time.time()
        q, dom = qr.query, qr.domain
        cached = ret_cache.get(dom, q)
        if cached:
            faiss_hits = [Retrieved(**h) for h in cached.get("faiss",[])]
            bm25_hits  = [Retrieved(**h) for h in cached.get("bm25",[])]
            gr_items   = [Retrieved(**h) for h in cached.get("graph",[])]
            nodes, edges = cached.get("nodes",[]), cached.get("edges",[])
        else:
            faiss_hits = [Retrieved(**vars(h)) for h in stores.search(dom, q, k=10)]
            bm25_hits  = [Retrieved(**vars(h)) for h in bm25.search(dom, q, k=10)]
            gr_items, nodes, edges = [], [], []
            if os.getenv("USE_GRAPHRAG","0") == "1":
                gr = GraphRAGClient().query(q, top_k=10)
                items = gr.get("items") if isinstance(gr, dict) else gr
                nodes = gr.get("nodes", []) if isinstance(gr, dict) else []
                edges = gr.get("edges", []) if isinstance(gr, dict) else []
                for g in items:
                    gr_items.append(Retrieved(text=g["text"], url=g.get("url") or "GraphRAG", title=g.get("title") or "GraphRAG", score=g.get("score",0.0), id=g.get("id","gr")))
            ret_cache.put(dom, q, {"faiss":[vars(x) for x in faiss_hits],"bm25":[vars(x) for x in bm25_hits],"graph":[vars(x) for x in gr_items],"nodes":nodes,"edges":edges})
        fused, _debug = fuse_coverage_mmr_debug(
            faiss_hits, bm25_hits, gr_items, nodes, edges,
            w_f=weights.get("faiss",0.5), w_b=weights.get("bm25",0.3), w_g=weights.get("graph",0.2),
            topn=5
        )
        m = metrics(fused, qr.relevant_titles, k=5)
        elapsed = time.time()-start
        acc_hit += m["hit"]; acc_ndcg += m["ndcg"]; total_time += elapsed

    n = len(qs) or 1
    # 비용 proxy: 그래프 의존 가중치 + 평균 시간
    cost_proxy = weights.get("graph",0.0) + (total_time/n)
    return {
        "hit": acc_hit/n,
        "ndcg": acc_ndcg/n,
        "time": total_time/n,
        "cost": cost_proxy
    }

def scalarize(m: Dict[str,float], wa: float, ws: float, wc: float) -> float:
    # maximize (accuracy) and minimize (speed/time & cost)
    acc = 0.6*m["hit"] + 0.4*m["ndcg"]
    # speed: convert to reward (smaller time -> higher)
    spd = 1.0 / (1.0 + m["time"])
    # cost: convert to reward (smaller cost -> higher)
    cst = 1.0 / (1.0 + m["cost"])
    return wa*acc + ws*spd + wc*cst

def hyperband(qrels, stores, bm25, R=27, eta=3, wa=0.7, ws=0.2, wc=0.1):
    # True Hyperband (Li et al. 2017)
    s_max = int(math.log(R, eta))
    B = (s_max + 1) * R
    best = None
    for s in reversed(range(s_max + 1)):
        n = int(math.ceil(int(B/R) * (eta**s) / (s+1)))
        r = int(R * (eta**(-s)))  # min resource
        # sample n configs uniformly
        configs = [{"faiss":random.uniform(0.2,0.8), "bm25":random.uniform(0.1,0.6)} for _ in range(n)]
        # normalize to ensure w_f + w_b <= 1; set w_g = 1 - (w_f + w_b)
        for cfg in configs:
            if cfg["faiss"] + cfg["bm25"] > 0.95:
                ssum = cfg["faiss"] + cfg["bm25"]
                cfg["faiss"] /= ssum/0.95; cfg["bm25"] /= ssum/0.95
            cfg["graph"] = max(0.0, 1.0 - cfg["faiss"] - cfg["bm25"])
        for i in range(s+1):
            ni = int(n * (eta**(-i)))
            ri = int(r * (eta**(i)))  # resources grow
            scored = []
            for cfg in configs:
                m = evaluate(cfg, qrels, stores, bm25, budget=ri)
                val = scalarize(m, wa, ws, wc)
                scored.append((val, cfg, m))
            scored.sort(key=lambda x: x[0], reverse=True)
            # successive halving
            configs = [cfg for _, cfg, _ in scored[:max(1, ni//eta)]]
            if best is None or scored[0][0] > best[0]:
                best = scored[0]
    return best  # (score, weights, metrics)

def bohb(qrels, stores, bm25, R=27, eta=3, wa=0.7, ws=0.2, wc=0.1, rounds=3):
    # Simplified BOHB: TPE-like sampling around top quantile + Hyperband scheduling
    hist = []
    def sample():
        import random
        if len(hist) < 10:
            w_f = random.uniform(0.2,0.8); w_b = random.uniform(0.1,0.6)
        else:
            # bias towards good configs
            top = sorted(hist, key=lambda x:x[0], reverse=True)[:max(5, len(hist)//3)]
            mu_f = sum(w["faiss"] for _,w,_ in top)/len(top)
            mu_b = sum(w["bm25"] for _,w,_ in top)/len(top)
            w_f = min(0.8, max(0.2, random.gauss(mu_f, 0.1)))
            w_b = min(0.6, max(0.1, random.gauss(mu_b, 0.1)))
        if w_f + w_b > 0.95:
            ssum = w_f + w_b
            w_f /= ssum/0.95; w_b /= ssum/0.95
        return {"faiss": w_f, "bm25": w_b, "graph": max(0.0, 1.0 - w_f - w_b)}

    best = None
    for rd in range(rounds):
        res = hyperband(qrels, stores, bm25, R=R, eta=eta, wa=wa, ws=ws, wc=wc)
        if best is None or res[0] > best[0]:
            best = res
        hist.append(res)
    return best

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=str, default="data/tuning/sample_qrels.yaml")
    ap.add_argument("--algo", type=str, choices=["hs","bohb"], default="hs")
    ap.add_argument("--R", type=int, default=27, help="max resource (subset size)")
    ap.add_argument("--eta", type=int, default=3)
    ap.add_argument("--wa", type=float, default=0.7, help="weight for accuracy")
    ap.add_argument("--ws", type=float, default=0.2, help="weight for speed (lower time better)")
    ap.add_argument("--wc", type=float, default=0.1, help="weight for cost proxy (lower better)")
    args = ap.parse_args()

    stores = FaissDomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../../data/docs"))
    bm25 = BM25DomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../../data/docs"))
    qrels = load_qrels(args.dataset)

    if args.algo == "hs":
        best = hyperband(qrels, stores, bm25, R=args.R, eta=args.eta, wa=args.wa, ws=args.ws, wc=args.wc)
    else:
        best = bohb(qrels, stores, bm25, R=args.R, eta=args.eta, wa=args.wa, ws=args.ws, wc=args.wc)

    score, weights, metrics = best
    print("Best score:", score)
    print("Best weights:", weights)
    print("Metrics:", metrics)
    print("Suggested HYBRID_WEIGHTS:", f'faiss:{weights["faiss"]:.3f},bm25:{weights["bm25"]:.3f},graph:{weights["graph"]:.3f}')

if __name__ == "__main__":
    main()
