from __future__ import annotations
from typing import Dict, Any, List, Tuple, Optional
import re
from dateutil import parser as dtp

def _to_int(v) -> Optional[int]:
    try:
        if v is None: return None
        return int(str(v).strip())
    except Exception:
        return None

def _to_bool(v) -> Optional[bool]:
    if v is None: return None
    s = str(v).strip().lower()
    if s in ("true","yes","y","1"): return True
    if s in ("false","no","n","0"): return False
    return None

def validate_doctor(slots: Dict[str,Any]) -> Tuple[Dict[str,Any], List[str], List[str]]:
    norm = dict(slots or {})
    errs: List[str] = []
    missing: List[str] = []

    # age
    age = _to_int(norm.get("age"))
    if age is None: missing.append("age")
    elif not (0 <= age <= 120): errs.append("age 범위(0~120)를 벗어남")
    norm["age"] = age

    # sex
    sex_map = {"남":"male","여":"female","m":"male","f":"female","male":"male","female":"female"}
    sex = norm.get("sex")
    if sex is None: missing.append("sex")
    else:
        sx = sex_map.get(str(sex).lower(), None)
        if not sx: errs.append("sex 값은 male/female/other 중 하나여야 함")
        norm["sex"] = sx or sex

    # symptoms
    sy = norm.get("symptoms") or []
    if isinstance(sy, str): sy = [sy]
    sy = [s for s in sy if s]
    if not sy: missing.append("symptoms")
    norm["symptoms"] = sy

    # duration_days
    dd = _to_int(norm.get("duration_days"))
    if dd is None: missing.append("duration_days")
    elif dd < 0: errs.append("duration_days는 0 이상")
    norm["duration_days"] = dd

    # lists
    for k in ("chronic_conditions","medications","allergies"):
        v = norm.get(k) or []
        if isinstance(v, str): v = [v]
        norm[k] = [x for x in v if x]

    # pregnancy
    norm["pregnancy"] = _to_bool(norm.get("pregnancy"))

    return norm, missing, errs

def _parse_date(s) -> Optional[str]:
    if not s: return None
    try:
        d = dtp.parse(str(s)).date()
        return d.isoformat()
    except Exception:
        return None

def validate_travel(slots: Dict[str,Any]) -> Tuple[Dict[str,Any], List[str], List[str]]:
    norm = dict(slots or {}); errs=[]; missing=[]
    # country
    if not norm.get("country"): missing.append("country")
    # nights
    n = _to_int(norm.get("nights"))
    if n is None: missing.append("nights")
    elif n <= 0: errs.append("nights는 1 이상"); n = None
    norm["nights"] = n
    # travelers
    t = _to_int(norm.get("travelers"))
    if t is None: missing.append("travelers")
    elif t <= 0: errs.append("travelers는 1 이상"); t = None
    norm["travelers"] = t
    # kids_ages
    ka = norm.get("kids_ages") or []
    if isinstance(ka, str):
        ka = [x.strip() for x in re.split(r"[,\s]+", ka) if x.strip()]
    ka2 = []
    for x in ka:
        xi = _to_int(x)
        if xi is not None and xi >= 0:
            ka2.append(xi)
    norm["kids_ages"] = ka2
    # dates
    sd = _parse_date(norm.get("start_date")); ed = _parse_date(norm.get("end_date"))
    norm["start_date"], norm["end_date"] = sd, ed
    return norm, missing, errs

def validate_movie(slots: Dict[str,Any]) -> Tuple[Dict[str,Any], List[str], List[str]]:
    norm = dict(slots or {}); errs=[]; missing=[]
    # genres
    gs = norm.get("genres") or []
    if isinstance(gs, str): gs = [gs]
    gs = [g for g in gs if g]
    if not gs: missing.append("genres")
    norm["genres"] = gs
    # runtime_max
    rm = _to_int(norm.get("runtime_max"))
    if rm is not None and rm <= 0: errs.append("runtime_max는 1분 이상"); rm=None
    norm["runtime_max"] = rm
    return norm, missing, errs
