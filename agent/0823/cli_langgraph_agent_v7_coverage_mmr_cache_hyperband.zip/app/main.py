from __future__ import annotations
import argparse, os
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from app.state import AgentState
from app.router import route_node, branch
from app.agents.doctor import doctor_collect, doctor_answer
from app.agents.travel import travel_collect, travel_answer
from app.agents.movie import movie_collect, movie_answer
from app.rag.faiss_store import FaissDomainStores
from app.rag.bm25_store import BM25DomainStores
from app.policy.overlay import PolicyOverlay
from app.utils.streaming import stream_print

def build_graph(stores: FaissDomainStores, bm25: BM25DomainStores, overlay: PolicyOverlay):
    g = StateGraph(AgentState)

    # 라우팅
    g.add_node("route", route_node)

    # 의사
    g.add_node("doctor_collect", doctor_collect)
    g.add_node("doctor_answer", lambda s: doctor_answer(s, stores, bm25, overlay))

    # 여행
    g.add_node("travel_collect", travel_collect)
    g.add_node("travel_answer", lambda s: travel_answer(s, stores, bm25, overlay))

    # 영화
    g.add_node("movie_collect", movie_collect)
    g.add_node("movie_answer", lambda s: movie_answer(s, overlay))

    # 기타
    g.add_node("other", lambda s: {**s, "result_text": "죄송합니다. 해당 요청은 현재 범위를 벗어납니다. 질문을 보다 구체화하여 다시 요청해 주세요.", "sources": []})

    # 흐름
    g.add_edge(START, "route")
    g.add_conditional_edges("route", branch, {
        "doctor_collect": "doctor_collect",
        "travel_collect": "travel_collect",
        "movie_collect": "movie_collect",
        "other": "other"
    })
    # collect 결과에 따라 answer 또는 추가정보 획득 루프
    g.add_conditional_edges("doctor_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "doctor_answer"
    })
    g.add_edge("doctor_answer", END)

    g.add_conditional_edges("travel_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "travel_answer"
    })
    g.add_edge("travel_answer", END)

    g.add_conditional_edges("movie_collect", lambda s: "ask" if s.get("needs_more_info") else "answer", {
        "ask": END,
        "answer": "movie_answer"
    })
    g.add_edge("movie_answer", END)

    db_path = os.getenv("CHECKPOINT_DB", ".checkpoints/agent.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    memory = SqliteSaver(db_path)
    return g.compile(checkpointer=memory)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=str, default="default", help="세션/대화 ID (체크포인트 키)")
    ap.add_argument("--no-stream", action="store_true", help="스트리밍 비활성화")
    ap.add_argument("--retriever", type=str, default="hybrid", choices=["faiss","graphrag","hybrid"], help="검색기 선택")
    ap.add_argument("--overlay", type=str, default=None, help="오버레이 국가코드(예: KR, JP, AU). 미지정 시 OVERLAY_COUNTRY 사용")
    ap.add_argument("--weights", type=str, default=None, help="가중치 예: faiss:0.5,bm25:0.3,graph:0.2 (HYBRID_WEIGHTS 대체)")
    args = ap.parse_args()

    if args.weights:
        os.environ["HYBRID_WEIGHTS"] = args.weights

    if args.overlay:
        os.environ["OVERLAY_COUNTRY"] = args.overlay

    os.environ["USE_GRAPHRAG"] = "1" if args.retriever in ("graphrag","hybrid") else "0"

    stores = FaissDomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../data/docs"))
    bm25 = BM25DomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../data/docs"))
    overlay = PolicyOverlay(base_dir=os.path.join(os.path.dirname(__file__), "../data/policies"))
    graph = build_graph(stores, bm25, overlay)

    print("=== CLI 멀티-역할 에이전트 (LangChain + LangGraph / Hybrid FAISS+BM25+GraphRAG / Policy Overlay / Slot Validator) ===")
    print("세션:", args.session)
    print("모델:", os.getenv("OLLAMA_MODEL", "llama3:8b"))
    print("검색기:", args.retriever, " (가중치:", os.getenv("HYBRID_WEIGHTS","faiss:0.5,bm25:0.3,graph:0.2"), ")")
    print("오버레이:", os.getenv("OVERLAY_COUNTRY","(미설정)"))
    print("")

    while True:
        try:
            user = input("> 사용자 질문(또는 exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n종료합니다.")
            break
        if user.lower() in ("exit","quit","q"):
            print("종료합니다.")
            break

        config = {"configurable": {"thread_id": args.session}}
        state_in = {"messages": [HumanMessage(content=user)]}

        while True:
            out = graph.invoke(state_in, config=config)
            if out.get("needs_more_info"):
                q = out.get("followup_question", "추가 정보가 필요합니다.")
                print("\n[추가 질문]")
                stream_print(q, enabled=not args.no_stream)
                try:
                    ans = input("> 추가정보: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\n종료합니다."); return
                state_in = {"messages": [HumanMessage(content=ans)]}
                continue

            print("\n▼ 답변")
            if args.no_stream: print(out.get("result_text",""))
            else: stream_print(out.get("result_text",""), enabled=True)

            sources = out.get("sources",[]) or []
            if sources:
                print("\n[출처]")
                for s in sources:
                    print(f"[{s.get('idx')}] {s.get('title','')} — {s.get('url','')}")
            print("")
            break

if __name__ == "__main__":
    main()
