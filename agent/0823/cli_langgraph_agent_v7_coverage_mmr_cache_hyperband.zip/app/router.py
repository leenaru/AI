from __future__ import annotations
import os, re, json, yaml
from typing import Literal, Dict, Any, List, Tuple
from langchain_core.messages import SystemMessage, HumanMessage
from app.utils.llm import get_llm, cached_invoke
from app.state import AgentState, Intent

RULES_PATH = os.getenv("ROUTING_RULES", os.path.join(os.path.dirname(__file__), "../data/routing/rules.yaml"))
ROUTER_MODE = os.getenv("ROUTER_MODE", "hybrid")  # rules | llm | hybrid

def _load_rules() -> Dict[str, Any]:
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def rules_score(text: str) -> Intent:
    cfg = _load_rules()
    version = int(cfg.get("version", 1))
    defaults = cfg.get("defaults", {})
    threshold = float(defaults.get("threshold", cfg.get("threshold", 1.0)))
    syn_map = cfg.get("synonyms", {}) or {}
    labels = cfg.get("labels", {})

    def _cjk_len(text: str) -> int:
        import re
        return len(re.findall(r"[가-힣一-龥ぁ-んァ-ン]", text))
    def _expand_synonyms(words, syn_keys):
        out = list(words or [])
        for key in (syn_keys or []):
            out.extend(syn_map.get(key, []))
        seen=set();res=[]
        for w in out:
            if w not in seen: res.append(w); seen.add(w)
        return res
    def _score_label_v2(text: str, label_cfg: Dict[str, Any]) -> Tuple[float, int]:
        weights = (defaults.get("weights") or {})
        w_kw = float(weights.get("keyword", 1.0))
        w_rx = float(weights.get("regex", 2.0))
        w_all = float(weights.get("bonus_all", 0.5))
        w_syll = float(weights.get("syllable_weight", 0.03))
        import re
        score = 0.0; t_low = text.lower(); matched_chars = 0
        any_cfg = label_cfg.get("any") or {}
        kws_any = _expand_synonyms([str(k) for k in (any_cfg.get("keywords") or [])], [str(k) for k in (any_cfg.get("synonyms") or [])])
        for k in kws_any:
            if not k: continue
            if k.lower() in t_low:
                score += w_kw; matched_chars += _cjk_len(k)
        all_cfg = label_cfg.get("all") or {}
        kws_all = [str(k) for k in (all_cfg.get("keywords") or [])]
        if kws_all and all(k.lower() in t_low for k in kws_all): score += w_all
        for pattern in (label_cfg.get("regex") or []):
            try:
                if re.search(pattern, text, re.IGNORECASE):
                    score += w_rx
                    for m in re.finditer(pattern, text, re.IGNORECASE):
                        matched_chars += _cjk_len(m.group(0))
            except re.error: pass
        score += w_syll * matched_chars
        priority = int(label_cfg.get("priority", 0))
        return score, priority

    if isinstance(labels, dict):
        best=("other",0.0,0)
        t=text.lower()
        import re
        for name,spec in labels.items():
            sc=0.0
            for k in spec.get("keywords",[]):
                if k.lower() in t: sc += 1.0
            for pattern in spec.get("regex",[]):
                try:
                    if re.search(pattern, text, re.IGNORECASE): sc += 2.0
                except re.error: pass
            if sc>best[1]: best=(name,sc,0)
        return best[0] if best[1]>=threshold else "other"

    cands=[]
    for label in labels:
        name=label.get("name") or "other"
        sc,pr=_score_label_v2(text,label)
        cands.append((name,sc,pr))
    cands.sort(key=lambda x:(x[1],x[2]), reverse=True)
    best_name, best_score, _ = cands[0] if cands else ("other",0.0,0)
    return best_name if best_score>=threshold else "other"

SMART_SYS = SystemMessage(content=(
    "You are a smart intent classifier for a multi-agent system (doctor, travel, movie, other). "
    "Read the user's Korean/English message and return strict JSON: {\"intent\":\"doctor|travel|movie|other\",\"confidence\":0.0-1.0}. "
    "Guidelines: medical symptoms/diagnosis/medications -> doctor; trip planning/itineraries/countries/dates -> travel; "
    "film preferences/tickets -> movie; else other. Prefer 'doctor' if symptoms/medications predominate, 'travel' if destinations/dates predominate."
))

def smart_llm_route(text: str) -> Intent:
    out = cached_invoke([SMART_SYS, HumanMessage(content=text)], namespace="router_smart", ttl_sec=86400, streaming=False).content.strip()
    import re, json
    m = re.search(r"\{[\s\S]*\}", out)
    label = "other"
    if m:
        try:
            data = json.loads(m.group(0))
            cand = (data.get("intent") or "").lower()
            if cand in ("doctor","travel","movie","other"):
                label = cand
        except Exception:
            pass
    else:
        s = out.lower()
        for cand in ("doctor","travel","movie","other"):
            if cand in s:
                label = cand; break
    return label  # type: ignore

def route_node(state: AgentState) -> AgentState:
    if state.get("intent_locked") and state.get("intent"):
        return state
    user_txt = state["messages"][-1].content if hasattr(state["messages"][-1], "content") else str(state["messages"][-1])
    mode = os.getenv("ROUTER_MODE","hybrid")
    if mode=="rules":
        intent: Intent = rules_score(user_txt)
    elif mode=="llm":
        intent = smart_llm_route(user_txt)
    else:
        intent = rules_score(user_txt)
        if intent=="other":
            intent = smart_llm_route(user_txt)
    out = dict(state); out["intent"]=intent; return out

def branch(state: AgentState) -> Literal["doctor_collect","travel_collect","movie_collect","other"]:
    it = state.get("intent","other")
    if it == "doctor": return "doctor_collect"
    if it == "travel": return "travel_collect"
    if it == "movie": return "movie_collect"
    return "other"
