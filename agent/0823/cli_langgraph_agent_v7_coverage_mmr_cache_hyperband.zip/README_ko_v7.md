---
## v7 확장 사항
1) **Coverage 보장 MMR (GraphRAG 커뮤니티 기반)**
   - `fuse_coverage_mmr_debug()`:
     - **Step-A(커버리지)**: 후보의 커뮤니티를 점수화(평균 중앙성 + 평균 base)하여 상위 커뮤니티 비율(`COMMUNITY_COVERAGE_RATIO`, 기본 0.5)을 **최소 1개씩** 커버.
     - **Step-B(MMR)**: 남은 슬롯은 `(1-λ)*score - λ*max_sim` 탐욕 선택(`MMR_LAMBDA`, 기본 0.35). 중복·유사 스니펫 감소.
   - 파라미터:
     - `GRAPH_META_WEIGHT`(중앙성 가중, 기본 0.15)
     - `COMMUNITY_COVERAGE_RATIO`(커뮤니티 커버 비율, 기본 0.5)
     - `MMR_LAMBDA`(MMR trade-off, 기본 0.35)

2) **캐시 정책 고도화 + 대시보드**
   - LLM/Retrieval 모두 **TTL/최대행수/최대바이트** 제한 + **LRU 기반 제거** + **히트/미스/에빅션** 카운트.
   - 환경변수:
     - `LLM_CACHE_TTL_SEC`/`LLM_CACHE_MAX_ROWS`/`LLM_CACHE_MAX_BYTES`
     - `RET_CACHE_TTL_SEC`/`RET_CACHE_MAX_ROWS`/`RET_CACHE_MAX_BYTES`
   - 대시보드 CLI: `python -m app.ops.cache_dashboard --export-json cache_stats.json`

3) **튜너: 진짜 Hyperband(HS) & BOHB + 다목적(정확도/속도/비용)**
   - 스크립트: `app/tune/hyperband.py`
   - 정확도(hit, ndcg), **속도(평균 질의 시간)**, **비용 proxy(그래프 의존 + 시간)**를 통합 스칼라(wa/ws/wc)로 최적화.
   - 실행:
     ```bash
     # Hyperband
     python -m app.tune.hyperband --dataset data/tuning/sample_qrels.yaml --algo hs --R 27 --eta 3 --wa 0.7 --ws 0.2 --wc 0.1
     # BOHB
     python -m app.tune.hyperband --dataset data/tuning/sample_qrels.yaml --algo bohb --R 27 --eta 3 --wa 0.7 --ws 0.2 --wc 0.1
     ```
   - 출력된 가중치를 `HYBRID_WEIGHTS`로 적용.

### 개념 설명: 커버리지 보장 MMR이란?
- **문제**: 단순 상위 점수/중앙성만 고르면 같은 커뮤니티(유사 토픽)의 근거만 모여 **편향/중복**이 생김.
- **해결**: 먼저 **서로 다른 커뮤니티**를 최소한 커버(coverage)하여 **주요 관점**을 확보 → 그 다음 단계에서 **MMR**로 **중복을 억제**하며 **점수 높은** 스니펫을 선택.
- **이점**: 
  - **정확성**: 커뮤니티별 대표 근거를 확보해 누락 위험 감소.
  - **신뢰성**: 서로 다른 소스/관점 교차검증 쉬움.
  - **가독성**: 비슷비슷한 스니펫 연속 제시를 방지.

### 빠른 사용 예
```bash
export USE_GRAPHRAG=1
export GRAPH_META_WEIGHT=0.2
export COMMUNITY_COVERAGE_RATIO=0.6
export MMR_LAMBDA=0.35
python -m app.main --session demo --retriever hybrid --overlay US
```
