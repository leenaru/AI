from __future__ import annotations
import os, glob
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import numpy as np

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

class FaissDomainStores:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.emb_model = SentenceTransformer("all-MiniLM-L6-v2")
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=700, chunk_overlap=100
        )
        self._stores = {}

    def _collect_docs(self, domain: str):
        path = os.path.join(self.base_dir, domain)
        files = sorted(glob.glob(os.path.join(path, "*.md")))
        docs = []
        for fp in files:
            loader = TextLoader(fp, encoding="utf-8")
            for d in loader.load():
                # 메타데이터 추가
                d.metadata["source"] = fp
                d.metadata["title"] = os.path.splitext(os.path.basename(fp))[0]
                docs.append(d)
        # 분할
        splits = self.text_splitter.split_documents(docs)
        return splits

    def _ensure_store(self, domain: str):
        if domain in self._stores:
            return self._stores[domain]
        splits = self._collect_docs(domain)
        if not splits:
            self._stores[domain] = None
            return None
        store = FAISS.from_documents(
            splits,
            embedding=self.emb_model,  # SentenceTransformer는 LangChain에서 임베더로 작동
        )
        self._stores[domain] = store
        return store

    def embed(self, texts: List[str]) -> np.ndarray:
        return self.emb_model.encode(texts, normalize_embeddings=True)

    def search(self, domain: str, query: str, k: int = 5) -> List[Retrieved]:
        store = self._ensure_store(domain)
        if not store:
            return []
        docs_and_scores = store.similarity_search_with_score(query, k=k)
        results = []
        for i, (doc, sc) in enumerate(docs_and_scores):
            results.append(
                Retrieved(
                    text=doc.page_content,
                    url=doc.metadata.get("source", ""),
                    title=doc.metadata.get("title", ""),
                    score=float(sc),
                    id=f"{domain}-{i}"
                )
            )
        return results

def rrf_fuse(*ranked_lists: List[Retrieved], k: float = 60.0, topn: int = 6) -> List[Retrieved]:
    # Reciprocal Rank Fusion. 각 리스트는 이미 '좋은 순서'라고 가정.
    scores = {}
    items = {}
    for lst in ranked_lists:
        for rank, item in enumerate(lst, start=1):
            key = item.url + "|" + item.title + "|" + item.text[:32]
            items[key] = item
            scores[key] = scores.get(key, 0.0) + 1.0 / (k + rank)
    fused = sorted(items.values(), key=lambda it: scores[it.url + "|" + it.title + "|" + it.text[:32]], reverse=True)
    return fused[:topn]
