from __future__ import annotations
import os, yaml
from typing import Dict, Any, Optional

class PolicyOverlay:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.cache: Dict[str, Dict[str, Any]] = {}

    def _load(self, country_code: str) -> Dict[str, Any]:
        country_code = (country_code or "").upper()
        if country_code in self.cache:
            return self.cache[country_code]
        path = os.path.join(self.base_dir, f"{country_code}.yaml")
        if not os.path.exists(path):
            self.cache[country_code] = {}
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        self.cache[country_code] = data
        return data

    def get_context(self, country_code: str, domain: str) -> str:
        data = self._load(country_code)
        # domain: 'medical' | 'travel' | 'movie'
        lines = []
        sect = (data.get(domain) or {})
        if not sect:
            return ""
        title = sect.get("title")
        if title:
            lines.append(f"[# 정책 오버레이: {title}]")
        for k, v in (sect.get("notes") or {}).items():
            lines.append(f"- {k}: {v}")
        warn = sect.get("warnings")
        if warn:
            lines.append("[주의] " + warn)
        return "\n".join(lines)
