import os, sqlite3, hashlib, json, time

RC_DB = os.getenv("RET_CACHE_DB", ".cache/retrieval_cache.sqlite")
os.makedirs(os.path.dirname(RC_DB), exist_ok=True)

def _db():
    con = sqlite3.connect(RC_DB)
    con.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, v TEXT, t INTEGER)")
    return con

def _key(domain: str, question: str) -> str:
    import hashlib
    h = hashlib.sha256((domain + "||" + (question or "")).encode("utf-8")).hexdigest()
    return h

def get(domain: str, question: str):
    con = _db()
    row = con.execute("SELECT v FROM cache WHERE k=?", (_key(domain, question),)).fetchone()
    if not row: return None
    try:
        return json.loads(row[0])
    except Exception:
        return None

def put(domain: str, question: str, items):
    con = _db()
    con.execute("INSERT OR REPLACE INTO cache (k, v, t) VALUES (?,?,?)", (_key(domain, question), json.dumps(items, ensure_ascii=False), int(time.time())))
    con.commit()
