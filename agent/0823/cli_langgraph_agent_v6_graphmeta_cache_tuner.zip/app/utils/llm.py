import os, json, sqlite3, hashlib, time
from typing import Any, List
from langchain_community.chat_models import ChatOllama

CACHE_DB = os.getenv("LLM_CACHE_DB", ".cache/llm_cache.sqlite")
os.makedirs(os.path.dirname(CACHE_DB), exist_ok=True)

def _db():
    con = sqlite3.connect(CACHE_DB)
    con.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, v TEXT, t INTEGER)")
    return con

def _hash_messages(messages: List[Any], model: str, opts: dict) -> str:
    blob = json.dumps({
        "model": model,
        "opts": opts,
        "messages": [getattr(m, "content", str(m)) for m in messages]
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()

def get_llm(streaming: bool):
    # scalar profile
    opts = json.loads(os.getenv("OLLAMA_OPTIONS","{}") or "{}")
    if os.getenv("CHEAP_MODE","0") == "1":
        # conservative, cost-saving defaults (tweakable)
        opts.setdefault("num_ctx", 1024)
        opts.setdefault("temperature", 0.2)
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    # ChatOllama accepts some kwargs directly
    kwargs = {}
    if "temperature" in opts: kwargs["temperature"] = float(opts["temperature"])
    if "num_ctx" in opts: kwargs["num_ctx"] = int(opts["num_ctx"])
    return ChatOllama(model=model, streaming=streaming, **kwargs)

def cached_invoke(messages: List[Any], *, namespace: str = "default", ttl_sec: int = 86400, streaming: bool = False):
    # Cache only non-streaming calls (streaming=False)
    llm = get_llm(streaming=streaming)
    if streaming:
        return llm.invoke(messages)
    opts = json.loads(os.getenv("OLLAMA_OPTIONS","{}") or "{}")
    k = namespace + ":" + _hash_messages(messages, os.getenv("OLLAMA_MODEL","llama3:8b"), opts)
    con = _db()
    now = int(time.time())
    row = con.execute("SELECT v, t FROM cache WHERE k=?", (k,)).fetchone()
    if row and (now - int(row[1])) < ttl_sec:
        class Fake:
            content = row[0]
        return Fake()
    out = llm.invoke(messages)
    con.execute("INSERT OR REPLACE INTO cache (k, v, t) VALUES (?,?,?)", (k, getattr(out, "content", str(out)), now))
    con.commit()
    return out
