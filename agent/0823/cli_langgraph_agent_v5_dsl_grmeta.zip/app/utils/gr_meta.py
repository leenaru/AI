from __future__ import annotations
import os
from typing import List, Dict, Any
from rich.console import Console
from rich.table import Table

console = Console()

def show_graphrag_meta(nodes: List[Dict[str,Any]], edges: List[Dict[str,Any]], title: str):
    if os.getenv("SHOW_GRAPHRAG_META","0") != "1":
        return
    if nodes:
        t = Table(title=title + " — Nodes (top 8)")
        t.add_column("id", overflow="fold"); t.add_column("type"); t.add_column("title", overflow="fold"); t.add_column("score")
        for n in nodes[:8]:
            t.add_row(str(n.get("id","")), str(n.get("type","")), str(n.get("title","") or n.get("name","")), str(n.get("score","")))
        console.print(t)
    if edges:
        t2 = Table(title=title + " — Edges (top 8)")
        t2.add_column("source"); t2.add_column("relation"); t2.add_column("target"); t2.add_column("weight")
        for e in edges[:8]:
            t2.add_row(str(e.get("source","")), str(e.get("relation","")), str(e.get("target","")), str(e.get("weight","")))
        console.print(t2)
