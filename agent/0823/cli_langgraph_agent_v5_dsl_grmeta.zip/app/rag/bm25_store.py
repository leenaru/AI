from __future__ import annotations
import os, glob, re
from typing import List, Tuple
from dataclasses import dataclass
from rank_bm25 import BM25Okapi
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def _word_tokens(text: str) -> List[str]:
    text = text.lower()
    text = re.sub(r"[^0-9a-z가-힣]+", " ", text)
    return text.split()

def _cjk_ngrams(text: str, n: int = 2) -> List[str]:
    # 한글/한자 등 CJK 영역에 대해 문자 n-gram
    grams = []
    for i in range(len(text) - n + 1):
        seg = text[i:i+n]
        if re.search(r"[가-힣一-龥ぁ-んァ-ン]", seg):
            grams.append(seg)
    return grams

def tokenize(text: str) -> List[str]:
    mode = os.getenv("BM25_TOKENIZER", "ngram")  # simple | ngram
    if mode == "simple":
        return _word_tokens(text)
    # ngram 모드: 영문/숫자는 단어 토큰 + CJK는 2/3-gram 혼합
    base = _word_tokens(text)
    bi = _cjk_ngrams(text, 2)
    tri = _cjk_ngrams(text, 3)
    return base + bi + tri

class BM25DomainStores:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.text_splitter = RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=100)
        self._stores = {}   # domain -> (bm25, chunks, corpus_tokens)

    def _collect_chunks(self, domain: str):
        path = os.path.join(self.base_dir, domain)
        files = sorted(glob.glob(os.path.join(path, "*.md")))
        docs = []
        for fp in files:
            loader = TextLoader(fp, encoding="utf-8")
            for d in loader.load():
                d.metadata["source"] = fp
                d.metadata["title"] = os.path.splitext(os.path.basename(fp))[0]
                docs.append(d)
        chunks = self.text_splitter.split_documents(docs)
        return chunks

    def _ensure_store(self, domain: str):
        if domain in self._stores:
            return self._stores[domain]
        chunks = self._collect_chunks(domain)
        if not chunks:
            self._stores[domain] = None
            return None
        corpus_tokens = [tokenize(ch.page_content) for ch in chunks]
        bm25 = BM25Okapi(corpus_tokens)
        self._stores[domain] = (bm25, chunks, corpus_tokens)
        return self._stores[domain]

    def search(self, domain: str, query: str, k: int = 5) -> List[Retrieved]:
        store = self._ensure_store(domain)
        if not store:
            return []
        bm25, chunks, corpus_tokens = store
        q_tokens = tokenize(query or "")
        scores = bm25.get_scores(q_tokens)
        idxs = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]
        out: List[Retrieved] = []
        for i in idxs:
            doc = chunks[i]
            out.append(Retrieved(
                text=doc.page_content,
                url=doc.metadata.get("source",""),
                title=doc.metadata.get("title",""),
                score=float(scores[i]),
                id=f"{domain}-bm25-{i}"
            ))
        return out
