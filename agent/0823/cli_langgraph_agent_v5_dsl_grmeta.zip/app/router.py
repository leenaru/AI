from __future__ import annotations
import os, re, json, yaml
from typing import Literal, Dict, Any, List, Tuple
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState, Intent

RULES_PATH = os.getenv("ROUTING_RULES", os.path.join(os.path.dirname(__file__), "../data/routing/rules.yaml"))
ROUTER_MODE = os.getenv("ROUTER_MODE", "hybrid")  # rules | llm | hybrid

def get_llm():
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=False)

def _load_rules() -> Dict[str, Any]:
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def _cjk_len(text: str) -> int:
    # rough syllable length (CJK/한글 문자 수)
    return len(re.findall(r"[가-힣一-龥ぁ-んァ-ン]", text))

def _expand_synonyms(words: List[str], syn_keys: List[str], syn_map: Dict[str, List[str]]) -> List[str]:
    out = list(words or [])
    for key in (syn_keys or []):
        out.extend(syn_map.get(key, []))
    # deduplicate preserving order
    seen = set(); uniq = []
    for w in out:
        if w not in seen:
            uniq.append(w); seen.add(w)
    return uniq

def _score_label_v2(text: str, label_cfg: Dict[str, Any], defaults: Dict[str, Any], syn_map: Dict[str, List[str]]) -> Tuple[float, int]:
    weights = (defaults.get("weights") or {})
    w_kw = float(weights.get("keyword", 1.0))
    w_rx = float(weights.get("regex", 2.0))
    w_all = float(weights.get("bonus_all", 0.5))
    w_syll = float(weights.get("syllable_weight", 0.03))

    score = 0.0
    t_low = text.lower()

    # any: keywords + synonyms
    any_cfg = label_cfg.get("any") or {}
    kws_any = [str(k) for k in (any_cfg.get("keywords") or [])]
    syn_any = [str(k) for k in (any_cfg.get("synonyms") or [])]
    kws_any = _expand_synonyms(kws_any, syn_any, syn_map)

    hit_any = False
    matched_chars = 0
    for k in kws_any:
        if not k: continue
        if k.lower() in t_low:
            score += w_kw
            hit_any = True
            # syllable weighting by matched literal
            matched_chars += _cjk_len(k)

    # all: all keywords must appear to get bonus
    all_cfg = label_cfg.get("all") or {}
    kws_all = [str(k) for k in (all_cfg.get("keywords") or [])]
    if kws_all:
        if all(k.lower() in t_low for k in kws_all):
            score += w_all

    # regex
    for pattern in (label_cfg.get("regex") or []):
        try:
            if re.search(pattern, text, re.IGNORECASE):
                score += w_rx
                # approximate syllable contribution from matched span(s)
                for m in re.finditer(pattern, text, re.IGNORECASE):
                    span = m.group(0)
                    matched_chars += _cjk_len(span)
        except re.error:
            pass

    score += w_syll * matched_chars
    priority = int(label_cfg.get("priority", 0))
    return score, priority

def rules_score(text: str) -> Intent:
    cfg = _load_rules()
    version = int(cfg.get("version", 1))
    defaults = cfg.get("defaults", {})
    threshold = float(defaults.get("threshold", cfg.get("threshold", 1.0)))
    syn_map = cfg.get("synonyms", {}) or {}
    labels = cfg.get("labels", {})

    # backward compat: v1 used dict mapping; v2 uses list of label entries
    if isinstance(labels, dict):
        # v1: {label: {keywords, regex}}
        best = ("other", 0.0, 0)
        for name, spec in labels.items():
            score = 0.0
            t = text.lower()
            for k in spec.get("keywords", []):
                if k.lower() in t: score += 1.0
            for pattern in spec.get("regex", []):
                try:
                    if re.search(pattern, text, re.IGNORECASE): score += 2.0
                except re.error:
                    pass
            if score > best[1]: best = (name, score, 0)
        return best[0] if best[1] >= threshold else "other"  # type: ignore

    # v2: list of {name, priority, any/all/regex}
    candidates: List[Tuple[str, float, int]] = []
    for label in labels:
        name = label.get("name") or "other"
        sc, pr = _score_label_v2(text, label, defaults, syn_map)
        candidates.append((name, sc, pr))

    # pick highest by (score, priority)
    candidates.sort(key=lambda x: (x[1], x[2]), reverse=True)
    best_name, best_score, best_pri = candidates[0] if candidates else ("other", 0.0, 0)
    if best_score >= threshold:
        return best_name  # type: ignore
    return "other"

SMART_SYS = SystemMessage(content=(
    "You are a smart intent classifier for a multi-agent system (doctor, travel, movie, other). "
    "Read the user's Korean/English message and return strict JSON: {\"intent\":\"doctor|travel|movie|other\",\"confidence\":0.0-1.0}. "
    "Guidelines: medical symptoms/diagnosis/medications -> doctor; trip planning/itineraries/countries/dates -> travel; "
    "film preferences/tickets -> movie; else other. Prefer 'doctor' if symptoms/medications predominate, 'travel' if destinations/dates predominate."
))

def smart_llm_route(text: str) -> Intent:
    llm = get_llm()
    out = llm.invoke([SMART_SYS, HumanMessage(content=text)]).content.strip()
    m = re.search(r"\{[\s\S]*\}", out)
    label = "other"
    if m:
        try:
            data = json.loads(m.group(0))
            cand = (data.get("intent") or "").lower()
            if cand in ("doctor","travel","movie","other"):
                label = cand
        except Exception:
            pass
    else:
        s = out.lower()
        for cand in ("doctor","travel","movie","other"):
            if cand in s:
                label = cand; break
    return label  # type: ignore

def route_node(state: AgentState) -> AgentState:
    if state.get("intent_locked") and state.get("intent"):
        return state
    last = state["messages"][-1]
    user_txt = last.content if hasattr(last, "content") else str(last)

    mode = os.getenv("ROUTER_MODE", "hybrid")
    if mode == "rules":
        intent: Intent = rules_score(user_txt)
    elif mode == "llm":
        intent = smart_llm_route(user_txt)
    else:
        intent = rules_score(user_txt)
        if intent == "other":
            intent = smart_llm_route(user_txt)

    out = dict(state); out["intent"] = intent; return out

def branch(state: AgentState) -> Literal["doctor_collect","travel_collect","movie_collect","other"]:
    it = state.get("intent","other")
    if it == "doctor": return "doctor_collect"
    if it == "travel": return "travel_collect"
    if it == "movie": return "movie_collect"
    return "other"
