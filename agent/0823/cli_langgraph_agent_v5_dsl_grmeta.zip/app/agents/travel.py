from __future__ import annotations
import os
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.rag.faiss_store import FaissDomainStores, Retrieved as FRetrieved
from app.rag.bm25_store import BM25DomainStores, Retrieved as BRetrieved
from app.rag.graphrag_client import GraphRAGClient
from app.rag.hybrid import fuse_weighted_debug, Retrieved as HRetrieved
from app.utils.citation import split_sentences, assign_sentence_citations
from app.utils.streaming import ConsoleStreamCallback
from app.utils.slot_utils import extract_json_block
from app.utils.slot_validator import validate_travel
from app.policy.overlay import PolicyOverlay
from app.utils.visualize import show_confidence
from app.utils.gr_meta import show_graphrag_meta

SYS_EXTRACT = SystemMessage(content=(
    "Extract travel planning slots as JSON from the user's last message (Korean allowed). "
    "Keys: country (str|None), city (str|None), start_date (str|None), end_date (str|None), nights (int|None), "
    "travelers (int|None), kids_ages (list[int]), budget_level ('low'|'mid'|'high'|None), interests (list[str]). "
    "Return ONLY JSON."
))

SYS_ASKER = SystemMessage(content=(
    "You are a travel intake assistant. Ask only for missing/critical items (2~3 at once), in polite Korean."
))

SYS_ANSWER = SystemMessage(content=(
    "You are a precise travel planner. Use the provided context about destination and the policy overlay to propose a day-by-day plan, "
    "including logistics, food, kid-friendly options, and budget tips. Answer in Korean."
))

REQUIRED = ["country","nights","travelers"]

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def _merge(old: Dict[str,Any], new: Dict[str,Any]) -> Dict[str,Any]:
    out = dict(old or {})
    for k,v in (new or {}).items():
        if v in (None, "", [], {}): continue
        out[k] = v
    return out

def _weights_from_env():
    s = os.getenv("HYBRID_WEIGHTS","faiss:0.5,bm25:0.3,graph:0.2")
    w = dict(faiss=0.5, bm25=0.3, graph=0.2)
    try:
        for pair in s.split(","):
            k,v = pair.split(":")
            if k in w: w[k]=float(v)
    except Exception:
        pass
    return w

def travel_collect(state: AgentState) -> AgentState:
    state = dict(state); state["intent"] = "travel"; state["intent_locked"] = True
    llm = get_llm(streaming=False)
    user_text = state["messages"][-1].content
    raw = llm.invoke([SYS_EXTRACT, HumanMessage(content=user_text)]).content
    slots = extract_json_block(raw)

    merged = _merge(state.get("travel_slots", {}), slots)
    norm, missing, errs = validate_travel(merged)

    if errs or missing:
        ask_llm = get_llm(streaming=False)
        q = ask_llm.invoke([SYS_ASKER, HumanMessage(content=f"정규화된 슬롯: {norm}. 누락: {missing}. 오류: {errs}. 한국어로 간결히 질문.")]).content.strip()
        out = dict(state)
        out["travel_slots"] = norm
        out["needs_more_info"] = True
        out["followup_question"] = q
        out.setdefault("messages", []).append(AIMessage(content=q))
        return out

    out = dict(state)
    out["travel_slots"] = norm
    out["needs_more_info"] = False
    return out

def travel_answer(state: AgentState, stores: FaissDomainStores, bm25: BM25DomainStores, overlay: PolicyOverlay) -> AgentState:
    state = dict(state); state["intent"] = "travel"; state["intent_locked"] = False
    question = state["messages"][-1].content

    faiss_hits = [FRetrieved(**vars(h)) for h in stores.search("travel", question, k=6)]
    bm25_hits = [BRetrieved(**vars(h)) for h in bm25.search("travel", question, k=6)]
    graph_items = []
    gr_nodes, gr_edges = [], []
    if os.getenv("USE_GRAPHRAG","0") == "1":
        gr = GraphRAGClient().query(question, top_k=6)
        items = gr.get("items") if isinstance(gr, dict) else gr
        gr_nodes = gr.get("nodes", []) if isinstance(gr, dict) else []
        gr_edges = gr.get("edges", []) if isinstance(gr, dict) else []
        for g in items:
            graph_items.append(HRetrieved(text=g["text"], url=g["url"] or "GraphRAG", title=g["title"] or "GraphRAG", score=g["score"], id=g["id"]))

    ws = _weights_from_env()
    fused, debug = fuse_weighted_debug(faiss_hits, bm25_hits, graph_items, w_f=ws["faiss"], w_b=ws["bm25"], w_g=ws["graph"], topn=6)

    # 콘솔 시각화
    show_confidence(debug, fused, title="[여행] 신뢰도 스코어(정규화)")
    show_graphrag_meta(gr_nodes, gr_edges, title="[여행] GraphRAG 메타")

    slots = state.get("travel_slots", {})
    country = slots.get("country") or os.getenv("OVERLAY_COUNTRY","KR")
    overlay_block = overlay.get_context(country, "travel")
    overlay_block = f"\\n\\n[정책 오버레이]\\n{overlay_block}\\n" if overlay_block else ""

    context = "\\n\\n---\\n\\n".join([f"[{i+1}] {h.title} ({h.url})\\n{h.text}" for i,h in enumerate(fused)])
    prompt = HumanMessage(content=(
        f"사용자 요청: {question}\\n슬롯: {slots}\\n{overlay_block}"
        f"참고 자료:\\n{context}\\n\\n위 정보를 참고하여 날짜별 일정표, 교통/음식/아이 동반/예산 팁을 포함해 제안하세요."
    ))

    llm = get_llm(streaming=True)
    resp = llm.invoke([SYS_ANSWER, prompt]).content

    embedder = stores.embed
    doc_chunks = [dict(text=h.text, url=h.url, title=h.title, id=h.id, embedding=None) for h in fused]
    sents = split_sentences(resp)
    marked, srcs = assign_sentence_citations(sents, doc_chunks, embedder)

    out = dict(state)
    out["result_text"] = marked
    out["sources"] = srcs
    out["retriever_used"] = "hybrid"
    return out
