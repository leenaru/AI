from __future__ import annotations
import os, pandas as pd, json, re, argparse
from typing import List, Dict, Any, Optional
from datetime import datetime

def _norm(s):
    if s is None: return ""
    if isinstance(s, float) and pd.isna(s): return ""
    return str(s).strip()

def row_to_sentences(row: Dict[str, Any], key_cols: Optional[List[str]]=None, file_id: str = "", row_idx: int=0) -> List[str]:
    """
    Turn a table row into compact key=value facts to improve dense retrieval & BM25.
    Example: "country=Japan; nationality=KR; visa_free_days=90. [visa_policies.csv#row=3]"
    """
    pairs = []
    for k, v in row.items():
        ks = str(k).strip()
        vs = _norm(v)
        if vs == "": continue
        # normalize units like days/d
        if ks.lower().endswith("_days") and re.match(r"^\d+$", vs):
            vs = f"{vs} days"
        pairs.append(f"{ks}={vs}")
    # key-first ordering
    if key_cols:
        head, tail = [], []
        keys = set([c for c in key_cols])
        for p in pairs:
            k = p.split("=",1)[0]
            (head if k in keys else tail).append(p)
        pairs = head + tail
    line = "; ".join(pairs)
    anchor = f"[{file_id}#row={row_idx}]"
    return [f"{line}. {anchor}"]

def csv_to_markdown_sentences(csv_path: str, out_md: str, domain: str, key_cols: Optional[List[str]]=None, max_rows: Optional[int]=None) -> Dict[str, Any]:
    df = pd.read_csv(csv_path)
    if max_rows:
        df = df.head(max_rows)
    lines: List[str] = []
    file_id = os.path.basename(csv_path)
    for i, r in df.iterrows():
        lines.extend(row_to_sentences(r.to_dict(), key_cols=key_cols, file_id=file_id, row_idx=i))
    meta = f"<!-- source_type: csv | domain: {domain} | source: {file_id} | generated: {datetime.utcnow().isoformat()}Z -->"
    head = f"# CSV-derived facts from `{file_id}` (domain={domain})\n\n{meta}\n\n"
    text = head + "\n".join(f"- {ln}" for ln in lines) + "\n"
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    with open(out_md, "w", encoding="utf-8") as f:
        f.write(text)
    return {"rows": len(df), "out": out_md}

def csv_to_graph(json_nodes: str, json_edges: str, df: pd.DataFrame, entity_col: str, table_name: str, id_prefix: str="csv"):
    """
    Optional: export a tiny graph view (entity node + 'has_row' edges). This can seed GraphRAG builders.
    """
    nodes, edges = [], []
    seen = set()
    for i, r in df.iterrows():
        ent = _norm(r.get(entity_col, "")) or f"row_{i}"
        if ent not in seen:
            nodes.append({"id": f"{id_prefix}:{entity_col}:{ent}", "title": ent, "type":"entity"})
            seen.add(ent)
        nodes.append({"id": f"{id_prefix}:{table_name}:row:{i}", "title": f"{table_name} row {i}", "type":"row"})
        edges.append({"src": f"{id_prefix}:{entity_col}:{ent}", "dst": f"{id_prefix}:{table_name}:row:{i}", "rel": "has_row"})
    with open(json_nodes, "w", encoding="utf-8") as f: json.dump(nodes, f, ensure_ascii=False, indent=2)
    with open(json_edges, "w", encoding="utf-8") as f: json.dump(edges, f, ensure_ascii=False, indent=2)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out-md", required=True)
    ap.add_argument("--domain", required=True, choices=["medical","travel","movie","other"])
    ap.add_argument("--key-cols", nargs="*", default=None)
    ap.add_argument("--graph-entity-col", default=None)
    ap.add_argument("--graph-nodes", default=None)
    ap.add_argument("--graph-edges", default=None)
    ap.add_argument("--max-rows", type=int, default=None)
    args = ap.parse_args()

    info = csv_to_markdown_sentences(args.csv, args.out_md, args.domain, key_cols=args.key_cols, max_rows=args.max_rows)
    print("Wrote:", info)

    if args.graph_entity_col and args.graph_nodes and args.graph_edges:
        df = pd.read_csv(args.csv)
        csv_to_graph(args.graph_nodes, args.graph_edges, df, args.graph_entity_col, table_name=os.path.splitext(os.path.basename(args.csv))[0])

if __name__ == "__main__":
    main()