from __future__ import annotations
import os, argparse, yaml, wikipediaapi, re
from datetime import datetime

def clean_text(text: str) -> str:
    # Basic cleanup: collapse blank lines, strip excessive whitespace
    text = re.sub(r'\n{3,}', '\n\n', text.strip())
    return text

def page_to_markdown(page, lang: str) -> str:
    lines = [f"# {page.title}", "", f"<!-- source_type: wiki | lang: {lang} | source_url: {page.fullurl} | generated: {datetime.utcnow().isoformat()}Z -->", ""]
    if page.summary:
        lines.append("## Summary")
        lines.append(clean_text(page.summary))
        lines.append("")
    def add_sections(sections, level=2):
        for s in sections:
            if not s.text: continue
            lines.append("#" * level + f" {s.title}")
            lines.append(clean_text(s.text))
            lines.append("")
            add_sections(s.sections, level+1)
    add_sections(page.sections, level=2)
    return "\n".join(lines)

def fetch_and_write(title: str, lang: str, out_dir: str):
    wiki = wikipediaapi.Wikipedia(language=lang, extract_format=wikipediaapi.ExtractFormat.WIKI)
    page = wiki.page(title)
    if not page.exists():
        raise ValueError(f"Page not found: {title} ({lang})")
    md = page_to_markdown(page, lang)
    fname = f"wiki_{title.replace(' ','_')}_{lang}.md"
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as f:
        f.write(md)
    return fname

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, required=True, help="YAML with fields: lang, domain, titles[]")
    ap.add_argument("--out-dir", type=str, default=None)
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    lang = cfg.get("lang","en")
    domain = cfg.get("domain","other")
    titles = cfg.get("titles", [])
    out_dir = args.out_dir or os.path.join("data","docs", domain)

    results = []
    for t in titles:
        fname = fetch_and_write(t, lang, out_dir)
        results.append(fname)
    print("Wrote:", results)

if __name__ == "__main__":
    main()