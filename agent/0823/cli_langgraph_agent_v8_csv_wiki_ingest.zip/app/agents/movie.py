from __future__ import annotations
import os, json
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.utils.streaming import ConsoleStreamCallback
from app.utils.slot_utils import extract_json_block
from app.utils.slot_validator import validate_movie
from app.policy.overlay import PolicyOverlay

SYS_EXTRACT = SystemMessage(content=(
    "Extract movie preference slots as JSON from user's last message (Korean allowed). "
    "Keys: genres (list[str]), language (str|None), country (str|None), actors (list[str]), directors (list[str]), "
    "mood (str|None), runtime_max (int|None), age_rating (str|None), platform (str|None). Return ONLY JSON."
))

SYS_ASKER = SystemMessage(content=(
    "You are a movie concierge. Ask for the most useful missing preferences (2~3 at once), in polite Korean."
))

SYS_ANSWER = SystemMessage(content=(
    "You are a movie recommender. Given top-N candidates and preferences, justify each pick in 1-2 sentences, "
    "respect the policy overlay for ratings/platform hints, then ask one smart follow-up. Answer in Korean."
))

REQUIRED = ["genres"]

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def _merge(old: Dict[str,Any], new: Dict[str,Any]) -> Dict[str,Any]:
    out = dict(old or {})
    for k,v in (new or {}).items():
        if v in (None, "", [], {}): continue
        out[k] = v
    return out

def load_movies():
    import os, json
    fp = os.path.join(os.path.dirname(__file__), "../../data/movies.json")
    with open(fp, "r", encoding="utf-8") as f:
        return json.load(f)

def score(movie, slots: Dict[str,Any]) -> float:
    s = 0.0
    for g in movie.get("genres", []):
        if any(g.lower() in (x or "").lower() for x in slots.get("genres", [])):
            s += 1.2
    for a in movie.get("actors", []):
        if any(a.lower() in (x or "").lower() for x in slots.get("actors", [])):
            s += 0.9
    if (slots.get("country") or "").lower() == (movie.get("country","") or "").lower():
        s += 0.5
    s += 0.1 * float(movie.get("rating", 7.0))
    s += 0.01 * float(movie.get("votes", 1000))
    rm = slots.get("runtime_max")
    if rm and isinstance(rm, int):
        # 가벼운 패널티
        if movie.get("runtime", 120) > rm:
            s -= 0.3
    return s

def movie_collect(state: AgentState) -> AgentState:
    state = dict(state); state["intent"] = "movie"; state["intent_locked"] = True
    llm = get_llm(streaming=False)
    user_text = state["messages"][-1].content
    raw = llm.invoke([SYS_EXTRACT, HumanMessage(content=user_text)]).content
    slots = extract_json_block(raw)

    merged = _merge(state.get("movie_slots", {}), slots)
    norm, missing, errs = validate_movie(merged)

    if errs or missing:
        ask_llm = get_llm(streaming=False)
        q = ask_llm.invoke([SYS_ASKER, HumanMessage(content=f"정규화된 슬롯: {norm}. 누락: {missing}. 오류: {errs}. 한국어로 간결히 질문.")]).content.strip()
        out = dict(state)
        out["movie_slots"] = norm
        out["needs_more_info"] = True
        out["followup_question"] = q
        out.setdefault("messages", []).append(AIMessage(content=q))
        return out

    out = dict(state)
    out["movie_slots"] = norm
    out["needs_more_info"] = False
    return out

def movie_answer(state: AgentState, overlay: PolicyOverlay) -> AgentState:
    state = dict(state); state["intent"] = "movie"; state["intent_locked"] = False
    slots = state.get("movie_slots", {})
    movies = load_movies()
    ranked = sorted(movies, key=lambda m: score(m, slots), reverse=True)[:5]

    llm = get_llm(streaming=True)
    country = os.getenv("OVERLAY_COUNTRY","KR")
    overlay_txt = overlay.get_context(country, "movie")
    overlay_block = f"\n\n[정책 오버레이]\n{overlay_txt}\n" if overlay_txt else ""
    catalog = "\n".join([f"- {m['title']} ({m['year']}) | 장르: {', '.join(m['genres'])} | 배우: {', '.join(m['actors'][:3])}" for m in ranked])
    prompt = HumanMessage(content=(
        f"사용자 선호 슬롯: {slots}\n{overlay_block}후보 목록:\n{catalog}\n"
        "각 후보의 추천 이유를 1~2문장으로 설명하고, 마지막에 한 가지 추가 질문을 덧붙이세요."
    ))
    resp = llm.invoke([SYS_ANSWER, prompt]).content

    out = dict(state)
    out["result_text"] = resp
    out["sources"] = []
    out["retriever_used"] = "none"
    return out
