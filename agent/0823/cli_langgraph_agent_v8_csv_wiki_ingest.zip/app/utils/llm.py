import os, json, sqlite3, hashlib, time
from typing import Any, List
from langchain_community.chat_models import ChatOllama
from .cache_common import _ensure_stats, _bump, _set_stat, _get_stat

CACHE_DB = os.getenv("LLM_CACHE_DB", ".cache/llm_cache.sqlite")
os.makedirs(os.path.dirname(CACHE_DB), exist_ok=True)

TTL = int(os.getenv("LLM_CACHE_TTL_SEC", "86400"))
MAX_ROWS = int(os.getenv("LLM_CACHE_MAX_ROWS", "5000"))
MAX_BYTES = int(os.getenv("LLM_CACHE_MAX_BYTES", str(50*1024*1024)))  # 50MB default

def _db():
    con = sqlite3.connect(CACHE_DB)
    con.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, v TEXT, t INTEGER, sz INTEGER)")
    _ensure_stats(con)
    return con

def _evict_if_needed(con: sqlite3.Connection):
    # TTL eviction
    now = int(time.time())
    con.execute("DELETE FROM cache WHERE ? - t > ?", (now, TTL))
    # size/row eviction (LRU by t asc)
    row = con.execute("SELECT COUNT(*), COALESCE(SUM(sz),0) FROM cache").fetchone()
    cnt, total = int(row[0]), int(row[1] or 0)
    evicted = 0
    if cnt > MAX_ROWS or total > MAX_BYTES:
        for _ in range(cnt):
            if cnt <= MAX_ROWS and total <= MAX_BYTES: break
            r = con.execute("SELECT k, sz FROM cache ORDER BY t ASC LIMIT 1").fetchone()
            if not r: break
            con.execute("DELETE FROM cache WHERE k=?", (r[0],))
            evicted += 1
            cnt -= 1; total -= int(r[1] or 0)
    if evicted:
        _bump(con, "evictions", evicted)
    con.commit()

def _hash_messages(messages: List[Any], model: str, opts: dict) -> str:
    blob = json.dumps({
        "model": model,
        "opts": opts,
        "messages": [getattr(m, "content", str(m)) for m in messages]
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()

def get_llm(streaming: bool):
    opts = json.loads(os.getenv("OLLAMA_OPTIONS","{}") or "{}")
    if os.getenv("CHEAP_MODE","0") == "1":
        opts.setdefault("num_ctx", 1024)
        opts.setdefault("temperature", 0.2)
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    kwargs = {}
    if "temperature" in opts: kwargs["temperature"] = float(opts["temperature"])
    if "num_ctx" in opts: kwargs["num_ctx"] = int(opts["num_ctx"])
    return ChatOllama(model=model, streaming=streaming, **kwargs)

def cached_invoke(messages: List[Any], *, namespace: str = "default", ttl_sec: int = None, streaming: bool = False):
    llm = get_llm(streaming=streaming)
    if streaming:
        return llm.invoke(messages)
    ttl = TTL if ttl_sec is None else int(ttl_sec)
    opts = json.loads(os.getenv("OLLAMA_OPTIONS","{}") or "{}")
    k = namespace + ":" + _hash_messages(messages, os.getenv("OLLAMA_MODEL","llama3:8b"), opts)
    con = _db()
    now = int(time.time())

    # expire old & enforce limits
    _evict_if_needed(con)

    row = con.execute("SELECT v, t FROM cache WHERE k=?", (k,)).fetchone()
    if row and (now - int(row[1])) < ttl:
        _bump(con, "hits", 1)
        class Fake:
            content = row[0]
        return Fake()

    out = llm.invoke(messages)
    val = getattr(out, "content", str(out))
    sz = len(val.encode("utf-8"))
    con.execute("INSERT OR REPLACE INTO cache (k, v, t, sz) VALUES (?,?,?,?)", (k, val, now, sz))
    _bump(con, "misses", 1)
    con.commit()
    return out

def stats():
    con = _db()
    row = con.execute("SELECT COUNT(*), COALESCE(SUM(sz),0) FROM cache").fetchone()
    cnt, total = int(row[0]), int(row[1] or 0)
    return {
        "rows": cnt,
        "bytes": total,
        "hits": _get_stat(con, "hits"),
        "misses": _get_stat(con, "misses"),
        "evictions": _get_stat(con, "evictions")
    }
