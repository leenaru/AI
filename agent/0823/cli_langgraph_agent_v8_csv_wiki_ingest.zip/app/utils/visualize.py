from __future__ import annotations
import os
from typing import Dict, List
from rich.console import Console
from rich.table import Table
from rich.progress import BarColumn, Progress

console = Console()

def _bar(val: float, width: int = 12) -> str:
    val = max(0.0, min(1.0, float(val)))
    filled = int(round(val * width))
    return "▇"*filled + " "*(width-filled) + f" {val:.2f}"

def show_confidence(debug_scores: Dict[str, Dict[str, float]], items: List[object], title: str):
    if os.getenv("VIS_CONFIDENCE","0") != "1":
        return
    table = Table(title=title)
    table.add_column("Rank", justify="right")
    table.add_column("Title", overflow="fold")
    table.add_column("FAISS")
    table.add_column("BM25")
    table.add_column("GraphRAG")
    table.add_column("Final")

    def _key(it):
        return (getattr(it, "url", "") or "") + "|" + (getattr(it, "title", "") or "") + "|" + (getattr(it, "text","")[:32] if getattr(it,"text",None) else "")

    for i, it in enumerate(items, start=1):
        k = _key(it)
        sc = debug_scores.get(k, {"faiss":0,"bm25":0,"graph":0,"final":0})
        table.add_row(str(i), getattr(it,"title",""), _bar(sc["faiss"]), _bar(sc["bm25"]), _bar(sc["graph"]), _bar(sc["final"]))
    console.print(table)
