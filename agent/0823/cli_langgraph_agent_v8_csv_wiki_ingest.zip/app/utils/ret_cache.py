import os, sqlite3, hashlib, json, time
from .cache_common import _ensure_stats, _bump, _get_stat

RC_DB = os.getenv("RET_CACHE_DB", ".cache/retrieval_cache.sqlite")
os.makedirs(os.path.dirname(RC_DB), exist_ok=True)

TTL = int(os.getenv("RET_CACHE_TTL_SEC", "86400"))
MAX_ROWS = int(os.getenv("RET_CACHE_MAX_ROWS", "10000"))
MAX_BYTES = int(os.getenv("RET_CACHE_MAX_BYTES", str(200*1024*1024)))  # 200MB

def _db():
    con = sqlite3.connect(RC_DB)
    con.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, v TEXT, t INTEGER, sz INTEGER)")
    _ensure_stats(con)
    return con

def _evict_if_needed(con: sqlite3.Connection):
    now = int(time.time())
    con.execute("DELETE FROM cache WHERE ? - t > ?", (now, TTL))
    row = con.execute("SELECT COUNT(*), COALESCE(SUM(sz),0) FROM cache").fetchone()
    cnt, total = int(row[0]), int(row[1] or 0)
    evicted = 0
    if cnt > MAX_ROWS or total > MAX_BYTES:
        for _ in range(cnt):
            if cnt <= MAX_ROWS and total <= MAX_BYTES: break
            r = con.execute("SELECT k, sz FROM cache ORDER BY t ASC LIMIT 1").fetchone()
            if not r: break
            con.execute("DELETE FROM cache WHERE k=?", (r[0],))
            evicted += 1
            cnt -= 1; total -= int(r[1] or 0)
    if evicted:
        _bump(con, "evictions", evicted)
    con.commit()

def _key(domain: str, question: str) -> str:
    h = hashlib.sha256((domain + "||" + (question or "")).encode("utf-8")).hexdigest()
    return h

def get(domain: str, question: str):
    con = _db()
    _evict_if_needed(con)
    row = con.execute("SELECT v, t FROM cache WHERE k=?", (_key(domain, question),)).fetchone()
    if not row: 
        _bump(con, "misses", 1)
        return None
    if int(time.time()) - int(row[1]) > TTL:
        con.execute("DELETE FROM cache WHERE k=?", (_key(domain, question),))
        con.commit()
        _bump(con, "misses", 1)
        return None
    _bump(con, "hits", 1)
    try:
        return json.loads(row[0])
    except Exception:
        return None

def put(domain: str, question: str, items):
    con = _db()
    blob = json.dumps(items, ensure_ascii=False)
    sz = len(blob.encode("utf-8"))
    con.execute("INSERT OR REPLACE INTO cache (k, v, t, sz) VALUES (?,?,?,?)", (_key(domain, question), blob, int(time.time()), sz))
    con.commit()

def stats():
    con = _db()
    row = con.execute("SELECT COUNT(*), COALESCE(SUM(sz),0) FROM cache").fetchone()
    cnt, total = int(row[0]), int(row[1] or 0)
    return {"rows": cnt, "bytes": total, "hits": _get_stat(con, "hits"), "misses": _get_stat(con, "misses")}
