# CSV-derived facts from `visa_policies.csv` (domain=travel)

- country=Japan; nationality=KR; visa_required=no; visa_free_days=90 days; notes=Short-term tourism allowed; source=https://www.mofa.go.jp/j_info/visit/visa/short/novisa.html. [visa_policies.csv#row=0]
- country=United Kingdom; nationality=KR; visa_required=no; visa_free_days=180 days; notes=Up to 6 months as a visitor; source=https://www.gov.uk/standard-visitor. [visa_policies.csv#row=1]
- country=United States; nationality=KR; visa_required=esta; visa_free_days=90 days; notes=ESTA required for air/sea entry; source=https://esta.cbp.dhs.gov/. [visa_policies.csv#row=2]
- country=France; nationality=KR; visa_required=no; visa_free_days=90 days; notes=Schengen short-stay; source=https://france-visas.gouv.fr/. [visa_policies.csv#row=3]
- country=Thailand; nationality=KR; visa_required=no; visa_free_days=90 days; notes=Temporary extension policy may vary; source=https://www.immigration.go.th/. [visa_policies.csv#row=4]
