# v8 — CSV & Wikipedia Ingestion for RAG (Best Practices + Examples)

## 핵심 아이디어 (요약)
- **CSV**는 그대로는 임베딩 매칭이 약합니다. 각 **행(row)을 key=value 문장**으로 풀어 **table2text**로 변환해 RAG에 공급하면 **검색 적합도**가 크게 올라갑니다.
- **위키**는 섹션 구조가 좋아서 **섹션 단위 청크**를 만들고 **메타데이터(원문 URL/언어/도메인)**를 담아두면 **필터링·출처 표시**가 쉬워집니다.

---

## 1) CSV → RAG 최적화 전략
1. **table2text**: 각 행을 `key=value` 쌍으로 풀어 **자기완결 문장**을 생성 (예: `country=Japan; nationality=KR; visa_free_days=90.`).
2. **키 컬럼 우선**: `key_cols`를 앞에 배치(예: `country`, `nationality`) → 쿼리 키워드와 초반에 정렬되어 BM25/임베딩 모두 유리.
3. **단위/동의어 표준화**: `_days → "90 days"`처럼 **단위 통일**. 열 이름도 **동의어 사전**에 맞춰 표준화.
4. **행-앵커 출처**: `file#row=idx` 형태의 **앵커**를 문장 끝에 부착 → **문장별 출처 표시**에 직접 사용.
5. **그래프 보강(선택)**: 엔터티 열을 노드로, 행을 row-node로 만들어 `"has_row"` 엣지를 생성 → **GraphRAG** 초기 그래프 시드로 사용.

### 실행 예시
```bash
# CSV → md (table2text), travel 도메인으로 변환
python -m app.ingest.csv_ingest --csv data/docs/csv/visa_policies.csv   --out-md data/docs/travel/csv_visa_policies_sentences.md   --domain travel --key-cols country nationality   --graph-entity-col country   --graph-nodes data/docs/travel/visa_nodes.json   --graph-edges data/docs/travel/visa_edges.json
```

---

## 2) Wikipedia → RAG 최적화 전략
1. **섹션 단위 청크**: summary/section으로 나눠 저장 → **주제 일치**와 **근거 선택**이 정교해집니다.
2. **메타데이터**: `source_type=wiki`, `lang`, `source_url`을 헤더 코멘트에 기록 → **출처 표기·언어 필터**에 활용.
3. **클린업**: 표/주석/목차 노이즈는 제거하거나 텍스트로 평탄화.
4. **도메인 바인딩**: travel/medical 등 **도메인 폴더**에 저장해서 라우팅/필터를 단순화.

### 실행 예시
```bash
# 위키 → md (여행 도메인)
python -m app.ingest.wiki_ingest --config data/ingest/wiki_travel.yaml --out-dir data/docs/travel
# 위키 → md (의료 도메인)
python -m app.ingest.wiki_ingest --config data/ingest/wiki_medical.yaml --out-dir data/docs/medical
```

---

## 3) 인덱싱 팁 (기존 파이프라인에 그대로 호환)
- 본 레포는 `data/docs/<domain>/*.md`를 색인합니다. 위 과정으로 생성된 md 파일은 **그대로 FAISS/BM25** 대상에 포함됩니다.
- **메타 필터**: 문서 머리의 코멘트(`source_type: csv/wiki`)를 파싱하여 **도메인·소스별 가중치**나 **필터 검색**에 활용하세요.
- **청크 분할**: `RecursiveCharacterTextSplitter`에 **섹션 헤더 기반** 커스텀 분할기를 추가하면 더 좋습니다.

---

## 4) 고급: CSV 하이브리드 검색 루틴
- **문자열 검색(BM25)** + **임베딩 검색(FAISS)** + **구조 쿼리(컬럼 필터)**를 RRF/가중합으로 융합.
- 구조쿼리 예: `country in ['Japan','Thailand'] AND nationality='KR'` → 상위 행을 **sentences md**와 함께 노출.
- 현재 예제는 md로 펼치는 방법을 제공하며, 구조쿼리는 필요 시 `pandas.query`로 별도 구현하면 됩니다.

---

## 5) 문장별 출처 표시 연결
- `csv_ingest`가 남긴 앵커(`[visa_policies.csv#row=2]`)는 생성 답변의 **문장별 출처 태깅**에 그대로 쓰면 됩니다.
- 위키 md는 헤더 코멘트에 `source_url`이 있어 **링크형 출처**로 표기하기 쉽습니다.

---

## 6) 품질 팁
- CSV의 숫자/단위를 **정규화**하고, **키 컬럼**을 **앞쪽**에 배치합니다.
- 위키는 **섹션 제목**을 chunk 첫 줄에 항상 포함(검색 신호 강화).
- 라우터에서 `source_type`에 따른 **우선순위/가중치**(예: 의료=위키↑, 여행=CSV 정책↑)를 둘 수 있습니다.