from __future__ import annotations
import os, json, argparse, requests, pandas as pd
from typing import Any, Dict, List
from datetime import datetime
from pandas import json_normalize

def flatten_json_to_sentences(data: Any, source_tag: str, key_fields: List[str]=None) -> List[str]:
    """
    - Flattens nested JSON into a table via pandas.json_normalize, then
      emits key=value; ... sentences with anchor [api:<source_tag>#i=<row>]
    """
    if isinstance(data, list):
        df = json_normalize(data, sep=".")
    elif isinstance(data, dict):
        # try to find list-like leaf; if not, treat as single row
        try:
            # pick first list field if any
            list_field = next((k for k,v in data.items() if isinstance(v, list)), None)
            if list_field:
                df = json_normalize(data, record_path=[list_field], meta=[k for k in data.keys() if k!=list_field], sep=".")
            else:
                df = json_normalize([data], sep=".")
        except Exception:
            df = json_normalize([data], sep=".")
    else:
        df = pd.DataFrame([{"value": str(data)}])

    def norm(v):
        if v is None: return ""
        if isinstance(v, float) and pd.isna(v): return ""
        s = str(v)
        return s.replace("\n"," ").strip()

    sents = []
    for i, row in df.iterrows():
        parts = []
        # key-first
        cols = list(df.columns)
        if key_fields:
            head = [c for c in key_fields if c in cols]
            tail = [c for c in cols if c not in head]
            cols = head + tail
        for c in cols:
            val = norm(row[c])
            if val == "": continue
            parts.append(f"{c}={val}")
        if not parts: continue
        sents.append(f"{'; '.join(parts)}. [api:{source_tag}#i={i}]")
    return sents

def save_markdown(sentences: List[str], out_md: str, domain: str, src_url: str, source_tag: str):
    meta = f"<!-- source_type: api | domain: {domain} | src: {src_url} | tag: {source_tag} | generated: {datetime.utcnow().isoformat()}Z -->"
    text = "# API-derived facts\n\n" + meta + "\n\n" + "\n".join(f"- {s}" for s in sentences) + "\n"
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    with open(out_md, "w", encoding="utf-8") as f:
        f.write(text)

def fetch_api(url: str, method: str="GET", headers: Dict[str,str]=None, params: Dict[str,Any]=None, body: Dict[str,Any]=None, timeout: int=15):
    m = method.upper()
    r = requests.request(m, url, headers=headers, params=params, json=body, timeout=timeout)
    r.raise_for_status()
    return r.json()

# ---- LangGraph node (functional) ----
def api_json_node(state: Dict[str,Any]) -> Dict[str,Any]:
    """
    Expected in state["api_request"]:
        { "url":..., "method":"GET|POST", "headers":{...}, "params":{...}, "body":{...},
          "domain":"travel|medical|movie|other", "key_fields":["id","title",...],
          "out_md":"data/docs/<domain>/api_<tag>.md", "tag":"service_name" }
    Side effect: writes markdown file for RAG ingestion, and returns updated state with 'ingested_files' list.
    """
    req = state.get("api_request") or {}
    url = req.get("url"); domain = req.get("domain","other")
    tag = req.get("tag") or "api"
    if not url: return state
    data = fetch_api(url, method=req.get("method","GET"), headers=req.get("headers"), params=req.get("params"), body=req.get("body"))
    sentences = flatten_json_to_sentences(data, tag, key_fields=req.get("key_fields"))
    out_md = req.get("out_md") or os.path.join("data","docs",domain,f"api_{tag}.md")
    save_markdown(sentences, out_md, domain, url, tag)
    new = dict(state)
    new.setdefault("ingested_files", []).append(out_md)
    new["last_api_rows"] = len(sentences)
    return new

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--method", default="GET")
    ap.add_argument("--headers", type=str, default=None, help='JSON string')
    ap.add_argument("--params", type=str, default=None, help='JSON string')
    ap.add_argument("--body", type=str, default=None, help='JSON string')
    ap.add_argument("--domain", required=True)
    ap.add_argument("--tag", default="service")
    ap.add_argument("--key-fields", nargs="*", default=None)
    ap.add_argument("--out-md", type=str, default=None)
    args = ap.parse_args()

    headers = json.loads(args.headers) if args.headers else None
    params  = json.loads(args.params) if args.params else None
    body    = json.loads(args.body) if args.body else None

    data = fetch_api(args.url, method=args.method, headers=headers, params=params, body=body)
    sents = flatten_json_to_sentences(data, args.tag, key_fields=args.key_fields)
    out_md = args.out_md or os.path.join("data","docs",args.domain, f"api_{args.tag}.md")
    save_markdown(sents, out_md, args.domain, args.url, args.tag)
    print(json.dumps({"rows": len(sents), "out": out_md}, ensure_ascii=False))

if __name__ == "__main__":
    main()