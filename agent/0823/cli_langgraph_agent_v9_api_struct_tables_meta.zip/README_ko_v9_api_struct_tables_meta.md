# v9 — API JSON→RAG 노드, CSV 구조쿼리 하이브리드, Wiki 표→CSV, 메타 가중치

## 추가 기능 요약
1) **API JSON → RAG**: 외부 서비스 API 응답(JSON)을 받아 **table2text 문장**으로 변환하고 md 저장 → LangGraph 노드로 플러그인.
2) **CSV 구조 쿼리 + 하이브리드**: `pandas.query`로 CSV 행을 선별, 문장화하여 **텍스트 검색 결과와 융합**.
3) **Wiki 표→CSV 자동 추출**: infobox/HTML 테이블을 CSV로 저장하고 **table2text**로 결합.
4) **메타 가중치 정책**: `source_type/section/domain` 기반 **점수 multiplier** 적용해 도메인/소스/섹션 특성 반영.

---

## 1) API JSON → RAG (LangGraph 노드)
```python
# app/ingest/api_ingest.py
from app.ingest.api_ingest import api_json_node

# LangGraph에서 사용 예 (의사코드)
def node_api_fetch(state):
    # state['api_request']는 라우팅/슬롯수집 이후 채움
    return api_json_node(state)

# state['api_request'] 예:
# {
#   "url": "https://api.example.com/hotels?city=Tokyo",
#   "method": "GET",
#   "headers": {"Authorization":"Bearer ..."},
#   "params": {"limit": 50},
#   "domain": "travel",
#   "tag": "hotels_tokyo",
#   "key_fields": ["name","city","price_per_night","rating"],
#   "out_md": "data/docs/travel/api_hotels_tokyo.md"
# }
```
- 결과 md는 기존 파이프라인(FAISS/BM25/GraphRAG)에 자동 포함됩니다.
- 문장 끝 앵커: `[api:<tag>#i=<row>]` → 문장별 출처 표시에 직접 사용.

CLI:
```bash
python -m app.ingest.api_ingest   --url "https://api.example.com/hotels?city=Tokyo"   --method GET   --domain travel --tag hotels_tokyo   --key-fields name city price rating   --out-md data/docs/travel/api_hotels_tokyo.md
```

---

## 2) CSV 구조쿼리 + 하이브리드 융합
- 모듈: `app/retrieval/csv_struct_query.py`
- 사용:
```bash
python -m app.retrieval.csv_struct_query   --csv data/docs/csv/visa_policies.csv   --query "nationality=='KR' and visa_free_days>=90"   --out-md data/docs/travel/csv_struct_kr_visa90.md   --domain travel
```
- 런타임 융합: `fuse_text_and_struct(faiss, bm25, graphrag, struct_sents, struct_weight=0.35)`  
  또는 확장 하이브리드: `app/rag/hybrid_struct.py::fuse_with_meta(...)`로 **메타 가중치** 포함 점수화.

---

## 3) Wiki 표→CSV 추출 + table2text 결합
- 모듈: `app/ingest/wiki_tables.py`
- 기능: infobox→CSV, HTML 표→CSV 저장 후, `--table2text`로 문장 md까지 한번에 생성.
```bash
python -m app.ingest.wiki_tables   --title "Japan" --lang en   --out-dir data/docs/travel   --domain travel   --table2text
```
- 생성된 CSV는 다시 `csv_ingest`로 돌려 **정규화된 table2text 문장**을 더 만들 수 있습니다.

> 주의: 실제 실행은 인터넷 연결이 필요합니다.

---

## 4) 메타 가중치 정책
- 정책 파일: `data/policy/meta_weights.yaml`
```yaml
source_type:
  csv: 1.05
  csv_struct: 1.10
  wiki: 1.00
  api: 1.08
section:
  Summary: 1.15
  Warnings: 1.15
domain:
  medical: 1.10
  travel: 1.05
```
- 적용 코드: `app/policy/meta_weights.py::score_multiplier(meta)`  
- 하이브리드 적용: `app/rag/hybrid_struct.py::fuse_with_meta(...)`에서 **base 점수 × multiplier**

---

## 운영 팁
- **JSON 키 매핑**: API 스키마가 복잡하면 `key_fields`를 지정해 핵심 키를 앞쪽에 배치.  
- **구조쿼리 우선권**: 정책적으로 `csv_struct` multiplier를 높여 **정책/규정성 데이터**를 강조.  
- **Wiki 테이블**: infobox는 수치/속성이 정리되어 있어 **사실 질의**에 강함 — table2text와 결합하면 BM25/임베딩 모두에 유리.
- **오류 대응**: API 실패/타임아웃 시 노드에서 state에 `last_api_rows=0`을 기록, 파이프라인 상위에서 graceful fallback.