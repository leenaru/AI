
from __future__ import annotations
import os, json, glob
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, Body, Query, BackgroundTasks
from pydantic import BaseModel
from rank_bm25 import BM25Okapi
import numpy as np

# Optional FAISS
FAISS_ENABLED = False
try:
    import faiss  # type: ignore
    FAISS_ENABLED = True
except Exception:
    FAISS_ENABLED = False

from .vec import hash_embed
from .tuner import load_qrels, hyperband

CORPUS_DIR = os.getenv("CORPUS_DIR", "data/corpus")

app = FastAPI(title="Retrieval Service", version="0.2-hybrid-tuner")

def current_version() -> str:
    path = os.path.join(CORPUS_DIR, "current_version.txt")
    return open(path,"r",encoding="utf-8").read().strip() if os.path.exists(path) else ""

def read_docs(version: str, domain: str) -> List[str]:
    root = os.path.join(CORPUS_DIR, version, domain)
    texts = []
    for md in glob.glob(os.path.join(root, "*.md")):
        try:
            s = open(md, "r", encoding="utf-8", errors="ignore").read()
            chunks = [ln.strip("- ").strip() for ln in s.splitlines() if ln.strip().startswith("- ")]
            if not chunks:
                chunks = [s]
            texts.extend(chunks)
        except Exception:
            continue
    return texts

class SearchReq(BaseModel):
    domain: str
    query: str
    k: int = 6
    version: Optional[str] = None
    weights: Optional[Dict[str, float]] = None

class Weights(BaseModel):
    bm25: float = 0.5
    faiss: float = 0.5

class TuneReq(BaseModel):
    qrels_path: str = "data/tuning/sample_qrels.yaml"
    R: int = 27
    eta: int = 3
    wa: float = 0.8
    ws: float = 0.2
    k: int = 6
    domain: Optional[str] = None
    version: Optional[str] = None

@app.get("/health")
def health():
    return {"ok": True, "faiss": FAISS_ENABLED, "version": current_version()}

BM25_INDEX: Dict[str, Any] = {}
FAISS_INDEX: Dict[str, Any] = {}
FUSION_WEIGHTS: Dict[str, Dict[str,float]] = {}
TUNE_STATUS: Dict[str, Any] = {"running": False}

def key(version: str, domain: str) -> str:
    return f"{version}:{domain}"

def ensure_bm25(version: str, domain: str):
    k = key(version, domain)
    if k in BM25_INDEX: return
    docs = read_docs(version, domain)
    tok = [d.lower().split() for d in docs]
    BM25_INDEX[k] = {"docs": docs, "bm25": BM25Okapi(tok)}

def ensure_faiss(version: str, domain: str):
    if not FAISS_ENABLED: return
    k = key(version, domain)
    if k in FAISS_INDEX: return
    docs = BM25_INDEX.get(k, {}).get("docs")
    if docs is None:
        ensure_bm25(version, domain)
        docs = BM25_INDEX[k]["docs"]
    dim = int(os.getenv("EMBED_DIM","512"))
    X = hash_embed(docs, dim=dim)
    idx = faiss.IndexFlatIP(X.shape[1])
    idx.add(X)
    FAISS_INDEX[k] = {"docs": docs, "index": idx, "vecs": X}

def get_weights(version: str, domain: str) -> Dict[str,float]:
    k = key(version, domain)
    w = FUSION_WEIGHTS.get(k)
    if w: return w
    wpath = os.path.join(CORPUS_DIR, version, "weights.json")
    if os.path.exists(wpath):
        obj = json.load(open(wpath,"r",encoding="utf-8"))
        if domain in obj:
            FUSION_WEIGHTS[k] = obj[domain]
            return obj[domain]
    FUSION_WEIGHTS[k] = {"bm25": 0.5, "faiss": 0.5 if FAISS_ENABLED else 0.0}
    return FUSION_WEIGHTS[k]

def save_weights(version: str, domain: str, weights: Dict[str,float]):
    k = key(version, domain)
    FUSION_WEIGHTS[k] = weights
    wpath = os.path.join(CORPUS_DIR, version, "weights.json")
    obj = {}
    if os.path.exists(wpath):
        try: obj = json.load(open(wpath,"r",encoding="utf-8"))
        except Exception: obj = {}
    obj[domain] = weights
    with open(wpath, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def fuse_scores(bm25_scores: np.ndarray, faiss_scores: Optional[np.ndarray], weights: Dict[str,float]) -> np.ndarray:
    def norm(x):
        if x is None: return None
        lo, hi = float(np.min(x)), float(np.max(x))
        if hi <= lo: 
            return np.zeros_like(x, dtype="float32")
        return (x - lo) / (hi - lo + 1e-9)
    nb = norm(bm25_scores)
    if faiss_scores is not None:
        nf = norm(faiss_scores)
        return weights.get("bm25",0.5)*nb + weights.get("faiss",0.5)*nf
    else:
        return nb

def _search_internal(version: str, domain: str, query: str, k: int, weights: Dict[str,float]) -> List[Dict[str,Any]]:
    ensure_bm25(version, domain)
    idx = BM25_INDEX[key(version, domain)]
    b_scores = idx["bm25"].get_scores(query.lower().split()).astype("float32")
    f_scores = None
    if FAISS_ENABLED and weights.get("faiss",0.0) > 0.0:
        ensure_faiss(version, domain)
        v = FAISS_INDEX[key(version, domain)]
        qv = hash_embed([query], dim=v["vecs"].shape[1])
        f_scores = (v["vecs"] @ qv.T).reshape(-1)
    fused = fuse_scores(b_scores, f_scores, weights)
    topk = np.argsort(fused)[-k:][::-1]
    out = []
    docs = BM25_INDEX[key(version, domain)]["docs"]
    for rank, i in enumerate(topk):
        out.append({
            "rank": rank+1,
            "text": docs[int(i)],
            "score": float(fused[int(i)]),
            "components": {
                "bm25": float(b_scores[int(i)]),
                "faiss": float(f_scores[int(i)]) if f_scores is not None else None
            },
            "meta": {"version": version, "domain": domain}
        })
    return out

class SearchResp(BaseModel):
    items: list
    weights: dict

@app.post("/search", response_model=SearchResp)
def search(req: SearchReq):
    ver = req.version or current_version()
    if not ver: return {"items": [], "weights": {"bm25":1.0,"faiss":0.0}}
    w = req.weights or get_weights(ver, req.domain)
    items = _search_internal(ver, req.domain, req.query, req.k, w)
    return {"items": items, "weights": w}

@app.get("/config/weights")
def get_current_weights(domain: str = Query(...), version: Optional[str] = Query(None)):
    ver = version or current_version()
    return {"version": ver, "domain": domain, "weights": get_weights(ver, domain)}

@app.post("/config/weights")
def set_weights(domain: str = Query(...), version: Optional[str] = Query(None), body: Weights = Body(...)):
    ver = version or current_version()
    w = {"bm25": float(body.bm25), "faiss": float(body.faiss)}
    save_weights(ver, domain, w)
    return {"ok": True, "version": ver, "domain": domain, "weights": w}

# ---- Tuning ----
TUNE_STATUS: Dict[str, Any] = {"running": False}

def _search_for_tune(domain: str, query: str, k: int, weights: Dict[str,float]):
    ver = current_version()
    return _search_internal(ver, domain, query, k, weights)

def run_tuning(qrels_path: str, R: int, eta: int, wa: float, ws: float, k: int, domain_filter: Optional[str] = None):
    TUNE_STATUS.update({"running": True, "stage": "loading"})
    qrels = load_qrels(qrels_path)
    if domain_filter:
        qrels = [q for q in qrels if q.domain == domain_filter]
    TUNE_STATUS.update({"running": True, "stage": "hyperband", "total": len(qrels)})
    best = hyperband(_search_for_tune, qrels, R=R, eta=eta, wa=wa, ws=ws, k=k)
    score, weights, metrics = best
    ver = current_version()
    domains = {domain_filter} if domain_filter else {q.domain for q in qrels}
    for d in domains:
        save_weights(ver, d, weights)
    TUNE_STATUS.update({"running": False, "best": {"score": score, "weights": weights, "metrics": metrics, "version": ver, "domains": list(domains)}})

@app.post("/tune/start")
def tune_start(body: TuneReq, bg: BackgroundTasks):
    if TUNE_STATUS.get("running"):
        return {"running": True, "note": "already running"}
    bg.add_task(run_tuning, body.qrels_path, body.R, body.eta, body.wa, body.ws, body.k, body.domain)
    return {"started": True}

@app.get("/tune/status")
def tune_status():
    return TUNE_STATUS
