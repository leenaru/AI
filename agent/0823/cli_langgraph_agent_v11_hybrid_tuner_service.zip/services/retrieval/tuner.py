
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Callable
import random, math, yaml

@dataclass
class Qrel:
    query: str
    domain: str
    relevant_contains: List[str]

def load_qrels(path: str) -> List[Qrel]:
    data = yaml.safe_load(open(path, "r", encoding="utf-8"))
    out = []
    for row in data:
        out.append(Qrel(query=row["query"], domain=row["domain"], relevant_contains=row.get("relevant_contains", [])))
    return out

def evaluate_once(search_fn, qrels: List[Qrel], k: int, weights: Dict[str,float]) -> Dict[str,float]:
    import time, math
    hit, ndcg, tt = 0.0, 0.0, 0.0
    for qr in qrels:
        t0 = time.time()
        items = search_fn(qr.domain, qr.query, k, weights)
        t1 = time.time()
        # Hit@k
        h = 0.0
        relset = [s.lower() for s in qr.relevant_contains]
        for it in items[:k]:
            if any(s in (it.get("text","").lower()) for s in relset):
                h = 1.0; break
        # nDCG@k (binary gain)
        gains = [1.0 if any(s in (it.get("text","").lower()) for s in relset) else 0.0 for it in items[:k]]
        dcg = sum(g/(math.log2(i+2)) for i,g in enumerate(gains))
        idcg = sum(1.0/(math.log2(i+2)) for i in range(int(sum(gains))))
        nd = dcg/(idcg or 1.0)
        hit += h; ndcg += nd; tt += (t1-t0)
    n = max(1,len(qrels))
    return {"hit": hit/n, "ndcg": ndcg/n, "time": tt/n}

def scalarize(m, wa, ws):
    acc = 0.6*m["hit"] + 0.4*m["ndcg"]
    spd = 1.0/(1.0+m["time"])
    return wa*acc + ws*spd

def hyperband(search_fn, qrels: List[Qrel], R=27, eta=3, wa=0.8, ws=0.2, k=6):
    s_max = int(math.log(R, eta))
    B = (s_max + 1) * R
    best = None
    for s in reversed(range(s_max+1)):
        n = int(math.ceil(int(B/R) * (eta**s) / (s+1)))
        r = int(R * (eta**(-s)))
        configs = [{"bm25": random.uniform(0.2,0.8)} for _ in range(n)]
        for cfg in configs:
            cfg["faiss"] = max(0.0, 1.0 - cfg["bm25"])
        for i in range(s+1):
            ni = int(n * (eta**(-i)))
            ri = int(r * (eta**(i)))
            scored = []
            import random as _rand
            subset = qrels if len(qrels)<=ri else _rand.sample(qrels, ri)
            for cfg in configs:
                m = evaluate_once(search_fn, subset, k, cfg)
                val = scalarize(m, wa, ws)
                scored.append((val, cfg, m))
            scored.sort(key=lambda x:x[0], reverse=True)
            configs = [cfg for _,cfg,_ in scored[:max(1, ni//eta)]]
            if best is None or scored[0][0] > best[0]:
                best = scored[0]
    return best  # (score, cfg, metrics)
