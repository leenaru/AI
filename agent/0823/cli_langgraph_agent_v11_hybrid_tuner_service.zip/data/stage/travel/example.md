# Example

<!-- source_type: csv | domain: travel -->

- country=Japan; nationality=KR; visa_free_days=90. [visa_policies.csv#row=0]
