from __future__ import annotations
import os, json
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.utils.streaming import ConsoleStreamCallback

SYS = SystemMessage(content=(
    "You are a movie recommender. "
    "Given top-N candidates with metadata, craft a short rationale and ask one smart follow-up if needed. "
    "Answer in Korean."
))

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def load_movies():
    fp = os.path.join(os.path.dirname(__file__), "../../data/movies.json")
    with open(fp, "r", encoding="utf-8") as f:
        return json.load(f)

def score(movie, query: str) -> float:
    q = query.lower()
    s = 0.0
    for g in movie.get("genres", []):
        if g.lower() in q:
            s += 1.0
    for k in movie.get("keywords", []):
        if k.lower() in q:
            s += 0.8
    for a in movie.get("actors", []):
        if a.lower() in q:
            s += 0.9
    if movie.get("country","").lower() in q:
        s += 0.5
    s += 0.1 * float(movie.get("rating", 7.0))
    s += 0.01 * float(movie.get("votes", 1000))
    return s

def movie_node(state: AgentState) -> AgentState:
    question = state["messages"][-1].content
    movies = load_movies()
    ranked = sorted(movies, key=lambda m: score(m, question), reverse=True)[:5]

    llm = get_llm(streaming=True)
    catalog = "\n".join([f"- {m['title']} ({m['year']}) | 장르: {', '.join(m['genres'])} | 배우: {', '.join(m['actors'][:3])}" for m in ranked])
    prompt = HumanMessage(content=(
        f"사용자 선호: {question}\n후보 목록:\n{catalog}\n"
        "각 후보의 추천 이유를 1~2문장으로 설명하고, 마지막에 한 가지 추가 질문을 덧붙이세요."
    ))
    resp = llm.invoke([SYS, prompt]).content

    out = dict(state)
    out["result_text"] = resp
    out["sources"] = []
    out["retriever_used"] = "none"
    return out
