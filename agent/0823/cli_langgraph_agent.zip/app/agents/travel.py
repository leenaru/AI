from __future__ import annotations
import os
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.rag.faiss_store import FaissDomainStores, rrf_fuse, Retrieved
from app.rag.graphrag_client import GraphRAGClient
from app.utils.citation import split_sentences, assign_sentence_citations
from app.utils.streaming import ConsoleStreamCallback

SYS = SystemMessage(content=(
    "You are a precise travel planner. "
    "Extract country, city, dates, travelers (esp. kids), and preferences. "
    "If missing key info, make reasonable assumptions and clearly state them. "
    "Use provided context about the destination to propose a daily schedule with logistics and tips. "
    "Answer in Korean."
))

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def travel_node(state: AgentState, stores: FaissDomainStores) -> AgentState:
    question = state["messages"][-1].content
    faiss_hits = stores.search("travel", question, k=6)
    hits = faiss_hits
    retriever_used = "faiss"
    if os.getenv("USE_GRAPHRAG", "0") == "1":
        gr = GraphRAGClient().query(question, top_k=6)
        gr_hits: list[Retrieved] = []
        if faiss_hits:
            T = type(faiss_hits[0])
            for g in gr:
                gr_hits.append(T(text=g["text"], url=g["url"] or "GraphRAG", title=g["title"] or "GraphRAG", score=g["score"], id=g["id"]))
            hits = rrf_fuse(faiss_hits, gr_hits)
            retriever_used = "hybrid"

    context = "\n\n---\n\n".join([f"[{i+1}] {h.title} ({h.url})\n{h.text}" for i, h in enumerate(hits)])
    prompt = HumanMessage(content=(
        f"사용자 요청: {question}\n\n"
        f"참고 자료:\n{context}\n\n"
        "위 자료를 참고해 최적 일정을 제안하고, 아이 동반/교통/예산 팁도 포함하세요."
    ))

    llm = get_llm(streaming=True)
    resp = llm.invoke([SYS, prompt]).content

    embedder = stores.embed
    doc_chunks = [dict(text=h.text, url=h.url, title=h.title, id=h.id, embedding=None) for h in hits]
    sents = split_sentences(resp)
    marked, srcs = assign_sentence_citations(sents, doc_chunks, embedder)

    out = dict(state)
    out["result_text"] = marked
    out["sources"] = srcs
    out["retriever_used"] = retriever_used
    return out
