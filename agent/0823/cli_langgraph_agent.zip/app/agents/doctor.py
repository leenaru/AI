from __future__ import annotations
import os
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState
from app.rag.faiss_store import FaissDomainStores, rrf_fuse, Retrieved
from app.rag.graphrag_client import GraphRAGClient
from app.utils.citation import split_sentences, assign_sentence_citations
from app.utils.streaming import ConsoleStreamCallback

SYS = SystemMessage(content=(
    "You are a cautious medical assistant. "
    "Ask minimal follow-ups only if critical info is missing. "
    "Use the provided context to hypothesize possible conditions (not a diagnosis), list red flags, and suggest OTC/home care when appropriate. "
    "ALWAYS include a disclaimer to consult a professional. "
    "Answer in Korean."
))

def get_llm(streaming: bool):
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=streaming, callbacks=[ConsoleStreamCallback(enabled=streaming)])

def doctor_node(state: AgentState, stores: FaissDomainStores) -> AgentState:
    question = state["messages"][-1].content
    # RAG
    faiss_hits = stores.search("medical", question, k=6)
    hits = faiss_hits
    retriever_used = "faiss"
    if os.getenv("USE_GRAPHRAG", "0") == "1":
        gr = GraphRAGClient().query(question, top_k=6)
        gr_hits: list[Retrieved] = []
        if faiss_hits:
            T = type(faiss_hits[0])
            for g in gr:
                gr_hits.append(T(text=g["text"], url=g["url"] or "GraphRAG", title=g["title"] or "GraphRAG", score=g["score"], id=g["id"]))
            hits = rrf_fuse(faiss_hits, gr_hits)
            retriever_used = "hybrid"

    context = "\n\n---\n\n".join([f"[{i+1}] {h.title} ({h.url})\n{h.text}" for i, h in enumerate(hits)])
    prompt = HumanMessage(content=f"사용자 질문: {question}\n\n참고 문서:\n{context}\n\n참고 문서를 바탕으로 한국어로 답변하세요. 문장마다 신뢰 근거에 의존하도록 하세요.")

    llm = get_llm(streaming=True)
    resp = llm.invoke([SYS, prompt]).content

    embedder = stores.embed
    doc_chunks = [dict(text=h.text, url=h.url, title=h.title, id=h.id, embedding=None) for h in hits]
    sents = split_sentences(resp)
    marked, srcs = assign_sentence_citations(sents, doc_chunks, embedder)

    out = dict(state)
    out["result_text"] = marked
    out["sources"] = srcs
    out["retriever_used"] = retriever_used
    return out
