from __future__ import annotations
import os
from typing import Literal
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_community.chat_models import ChatOllama
from app.state import AgentState, Intent

def get_llm():
    model = os.getenv("OLLAMA_MODEL", "llama3:8b")
    return ChatOllama(model=model, streaming=False)

ROUTE_SYS = SystemMessage(content=(
    "You are an intent classifier. "
    "Return one of: doctor, travel, movie, other. "
    "Korean input allowed. Rules: "
    "- If user asks about symptoms, diseases, diagnosis, medication -> doctor. "
    "- If trip planning, itinerary, countries, schedules -> travel. "
    "- If film/movie preferences or finding films to watch -> movie. "
    "- Else -> other. Return ONLY the label."
))

def simple_rules(text: str) -> Intent:
    t = text.lower()
    if any(k in t for k in ["열", "기침", "통증", "두통", "약", "증상", "병", "감기", "독감"]):
        return "doctor"
    if any(k in t for k in ["여행", "일정", "일정짜", "코스", "항공", "호텔", "도쿄", "시드니", "오사카", "호주", "일본"]):
        return "travel"
    if any(k in t for k in ["영화", "예매", "추천", "감독", "배우", "장르", "무비"]):
        return "movie"
    return "other"

def route_node(state: AgentState) -> AgentState:
    last = state["messages"][-1]
    user_txt = last.content if hasattr(last, "content") else str(last)
    intent = simple_rules(user_txt)
    if intent == "other":
        llm = get_llm()
        label = llm.invoke([ROUTE_SYS, HumanMessage(content=user_txt)]).content.strip().lower()
        if label in ("doctor","travel","movie","other"):
            intent = label  # type: ignore
    out = dict(state)
    out["intent"] = intent
    return out

def branch(state: AgentState) -> Literal["doctor","travel","movie","other"]:
    return state.get("intent","other")  # type: ignore
