import regex as re
from typing import List, Dict, Any, Tuple
import numpy as np

def split_sentences(text: str) -> List[str]:
    # 단순 분할기(한국어/영어 혼합 대비 약식)
    sents = re.split(r"(?<=[\.\!\?]|[\.\!\?][\"\'])\s+", text.strip())
    return [s.strip() for s in sents if s.strip()]

def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

def assign_sentence_citations(
    sentences: List[str],
    doc_chunks: List[Dict[str, Any]],
    embedder
) -> Tuple[str, List[Dict[str, Any]]]:
    # 각 문장을 가장 유사한 문서 조각에 매핑하여 [n] 꼬리표를 부착.
    # doc_chunks: [{'text':..., 'url':..., 'title':..., 'embedding': np.ndarray, 'id':...}]
    # embedder: callable(texts: List[str]) -> np.ndarray

    if not sentences or not doc_chunks:
        return (" ".join(sentences), [])

    # 미리 문서 임베딩이 없다면 계산
    if "embedding" not in doc_chunks[0] or doc_chunks[0]["embedding"] is None:
        texts = [d["text"] for d in doc_chunks]
        embs = embedder(texts)
        for i, e in enumerate(embs):
            doc_chunks[i]["embedding"] = e

    sent_embs = embedder(sentences)
    chosen = []
    marked_sentences = []
    for i, s in enumerate(sentences):
        emb = sent_embs[i]
        # 최고 유사 문서 찾기
        best_idx = -1
        best_sim = -1.0
        for j, d in enumerate(doc_chunks):
            sim = cosine_sim(emb, d["embedding"])
            if sim > best_sim:
                best_sim = sim
                best_idx = j
        if best_idx >= 0:
            chosen.append(doc_chunks[best_idx])
            marked_sentences.append(f"{s}[{len(chosen)}]")
        else:
            marked_sentences.append(s)
    result_text = " ".join(marked_sentences)
    # 고유 출처로 재정렬
    seen = {}
    final_sources = []
    for idx, d in enumerate(chosen, start=1):
        url = (d.get("url", "") or "")
        title = (d.get("title", "") or "")
        key = url + "|" + title
        if key in seen:
            continue
        seen[key] = True
        final_sources.append({
            "idx": len(final_sources) + 1,
            "id": d.get("id"),
            "title": title,
            "url": url,
            "snippet": (d.get("text", "") or "")[:240] + ("..." if len(d.get("text",""))>240 else ""),
        })
    return result_text, final_sources
