from __future__ import annotations
import argparse, os
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from app.state import AgentState
from app.router import route_node, branch
from app.agents.doctor import doctor_node
from app.agents.travel import travel_node
from app.agents.movie import movie_node
from app.rag.faiss_store import FaissDomainStores
from app.utils.streaming import stream_print

def build_graph(stores: FaissDomainStores):
    g = StateGraph(AgentState)

    g.add_node("route", route_node)
    g.add_node("doctor", lambda s: doctor_node(s, stores))
    g.add_node("travel", lambda s: travel_node(s, stores))
    g.add_node("movie", movie_node)
    g.add_node("other", lambda s: {**s, "result_text": "죄송합니다. 해당 요청은 현재 범위를 벗어납니다. 질문을 보다 구체화하여 다시 요청해 주세요.", "sources": []})

    g.add_edge(START, "route")
    g.add_conditional_edges("route", branch, {
        "doctor": "doctor",
        "travel": "travel",
        "movie": "movie",
        "other": "other"
    })
    g.add_edge("doctor", END)
    g.add_edge("travel", END)
    g.add_edge("movie", END)
    g.add_edge("other", END)

    db_path = os.getenv("CHECKPOINT_DB", ".checkpoints/agent.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    memory = SqliteSaver(db_path)
    return g.compile(checkpointer=memory)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=str, default="default", help="세션/대화 ID (체크포인트 키)")
    ap.add_argument("--no-stream", action="store_true", help="스트리밍 비활성화")
    ap.add_argument("--retriever", type=str, default="hybrid", choices=["faiss","graphrag","hybrid"], help="검색기 선택")
    args = ap.parse_args()

    os.environ["USE_GRAPHRAG"] = "1" if args.retriever in ("graphrag","hybrid") else "0"

    stores = FaissDomainStores(base_dir=os.path.join(os.path.dirname(__file__), "../data/docs"))
    graph = build_graph(stores)

    print("=== CLI 멀티‑역할 에이전트 (LangChain + LangGraph) ===")
    print("세션:", args.session)
    print("모델:", os.getenv("OLLAMA_MODEL", "llama3:8b"))
    print("검색기:", args.retriever)
    print("")

    while True:
        try:
            user = input("> 사용자 질문(또는 exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n종료합니다.")
            break
        if user.lower() in ("exit","quit","q"):
            print("종료합니다.")
            break

        config = {"configurable": {"thread_id": args.session}}
        state_in = {"messages": [HumanMessage(content=user)]}
        out = graph.invoke(state_in, config=config)

        print("")
        print("▼ 답변")
        if args.no_stream:
            print(out.get("result_text",""))
        else:
            stream_print(out.get("result_text",""), enabled=True)

        sources = out.get("sources",[]) or []
        if sources:
            print("\n[출처]")
            for s in sources:
                title = s.get("title","")
                url = s.get("url","")
                print(f"[{s.get('idx')}] {title} — {url}")
        print("")

if __name__ == "__main__":
    main()
