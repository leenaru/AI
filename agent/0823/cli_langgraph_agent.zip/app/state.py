from __future__ import annotations
from typing import TypedDict, List, Optional, Literal, Dict, Any
from langchain_core.messages import BaseMessage

Intent = Literal["doctor", "travel", "movie", "other"]

class AgentState(TypedDict, total=False):
    messages: List[BaseMessage]
    intent: Intent
    result_text: str
    sources: List[Dict[str, Any]]      # [{'id':..., 'title':..., 'url':..., 'snippet':..., 'score':...}, ...]
    retriever_used: Literal["faiss", "graphrag", "hybrid", "none"]
