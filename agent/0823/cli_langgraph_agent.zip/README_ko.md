# CLI 기반 멀티‑역할 AI Agent (LangChain + LangGraph)

> **요약**
> - 하나의 루트 Agent 안에 **의사/여행사/영화 추천** 서브에이전트를 **LangGraph 분기/서브그래프/체크포인트**로 구성했습니다.  
> - **로컬 LLM(Ollama)** 를 통해 **스트리밍 출력**을 지원합니다.  
> - **RAG**: 도메인별 **FAISS**(로컬 인덱스) + (옵션) **Microsoft GraphRAG** 결과를 **RRF** 방식으로 융합. **문장별 출처 표기**를 합니다.  
> - 완전한 **오픈소스 스택**만 사용합니다.

## 설치

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3:8b   # 또는 qwen2.5:7b 등
```

## 실행

```bash
export OLLAMA_MODEL=llama3:8b
export USE_GRAPHRAG=0                 # 1이면 GraphRAG 융합
export GRAPHRAG_MODE=http             # http | cli
export GRAPHRAG_URL=http://localhost:8010/query
export GRAPHRAG_CLI="python -m graphrag.query"
export CHECKPOINT_DB=.checkpoints/agent.db

python -m app.main --session demo
```

## 구조
```
app/
  main.py
  state.py
  router.py
  agents/
    doctor.py
    travel.py
    movie.py
  rag/
    faiss_store.py
    graphrag_client.py
  utils/
    streaming.py
    citation.py
data/
  docs/
    medical/*.md
    travel/*.md
  movies.json
requirements.txt
```
