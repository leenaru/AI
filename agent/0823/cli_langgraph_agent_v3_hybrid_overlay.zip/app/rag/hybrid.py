from __future__ import annotations
from typing import List, Dict, Any
from dataclasses import dataclass

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def _key(it: Retrieved) -> str:
    return (it.url or "") + "|" + (it.title or "") + "|" + (it.text[:32] if it.text else "")

def _normalize_scores(items: List[Retrieved]) -> Dict[str, float]:
    if not items:
        return {}
    vals = [it.score for it in items]
    lo, hi = min(vals), max(vals)
    norm = {}
    for it in items:
        if hi > lo:
            norm[_key(it)] = (it.score - lo) / (hi - lo)
        else:
            norm[_key(it)] = 0.0
    return norm

def fuse_weighted(faiss: List[Retrieved], bm25: List[Retrieved], graphrag: List[Retrieved], w_f=0.5, w_b=0.3, w_g=0.2, topn: int = 6) -> List[Retrieved]:
    # 점수 정규화 후 가중합
    nf = _normalize_scores(faiss)
    nb = _normalize_scores(bm25)
    ng = _normalize_scores(graphrag)
    pool: Dict[str, Retrieved] = {}
    score: Dict[str, float] = {}
    for lst in (faiss, bm25, graphrag):
        for it in lst:
            k = _key(it)
            pool[k] = it
    for k in pool.keys():
        score[k] = w_f*nf.get(k,0.0) + w_b*nb.get(k,0.0) + w_g*ng.get(k,0.0)
    ranked = sorted(pool.values(), key=lambda it: score[_key(it)], reverse=True)
    return ranked[:topn]
