# CLI 기반 멀티‑역할 AI Agent (LangChain + LangGraph)

> **요약**
> - 하나의 루트 Agent 안에 **의사/여행사/영화 추천** 서브에이전트를 **LangGraph 분기/서브그래프/체크포인트**로 구성했습니다.  
> - **로컬 LLM(Ollama)** 를 통해 **스트리밍 출력**을 지원합니다.  
> - **RAG**: 도메인별 **FAISS**(로컬 인덱스) + (옵션) **Microsoft GraphRAG** 결과를 **RRF** 방식으로 융합. **문장별 출처 표기**를 합니다.  
> - 완전한 **오픈소스 스택**만 사용합니다.

## 설치

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3:8b   # 또는 qwen2.5:7b 등
```

## 실행

```bash
export OLLAMA_MODEL=llama3:8b
export USE_GRAPHRAG=0                 # 1이면 GraphRAG 융합
export GRAPHRAG_MODE=http             # http | cli
export GRAPHRAG_URL=http://localhost:8010/query
export GRAPHRAG_CLI="python -m graphrag.query"
export CHECKPOINT_DB=.checkpoints/agent.db

python -m app.main --session demo
```

## 구조
```
app/
  main.py
  state.py
  router.py
  agents/
    doctor.py
    travel.py
    movie.py
  rag/
    faiss_store.py
    graphrag_client.py
  utils/
    streaming.py
    citation.py
data/
  docs/
    medical/*.md
    travel/*.md
  movies.json
requirements.txt
```


---

## v3 확장 사항
- **BM25** 인덱스 추가(`rank-bm25`) 및 **FAISS + BM25 + GraphRAG 가중 융합**:
  - 가중치: `HYBRID_WEIGHTS="faiss:0.5,bm25:0.3,graph:0.2"` (CLI `--weights`로 덮어쓰기)
  - 검색 모드: `--retriever faiss|graphrag|hybrid` (hybrid가 기본)
- **슬롯 검증기**: 나이/성별/기간/날짜/장르/러닝타임 등 **정규화 & 검사** 후 **오류/누락**을 바탕으로 **질문 생성**
- **국가별 정책 오버레이(YAML)**: `data/policies/{KR,JP,AU}.yaml` 예제 포함
  - 의료/여행/영화 등급 가이드라인을 **답변 문맥에 삽입**
- **CLI 옵션**
  ```bash
  python -m app.main --session demo --retriever hybrid --weights "faiss:0.6,bm25:0.25,graph:0.15" --overlay KR
  ```


---

## v4 확장 사항
1) **라우팅 확장**
   - `data/routing/rules.yaml` 기반의 **키워드/정규식 규칙** 라우터(`ROUTER_MODE=rules`)
   - **스마트 LLM 라우터**(JSON 반환) (`ROUTER_MODE=llm`)
   - **하이브리드**: 규칙 점수가 임계치 미만이면 LLM로 보완 (`ROUTER_MODE=hybrid`, 기본값)
   - 규칙 파일은 YAML로 손쉽게 **추가/삭제** 가능

2) **국가 정책 오버레이 확장**
   - KR/JP/AU + **US/GB/SG** 예시 추가 (`data/policies/*.yaml`)

3) **문서 코퍼스 확장**
   - 의료: `covid19.md`, `otc_cough.md`
   - 여행: `uk_london.md`, `fr_paris.md`, `us_nyc.md`

4) **BM25 토크나이저 교체**
   - `BM25_TOKENIZER=ngram`(기본) → 한글 등 CJK에 **2/3-gram** + 영문 **단어 토큰** 혼합
   - `BM25_TOKENIZER=simple` → 기존 단어 토큰 방식

5) **신뢰도 스코어링 시각화**
   - `VIS_CONFIDENCE=1` 설정 시, **Rich 테이블**로 FAISS/BM25/GraphRAG/최종 스코어(정규화) 시각화

### 실행 예시
```bash
export ROUTER_MODE=hybrid
export BM25_TOKENIZER=ngram
export VIS_CONFIDENCE=1
export HYBRID_WEIGHTS="faiss:0.6,bm25:0.25,graph:0.15"
python -m app.main --session demo --retriever hybrid --overlay JP
```


---
## v5 확장 사항
1) **프로덕션 DSL 라우팅**
   - YAML v2 스키마: `defaults(threshold, weights.syllable_weight)`, `synonyms`, `labels[{name, priority, any{keywords,synonyms}, all{keywords}, regex}]`
   - 특성:
     - **우선순위(priority)**: 동일 점수 시 우선순위 높은 라벨 선택
     - **음절가중(syllable_weight)**: CJK(한글 등) 일치 길이만큼 추가 가중
     - **동의어 사전(synonyms)**: 라벨별 any.synonyms 키로 확장
   - 모드: `ROUTER_MODE=rules|llm|hybrid`

2) **GraphRAG 노드/에지 메타 표시**
   - `GraphRAGClient.query()`가 `{items, nodes, edges}` 반환
   - `SHOW_GRAPHRAG_META=1` 설정 시, **Rich 테이블**로 노드/에지 상위 8개 출력

3) **실행 예시**
```bash
export ROUTER_MODE=hybrid
export SHOW_GRAPHRAG_META=1
python -m app.main --session demo --retriever hybrid --overlay US
```


---
## v6 추가 기능
1) **GraphRAG centrality/communities 반영**
   - `GRAPH_META_WEIGHT`(기본 0.15)로 중앙성 점수를 가중
   - `COMMUNITY_DIVERSITY_WEIGHT`(기본 0.05)로 동일 커뮤니티 과다에 패널티(탐욕적 MMR 유사)
   - 함수: `fuse_weighted_graphmeta_debug(...)`

2) **LLM 비용 절감**
   - **LLM 응답 캐시**(`.cache/llm_cache.sqlite`) : 추출/추가질문/라우팅 LLM 호출 캐시
   - **Retrieval 캐시**(`.cache/retrieval_cache.sqlite`) : 질의→FAISS/BM25/GraphRAG 결과 캐시
   - **스칼라 프로필**: `CHEAP_MODE=1` 또는 `OLLAMA_OPTIONS='{"num_ctx":1024,"temperature":0.2}'`

3) **자동 하이브리드 가중치 러닝**
   - 데이터셋: `data/tuning/sample_qrels.yaml` (질의/도메인/정답 타이틀)
   - 알고리즘: `--algo bayes|random|hyperband`
   - 실행 예시:
     ```bash
     python -m app.tune.weights --dataset data/tuning/sample_qrels.yaml --algo bayes --trials 30
     ```
   - 출력: 최적 가중치 제안 → `HYBRID_WEIGHTS="faiss:x,bm25:y,graph:z"`

4) **시각화**
   - `VIS_CONFIDENCE=1` : 정규화 점수 + 중앙성/다양성 패널티 반영 전후(`final`/`final_plus`) 확인
   - `SHOW_GRAPHRAG_META=1` : 노드/에지 상위 8개 표 출력
