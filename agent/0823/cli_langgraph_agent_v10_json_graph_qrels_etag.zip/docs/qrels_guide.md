# Qrels란 무엇인가?

**Qrels**(Query Relevance Judgments)는 정보검색(IR)에서 **평가용 정답표**를 뜻합니다.  
- **Query**: 사용자가 실제로 던질 법한 질문/검색어
- **Relevance Judgments**: 각 쿼리에 대해 **어떤 문서(또는 문서 타이틀/스니펫)가 관련(relevant)한지**를 사람이 라벨링한 목록

## 왜 필요한가?
Retriever/RAG 품질을 수치로 평가하려면 **정답 기준**이 필요합니다. Qrels는 이 기준을 제공하여,
- Hit@K, nDCG@K 같은 **정확도 지표**를 계산하고
- 가중치 튜닝(예: FAISS/BM25/GraphRAG 융합)이나 하이퍼파라미터 최적화에 사용합니다.

## 예시 스키마
```yaml
- query: "일본 가족여행 4박 추천 일정"
  domain: "travel"
  relevant_titles: ["japan_overview", "tokyo_itinerary", "kyoto_highlights"]
- query: "기침 미열 근육통 원인"
  domain: "medical"
  relevant_titles: ["covid19", "flu", "common_cold"]
```

## 주의
- **충분한 다양성**: 쿼리는 여러 의도/난이도를 포함하도록 구성
- **라벨 품질**: 리뷰어 가이드라인/다중 라벨러로 신뢰도 향상
- **버전 관리**: 말뭉치가 바뀌면 qrels도 업데이트