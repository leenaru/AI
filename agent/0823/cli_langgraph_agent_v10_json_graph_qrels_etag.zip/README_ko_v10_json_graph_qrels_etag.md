# v10 — JSON 전략 재고, LangGraph API 파이프라인, qrels 설명, ETag DB-API

## 1) JSON 응답, table2text가 최선일까?
- **table2text**: 간결·자기완결 문장으로 변환해 **BM25/임베딩** 모두 강함. *단점*: 깊게 중첩된 구조/관계 손실.
- **jsonpointer(경로 인코딩) 청크**: `/items/0/name: ...` 같이 **경로를 보존**하여 **필드/계층 문맥**을 유지. 필드명 질의에 강함.
- **triples(의사 RDF)**: `(subject) --path--> (object)` 형태로 **관계 중심** 표현. **GraphRAG** 시드에 유리.
=> **권장**: 도메인/질의 특성에 따라 **혼합 전략**. 검색기는 하이브리드로 융합.

CLI:
```bash
python -m app.ingest.json_ingest_strategies   --json sample.json --strategy table2text --tag hotels --domain travel --out-md data/docs/travel/api_hotels_t2t.md
python -m app.ingest.json_ingest_strategies   --json sample.json --strategy jsonpointer --tag hotels --domain travel --out-md data/docs/travel/api_hotels_ptr.md
python -m app.ingest.json_ingest_strategies   --json sample.json --strategy triples --tag hotels --domain travel --out-md data/docs/travel/api_hotels_triples.md --subject-key id
```

## 2) LangGraph: api_json_node → 인덱싱 → 질의 예제
파일: `app/graph/examples/api_pipeline.py`
- 노드:
  - `node_api`: API 호출+md 생성 (`api_json_node` 사용)
  - `node_index`: 새 파일 **증분 인덱싱**(실 서비스 API에 맞게 `add_files/rebuild_domain` 교체)
  - `node_query`: 하이브리드 검색(`fuse_with_meta`로 메타 가중 포함)
- 그래프:
  `START → api → index → query → END`

## 3) qrels란?
정보검색 평가용 **정답표(Query Relevance Judgments)**. 각 쿼리에 대해 **관련 문서(타이틀)** 목록을 사람이 라벨링한 데이터.  
튜너/검증에 사용(Hit@K, nDCG@K 등). 문서: `docs/qrels_guide.md`

## 4) ETag가 적용된 DB API 케이스
파일: `app/ingest/etag_db_api.py`
- `If-None-Match` 헤더로 **변경 없으면 304** → **재인덱싱 생략**, 비용 절감
- 변경 시 새 ETag 저장, JSON 평탄화 → table2text 문장 → md 저장
- 옵션: 단순 페이지네이션(`--paginate-param page --max-pages 5`)

예시:
```bash
python -m app.ingest.etag_db_api   --url "https://db.example.com/records"   --domain travel --tag db_hotels   --key-fields id name city rating   --out-md data/docs/travel/db_hotels.md   --paginate-param page --max-pages 3
```