from __future__ import annotations
import os, yaml
from typing import Dict, Any

POLICY_PATH = os.getenv("META_WEIGHTS_PATH", os.path.join("data","policy","meta_weights.yaml"))

def load_policy() -> Dict[str,Any]:
    try:
        with open(POLICY_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def score_multiplier(meta: Dict[str,Any]) -> float:
    pol = load_policy()
    mul = float(pol.get("defaults",{}).get("multiplier", 1.0))
    st  = (meta.get("source_type") or meta.get("src_type") or "").lower()
    sec = (meta.get("section") or meta.get("sec") or "")
    dom = (meta.get("domain") or "").lower()
    if st and st in pol.get("source_type",{}):
        mul *= float(pol["source_type"][st])
    if sec and sec in pol.get("section",{}):
        mul *= float(pol["section"][sec])
    if dom and dom in pol.get("domain",{}):
        mul *= float(pol["domain"][dom])
    return mul