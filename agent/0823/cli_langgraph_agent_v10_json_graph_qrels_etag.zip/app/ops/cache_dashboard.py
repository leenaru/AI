from __future__ import annotations
import os, argparse, json
from rich.console import Console
from rich.table import Table
from app.utils import llm as llm_cache
from app.utils import ret_cache as ret_cache

console = Console()

def show_table(title: str, data: dict):
    t = Table(title=title)
    for k,v in data.items():
        t.add_row(str(k), str(v))
    console.print(t)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--export-json", type=str, default=None)
    args = ap.parse_args()

    llm_stats = llm_cache.stats()
    ret_stats = ret_cache.stats()

    if args.export_json:
        with open(args.export_json, "w", encoding="utf-8") as f:
            json.dump({"llm": llm_stats, "retrieval": ret_stats}, f, ensure_ascii=False, indent=2)

    show_table("LLM Cache Stats", llm_stats)
    show_table("Retrieval Cache Stats", ret_stats)

if __name__ == "__main__":
    main()
