import os, sqlite3, time, json

def _human_bytes(n: int) -> str:
    for u in ["B","KB","MB","GB"]:
        if n < 1024: return f"{n:.1f}{u}"
        n /= 1024.0
    return f"{n:.1f}TB"

def _ensure_stats(con: sqlite3.Connection):
    con.execute("CREATE TABLE IF NOT EXISTS stats (k TEXT PRIMARY KEY, v REAL)")
    for k in ("hits","misses","evictions","bytes","rows"):
        con.execute("INSERT OR IGNORE INTO stats (k, v) VALUES (?, 0)", (k,))
    con.commit()

def _bump(con: sqlite3.Connection, k: str, delta: float = 1.0):
    con.execute("UPDATE stats SET v = v + ? WHERE k = ?", (float(delta), k))
    con.commit()

def _set_stat(con: sqlite3.Connection, k: str, v: float):
    con.execute("INSERT OR REPLACE INTO stats (k, v) VALUES (?, ?)", (k, float(v)))
    con.commit()

def _get_stat(con: sqlite3.Connection, k: str) -> float:
    row = con.execute("SELECT v FROM stats WHERE k=?", (k,)).fetchone()
    return float(row[0]) if row else 0.0
