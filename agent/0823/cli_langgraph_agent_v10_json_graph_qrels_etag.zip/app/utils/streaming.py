from typing import Optional
from langchain_core.callbacks.base import BaseCallbackHandler

class ConsoleStreamCallback(BaseCallbackHandler):
    def __init__(self, enabled: bool = True):
        self.enabled = enabled

    def on_llm_new_token(self, token: str, **kwargs):
        if self.enabled:
            print(token, end="", flush=True)

    def on_llm_end(self, *args, **kwargs):
        if self.enabled:
            print("", flush=True)

def stream_print(text: str, enabled: bool = True):
    if not enabled:
        print(text)
        return
    for ch in text:
        print(ch, end="", flush=True)
    print("")
