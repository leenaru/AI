from __future__ import annotations
import os
from typing import Dict, Any
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage
from app.ingest.api_ingest import api_json_node
from app.rag.faiss_store import FaissDomainStores
from app.rag.bm25_store import BM25DomainStores
from app.rag.hybrid_struct import fuse_with_meta, Retrieved
from app.policy.meta_weights import score_multiplier

# ---- Minimal state ----
class State(dict): pass

# ---- Nodes ----
def node_api(state: State) -> State:
    # Fetch API and write md
    return api_json_node(state)

def node_index(state: State) -> State:
    """
    Incremental indexing of newly ingested files.
    Assumes FaissDomainStores/BM25DomainStores support add_files(domain, file_paths) (pseudo-API).
    Replace with your store's real API.
    """
    files = state.get("ingested_files", [])
    if not files: return state
    domain = state.get("api_request", {}).get("domain", "other")
    base_dir = os.path.join(os.path.dirname(__file__), "../../data/docs")
    faiss = FaissDomainStores(base_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), "../../data/docs")))
    bm25 = BM25DomainStores(base_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), "../../data/docs")))
    try:
        faiss.add_files(domain, files)
    except Exception:
        # fallback: rebuild single domain (implementation-dependent)
        faiss.rebuild_domain(domain)
    try:
        bm25.add_files(domain, files)
    except Exception:
        bm25.rebuild_domain(domain)
    return state

def node_query(state: State) -> State:
    question = state.get("question","")
    domain = state.get("api_request",{}).get("domain","other")
    base_dir = os.path.join(os.path.dirname(__file__), "../../data/docs")
    faiss = FaissDomainStores(base_dir=os.path.abspath(base_dir))
    bm25 = BM25DomainStores(base_dir=os.path.abspath(base_dir))

    # Retrieve
    f_hits = [Retrieved(**vars(h)) for h in faiss.search(domain, question, k=6)]
    b_hits = [Retrieved(**vars(h)) for h in bm25.search(domain, question, k=6)]
    g_hits = []   # plug your GraphRAG items if available
    s_hits = []   # structured (csv_struct) hits could be inserted here
    ranked, finals = fuse_with_meta(f_hits, b_hits, g_hits, s_hits, topn=6)

    state["retrieved"] = [vars(r) for r in ranked]
    return state

# ---- Graph wiring ----
def build_graph():
    g = StateGraph(State)
    g.add_node("api", node_api)
    g.add_node("index", node_index)
    g.add_node("query", node_query)
    g.add_edge(START, "api")
    g.add_edge("api", "index")
    g.add_edge("index", "query")
    g.add_edge("query", END)
    return g.compile()

if __name__ == "__main__":
    app = build_graph()
    # Example run
    state = State({
        "question": "도쿄 호텔 중 평점 4.5 이상은?",
        "api_request": {
            "url": "https://api.example.com/hotels?city=Tokyo",
            "method": "GET",
            "domain": "travel",
            "tag": "hotels_tokyo",
            "key_fields": ["name","city","rating","price_per_night"],
            "out_md": "data/docs/travel/api_hotels_tokyo.md"
        }
    })
    out = app.invoke(state)
    print(out.get("retrieved", [])[:2])