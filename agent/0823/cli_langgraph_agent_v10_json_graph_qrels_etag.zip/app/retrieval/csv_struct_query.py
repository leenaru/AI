from __future__ import annotations
import os, argparse, pandas as pd, json
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def struct_query(csv_path: str, query: str, limit: int = 20) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    if query and query.strip():
        dfq = df.query(query, engine="python")
    else:
        dfq = df
    return dfq.head(limit)

def df_to_sentences(df: pd.DataFrame, file_id: str) -> List[str]:
    sents = []
    for i, row in df.iterrows():
        parts = []
        for c, v in row.items():
            if pd.isna(v): continue
            parts.append(f"{c}={v}")
        sents.append(f"{'; '.join(parts)}. [{file_id}#row={i}]")
    return sents

def run_struct_and_to_md(csv_path: str, query: str, out_md: str, domain: str):
    dfq = struct_query(csv_path, query)
    sents = df_to_sentences(dfq, os.path.basename(csv_path))
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    meta = f"<!-- source_type: csv_struct | domain: {domain} | source: {os.path.basename(csv_path)} | query: {query} -->"
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("# CSV structured query facts\n\n"+meta+"\n\n" + "\n".join(f"- {s}" for s in sents) + "\n")
    return {"rows": len(dfq), "out": out_md}

def fuse_text_and_struct(faiss: List[Retrieved], bm25: List[Retrieved], graphrag: List[Retrieved], struct_sents: List[str], struct_weight: float = 0.35) -> List[Retrieved]:
    """
    Lightweight fusion: treat structure-derived sentences as pseudo-retrieved docs with fixed weight.
    """
    struct_items = []
    for i, s in enumerate(struct_sents):
        struct_items.append(Retrieved(text=s, url="CSV:struct", title="csv_struct", score=struct_weight, id=f"struct:{i}"))
    # naive union + sort by score descending
    pool = faiss + bm25 + graphrag + struct_items
    pool.sort(key=lambda r: r.score, reverse=True)
    return pool[:10]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--query", required=True, help="pandas.query string, e.g., \"nationality=='KR' and visa_free_days>=90\"")
    ap.add_argument("--out-md", required=True)
    ap.add_argument("--domain", required=True)
    args = ap.parse_args()
    info = run_struct_and_to_md(args.csv, args.query, args.out_md, args.domain)
    print(json.dumps(info, ensure_ascii=False))

if __name__ == "__main__":
    main()