from __future__ import annotations
from typing import List, Dict, Any, Tuple, Set
from dataclasses import dataclass
import os, re

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str

def _key(it: Retrieved) -> str:
    return (it.url or "") + "|" + (it.title or "") + "|" + (it.text[:32] if it.text else "")

def _normalize_list(items: List[Retrieved]) -> Dict[str, float]:
    if not items: return {}
    lo, hi = min(i.score for i in items), max(i.score for i in items)
    if hi <= lo:
        return {_key(i):0.0 for i in items}
    return {_key(i):(i.score-lo)/(hi-lo) for i in items}

def _graph_meta_map(items: List[Retrieved], nodes: List[Dict[str,Any]]) -> Dict[str, Dict[str,Any]]:
    meta = {}
    by_id = {str(n.get("id")): n for n in (nodes or [])}
    by_title = {str(n.get("title") or n.get("name","")): n for n in (nodes or [])}
    for it in items:
        k = _key(it)
        cand = by_id.get(str(getattr(it,"id",""))) or by_title.get(it.title) or {}
        cent = cand.get("centrality") or cand.get("pagerank") or cand.get("score") or 0.0
        comm = cand.get("community") or cand.get("cluster") or cand.get("modularity_class")
        meta[k] = {"centrality": float(cent or 0.0), "community": comm}
    # normalize centrality among pool
    if meta:
        vals = {k:v["centrality"] for k,v in meta.items()}
        lo, hi = min(vals.values()), max(vals.values())
        for k in meta:
            if hi>lo:
                meta[k]["centrality"] = (meta[k]["centrality"]-lo)/(hi-lo)
            else:
                meta[k]["centrality"] = 0.0
    return meta

def _char_ngrams(s: str, n: int = 3) -> Set[str]:
    s = (s or "").lower()
    s = re.sub(r"\s+", " ", s)
    grams = set()
    for i in range(max(0, len(s)-n+1)):
        grams.add(s[i:i+n])
    return grams

def _sim(item_a: Retrieved, item_b: Retrieved) -> float:
    # light-weight textual redundancy proxy (title+url+prefix of text)
    a = (item_a.title or "") + " " + (item_a.url or "") + " " + (item_a.text or "")[:120]
    b = (item_b.title or "") + " " + (item_b.url or "") + " " + (item_b.text or "")[:120]
    A = _char_ngrams(a, 3); B = _char_ngrams(b, 3)
    if not A or not B: return 0.0
    return len(A & B) / float(len(A | B))

def fuse_coverage_mmr_debug(
    faiss: List[Retrieved],
    bm25: List[Retrieved],
    graphrag: List[Retrieved],
    nodes: List[Dict[str,Any]] | None,
    edges: List[Dict[str,Any]] | None,
    w_f: float = 0.5, w_b: float = 0.3, w_g: float = 0.2,
    w_centrality: float = None,
    mmr_lambda: float = None,
    coverage_ratio: float = None,
    topn: int = 6
) -> Tuple[List[Retrieved], Dict[str, Dict[str, float]]]:
    """
    2-단계:
      (Step-A) Coverage 보장: 후보 커뮤니티 상위 순(평균 중앙성/사이즈)으로 최소 C개의 커뮤니티를 커버하도록 1개씩 선별
      (Step-B) MMR: 남은 슬롯은 (1-λ)*score - λ*max_sim 로 탐욕적 선택
    """
    if w_centrality is None:
        w_centrality = float(os.getenv("GRAPH_META_WEIGHT", "0.15"))
    if mmr_lambda is None:
        mmr_lambda = float(os.getenv("MMR_LAMBDA", "0.35"))
    if coverage_ratio is None:
        coverage_ratio = float(os.getenv("COMMUNITY_COVERAGE_RATIO", "0.5"))  # 후보 커뮤니티의 50% 보장(최대 topn)

    nf = _normalize_list(faiss)
    nb = _normalize_list(bm25)
    ng = _normalize_list(graphrag)

    pool: Dict[str, Retrieved] = {}
    for lst in (faiss, bm25, graphrag):
        for it in lst:
            pool[_key(it)] = it
    items = list(pool.values())
    meta = _graph_meta_map(items, nodes or [])

    # base score
    base: Dict[str, float] = {}
    for it in items:
        k = _key(it)
        base[k] = w_f*nf.get(k,0.0) + w_b*nb.get(k,0.0) + w_g*ng.get(k,0.0) + w_centrality*meta.get(k,{}).get("centrality",0.0)

    # --- Step-A: Coverage 보장 ---
    # 커뮤니티 집계 및 랭킹
    from collections import defaultdict
    comm2items = defaultdict(list)
    for it in items:
        k = _key(it)
        comm = str(meta.get(k,{}).get("community", "__none__"))
        comm2items[comm].append(it)

    # 커뮤니티 점수: 평균 중앙성 + 평균 base
    comm_rank = []
    for comm, lst in comm2items.items():
        if not lst: continue
        scores = [base[_key(it)] for it in lst]
        cents  = [meta[_key(it)]["centrality"] for it in lst]
        comm_score = (sum(scores)/len(scores)) + (sum(cents)/len(cents))
        comm_rank.append((comm_score, comm))
    comm_rank.sort(reverse=True)

    target_cov = max(1, min(topn, int(round(len(comm_rank) * coverage_ratio))))
    selected: List[Retrieved] = []
    debug: Dict[str, Dict[str, float]] = {}

    covered = set()
    for _, comm in comm_rank[:target_cov]:
        # 이 커뮤니티에서 가장 점수가 높은 아이템 1개 선택
        best_it, best_sc = None, -1e9
        for it in comm2items[comm]:
            k = _key(it)
            sc = base[k]
            if sc > best_sc:
                best_it, best_sc = it, sc
        if best_it is not None:
            selected.append(best_it); covered.add(comm)
            k = _key(best_it)
            debug[k] = {"phase":"coverage", "base": base[k], "centrality": meta.get(k,{}).get("centrality",0.0), "final": base[k]}

        if len(selected) >= topn:
            return selected, debug

    # --- Step-B: Greedy MMR with redundancy control ---
    remaining = [it for it in items if all(_key(it)!=_key(s) for s in selected)]
    while len(selected) < min(topn, len(items)) and remaining:
        best_it, best_val = None, -1e9
        for it in remaining:
            k = _key(it)
            # 최대 유사도 (이미 선택된 것들 중)
            if selected:
                msim = max(_sim(it, s) for s in selected)
            else:
                msim = 0.0
            mmr_val = (1.0 - mmr_lambda) * base[k] - mmr_lambda * msim
            if mmr_val > best_val:
                best_val, best_it = mmr_val, it
        if best_it is None: break
        selected.append(best_it)
        rk = _key(best_it)
        debug[rk] = {"phase":"mmr", "base": base[rk], "mmr": best_val, "final": best_val}
        remaining = [it for it in remaining if _key(it)!=rk]

    return selected, debug
