from __future__ import annotations
from typing import List, Dict, Any, Tuple, Set
from dataclasses import dataclass
import os, re
from app.policy.meta_weights import score_multiplier

@dataclass
class Retrieved:
    text: str
    url: str
    title: str
    score: float
    id: str
    meta: Dict[str,Any] = None

def _key(it: Retrieved) -> str:
    return (it.url or "") + "|" + (it.title or "") + "|" + (it.text[:32] if it.text else "")

def _normalize_list(items: List[Retrieved]) -> Dict[str, float]:
    if not items: return {}
    lo, hi = min(i.score for i in items), max(i.score for i in items)
    if hi <= lo:
        return {_key(i):0.0 for i in items}
    return {_key(i):(i.score-lo)/(hi-lo) for i in items}

def fuse_with_meta(
    faiss: List[Retrieved],
    bm25: List[Retrieved],
    graphrag: List[Retrieved],
    structured: List[Retrieved],
    w_f: float = 0.5, w_b: float = 0.3, w_g: float = 0.1, w_s: float = 0.1,
    topn: int = 8
) -> Tuple[List[Retrieved], Dict[str,float]]:
    nf = _normalize_list(faiss)
    nb = _normalize_list(bm25)
    ng = _normalize_list(graphrag)
    ns = _normalize_list(structured)

    pool: Dict[str, Retrieved] = {}
    for lst in (faiss, bm25, graphrag, structured):
        for it in lst:
            pool[_key(it)] = it

    finals: Dict[str,float] = {}
    for k,it in pool.items():
        base = w_f*nf.get(k,0.0) + w_b*nb.get(k,0.0) + w_g*ng.get(k,0.0) + w_s*ns.get(k,0.0)
        mult = score_multiplier((it.meta or {}))
        finals[k] = base * mult

    ranked = sorted(pool.values(), key=lambda r: finals[_key(r)], reverse=True)[:topn]
    return ranked, finals