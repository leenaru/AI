from __future__ import annotations
import os, json, argparse
from typing import Any, Dict, List, Optional
from datetime import datetime
import pandas as pd
from pandas import json_normalize

def _norm(v):
    if v is None: return ""
    if isinstance(v, float) and pd.isna(v): return ""
    return str(v).replace("\n"," ").strip()

def table2text(data: Any, tag: str, key_fields: Optional[List[str]] = None) -> List[str]:
    if isinstance(data, list):
        df = json_normalize(data, sep=".")
    elif isinstance(data, dict):
        # Heuristic: pick first list field
        list_field = next((k for k,v in data.items() if isinstance(v, list)), None)
        if list_field:
            df = json_normalize(data, record_path=[list_field], meta=[k for k in data.keys() if k!=list_field], sep=".")
        else:
            df = json_normalize([data], sep=".")
    else:
        df = pd.DataFrame([{"value": str(data)}])
    out=[]
    cols=list(df.columns)
    if key_fields:
        head=[c for c in key_fields if c in cols]; tail=[c for c in cols if c not in head]
        cols=head+tail
    for i,row in df.iterrows():
        parts=[]
        for c in cols:
            val=_norm(row[c])
            if val=="": continue
            parts.append(f"{c}={val}")
        if parts:
            out.append(f"{'; '.join(parts)}. [api:{tag}#i={i}]")
    return out

def jsonpointer_chunks(data: Any, tag: str, max_len: int = 400) -> List[str]:
    """
    Emit path-aware chunks using JSON Pointer-like keys: /items/0/name: foo
    Better for nested objects because keys encode structure explicitly.
    """
    out=[]
    def walk(node, path=""):
        if isinstance(node, dict):
            for k,v in node.items():
                walk(v, f"{path}/{k}")
        elif isinstance(node, list):
            for idx,v in enumerate(node):
                walk(v, f"{path}/{idx}")
        else:
            s = f"{path}: {str(node)}"
            if len(s)>max_len: s=s[:max_len-3]+"..."
            out.append(f"{s} [api:{tag}]")
    walk(data, "")
    return out

def triples(data: Any, tag: str, subject_key: Optional[str] = None) -> List[str]:
    """
    Emit pseudo RDF triples: (subject, predicate, object).
    - subject: top-level subject_key or tag
    - predicate: dotted path
    - object: leaf value
    """
    subs=[]
    if isinstance(data, dict) and subject_key and subject_key in data:
        base_sub=str(data[subject_key])
    else:
        base_sub=tag
    out=[]
    def walk(node, path="", sub=base_sub):
        if isinstance(node, dict):
            for k,v in node.items():
                walk(v, f"{path}.{k}" if path else k, sub)
        elif isinstance(node, list):
            for i,v in enumerate(node):
                walk(v, f"{path}[{i}]" if path else f"[{i}]", sub)
        else:
            out.append(f"({sub}) --{path}--> ({str(node)}) [api:{tag}]")
    walk(data, "", base_sub)
    return out

def save_md(sentences: List[str], out_md: str, domain: str, src: str, tag: str, strategy: str):
    meta = f"<!-- source_type: api | strategy: {strategy} | domain: {domain} | src: {src} | tag: {tag} | generated: {datetime.utcnow().isoformat()}Z -->"
    text = "# API-derived chunks\n\n" + meta + "\n\n" + "\n".join(f"- {s}" for s in sentences) + "\n"
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    with open(out_md, "w", encoding="utf-8") as f:
        f.write(text)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", required=True, help="path to JSON file")
    ap.add_argument("--strategy", choices=["table2text","jsonpointer","triples"], default="table2text")
    ap.add_argument("--tag", default="api")
    ap.add_argument("--domain", default="other")
    ap.add_argument("--out-md", required=True)
    ap.add_argument("--key-fields", nargs="*", default=None)
    ap.add_argument("--subject-key", default=None)
    args = ap.parse_args()

    with open(args.json, "r", encoding="utf-8") as f:
        data = json.load(f)

    if args.strategy=="table2text":
        sents = table2text(data, args.tag, key_fields=args.key_fields)
    elif args.strategy=="jsonpointer":
        sents = jsonpointer_chunks(data, args.tag)
    else:
        sents = triples(data, args.tag, subject_key=args.subject_key)

    save_md(sents, args.out_md, args.domain, f"file://{args.json}", args.tag, args.strategy)
    print(json.dumps({"rows": len(sents), "out": args.out_md}, ensure_ascii=False))

if __name__ == "__main__":
    main()