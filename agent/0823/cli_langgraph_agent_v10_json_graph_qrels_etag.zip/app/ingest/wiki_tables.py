from __future__ import annotations
import os, argparse, pandas as pd, wptools, re, json, requests
from typing import List, Dict, Any
from bs4 import BeautifulSoup

def sanitize_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]", "_", name or "table")

def fetch_infobox(title: str, lang: str = "en") -> Dict[str, Any]:
    page = wptools.page(title=title, lang=lang)
    page.get_parse()  # fetch parse tree including infobox
    # infobox as dict
    info = page.data.get("infobox") or {}
    return info

def fetch_html_tables(title: str, lang: str = "en") -> List[pd.DataFrame]:
    url = f"https://{lang}.wikipedia.org/wiki/{title.replace(' ','_')}"
    # requests for HTML, then pandas.read_html
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    dfs = pd.read_html(r.text)  # requires lxml/html5lib
    return dfs

def write_csvs_from_wiki(title: str, out_dir: str, lang: str = "en") -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    written = []
    # infobox
    try:
        info = fetch_infobox(title, lang=lang)
        if info:
            df = pd.DataFrame(list(info.items()), columns=["key","value"])
            path = os.path.join(out_dir, f"wiki_{sanitize_name(title)}_{lang}_infobox.csv")
            df.to_csv(path, index=False)
            written.append(path)
    except Exception as e:
        pass
    # html tables
    try:
        dfs = fetch_html_tables(title, lang=lang)
        for idx, df in enumerate(dfs):
            path = os.path.join(out_dir, f"wiki_{sanitize_name(title)}_{lang}_table{idx}.csv")
            df.to_csv(path, index=False)
            written.append(path)
    except Exception:
        pass
    return written

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", required=True)
    ap.add_argument("--lang", default="en")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--domain", required=True)
    ap.add_argument("--table2text", action="store_true")
    args = ap.parse_args()

    paths = write_csvs_from_wiki(args.title, args.out_dir, lang=args.lang)
    print(json.dumps({"csvs": paths}, ensure_ascii=False))
    if args.table2text and paths:
        from app.ingest.csv_ingest import csv_to_markdown_sentences
        for p in paths:
            out_md = os.path.splitext(p)[0] + "_sentences.md"
            csv_to_markdown_sentences(p, out_md, domain=args.domain, key_cols=None, max_rows=None)
            print("table2text:", out_md)

if __name__ == "__main__":
    main()