from __future__ import annotations
import os, json, argparse, requests, sqlite3, time
from typing import Any, Dict, List, Optional
from pandas import json_normalize
import pandas as pd

ETAG_DB = os.getenv("ETAG_DB", ".cache/etag.sqlite")
os.makedirs(os.path.dirname(ETAG_DB), exist_ok=True)

def db():
    con = sqlite3.connect(ETAG_DB)
    con.execute("CREATE TABLE IF NOT EXISTS etags (url TEXT PRIMARY KEY, etag TEXT, updated_ts INTEGER)")
    return con

def get_etag(url: str) -> Optional[str]:
    con = db()
    row = con.execute("SELECT etag FROM etags WHERE url=?", (url,)).fetchone()
    return row[0] if row else None

def set_etag(url: str, etag: str):
    con = db()
    con.execute("INSERT OR REPLACE INTO etags (url, etag, updated_ts) VALUES (?,?,?)", (url, etag, int(time.time())))
    con.commit()

def fetch_with_etag(url: str, headers: Dict[str,str]=None, params: Dict[str,Any]=None, timeout: int=20) -> requests.Response:
    h = dict(headers or {})
    et = get_etag(url)
    if et:
        h["If-None-Match"] = et
    r = requests.get(url, headers=h, params=params, timeout=timeout)
    return r

def flatten_list(data: Any) -> pd.DataFrame:
    if isinstance(data, list):
        return json_normalize(data, sep=".")
    elif isinstance(data, dict):
        # try to find list field
        lf = next((k for k,v in data.items() if isinstance(v, list)), None)
        if lf: return json_normalize(data, record_path=[lf], meta=[k for k in data.keys() if k!=lf], sep=".")
        return json_normalize([data], sep=".")
    return pd.DataFrame([{"value": str(data)}])

def create_sentences(df: pd.DataFrame, tag: str, key_fields: List[str]=None) -> List[str]:
    cols=list(df.columns)
    if key_fields:
        head=[c for c in key_fields if c in cols]; tail=[c for c in cols if c not in head]
        cols=head+tail
    out=[]
    for i,row in df.iterrows():
        parts=[]
        for c in cols:
            v=row[c]
            if pd.isna(v): continue
            parts.append(f"{c}={str(v).strip()}")
        if parts:
            out.append(f"{'; '.join(parts)}. [db:{tag}#i={i}]")
    return out

def save_md(sentences: List[str], out_md: str, domain: str, src: str, tag: str):
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("# DB-API facts\n\n")
        f.write(f"<!-- source_type: api | api_kind: db | domain: {domain} | src: {src} | tag: {tag} -->\n\n")
        for s in sentences:
            f.write(f"- {s}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True, help="DB API endpoint, supports ETag")
    ap.add_argument("--domain", required=True)
    ap.add_argument("--tag", default="db")
    ap.add_argument("--key-fields", nargs="*", default=None)
    ap.add_argument("--out-md", required=True)
    ap.add_argument("--paginate-param", default=None, help="e.g., 'page'")
    ap.add_argument("--max-pages", type=int, default=1)
    args = ap.parse_args()

    all_rows = []
    url = args.url
    page = 1
    for _ in range(args.max_pages):
        params = {args.paginate_param: page} if args.paginate_param else None
        r = fetch_with_etag(url, headers=None, params=params)
        if r.status_code == 304:
            print(json.dumps({"status":"not_modified","page":page}))
            break
        r.raise_for_status()
        et = r.headers.get("ETag")
        if et: set_etag(url, et)
        data = r.json()
        df = flatten_list(data)
        all_rows.append(df)
        # naive pagination stop condition
        if not args.paginate_param or df.empty: break
        page += 1

    if not all_rows:
        print(json.dumps({"rows":0,"out":args.out_md,"note":"unchanged"}, ensure_ascii=False))
        return

    big = pd.concat(all_rows, ignore_index=True)
    sents = create_sentences(big, args.tag, key_fields=args.key_fields)
    save_md(sents, args.out_md, args.domain, args.url, args.tag)
    print(json.dumps({"rows": len(sents), "out": args.out_md}, ensure_ascii=False))

if __name__ == "__main__":
    main()