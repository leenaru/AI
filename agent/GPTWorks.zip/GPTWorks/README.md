# GPTWorks On-Demand AI Agent

웹 기반 IoT 고객지원 에이전트를 위한 서버/클라이언트 구현입니다. 온디맨드 모드에 집중하여 FastAPI 백엔드와 ChatGPT 스타일의 채팅 인터페이스를 제공합니다.

## 주요 구성

- **API Gateway (FastAPI)**: `/api/chat/messages` 엔드포인트로 텍스트/음성/이미지 입력을 처리하고, 대화 상태를 관리합니다.
- **OnDemand Orchestrator**: 토큰 예산 관리, 대화 흐름 유지, 정책/지식 컨텍스트 연결을 수행합니다.
- **Model Adapter (LLM)**: 환경 변수만으로 Mock ↔ Ollama ↔ vLLM 백엔드를 전환할 수 있는 어댑터. 오류 시 Mock으로 자동 폴백합니다.
- **Knowledge Context Engine**: GraphRAG/FAISS/BM25/RRF 조합을 모사하며, JSON 지식 그래프(`data/knowledge/nodes.json`)를 로드해 컨텍스트를 제공합니다.
- **Service Gateway**: HTTP 기반 온보딩·트러블슈팅 API를 호출하며, 환경 변수로 베이스 URL 및 인증키를 제어합니다.
- **In-memory Conversation Store**: 세션별 대화 기록과 토큰 추정치를 유지합니다.
- **Web Client**: ChatGPT 스타일 UX로 텍스트 입력, 이미지 업로드(+ 버튼), 음성 입력(마이크 버튼), 토큰 사용량 표기, 응답 대기 애니메이션을 지원합니다.

```
Client (Web)
 ├─ Interaction Layer: chat UI, attachment tray, microphone control
 └─ Communicator: FormData 기반 API 호출, 세션 관리

Server (FastAPI)
 ├─ API Gateway: validation, attachment 정규화
 ├─ OnDemand Orchestrator
 │   ├─ Conversation Store
 │   ├─ Knowledge Context Engine
 │   ├─ Model Adapter (LLM)
 │   └─ Service Gateway
 └─ Static Files: web UI 배포
```

## 실행 방법

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
uvicorn server.app.main:app --reload
```

실행 후 `http://localhost:8000/` 에 접속하면 웹 채팅 UI가 제공됩니다.

## 환경 설정

1. `.env.example`를 참고해 환경 변수를 정의하고, 필요 시 `KNOWLEDGE_STORE_PATH`를 실제 지식 그래프 JSON 파일로 지정합니다.
2. `LLM_PROVIDER` 값으로 `mock`, `ollama`, `vllm` 중 하나를 선택하고, 각 백엔드 엔드포인트와 모델명을 설정합니다.
3. 온보딩/트러블슈팅 백엔드가 준비되어 있다면 `SERVICE_GATEWAY_BASE_URL`과 `SERVICE_GATEWAY_API_KEY`를 지정하여 API 호출을 활성화할 수 있습니다.
4. 런타임 구성은 `/api/admin/status`에서 확인하고, 지식 그래프를 변경한 후 `/api/admin/knowledge/reload`(POST)로 다시 로드할 수 있습니다.

## 프론트엔드 UX 특징

- 사용자 메시지를 즉시 표시하고, AI 응답이 준비될 때까지 3점 애니메이션으로 진행 상황을 보여줍니다.
- 이미지 첨부는 입력창의 `+` 아이콘을 통해 노출되며, 선택된 이미지/음성은 전송 전 칩 형태로 확인/제거할 수 있습니다.
- 마이크 아이콘을 누르면 브라우저 MediaRecorder를 통해 음성 입력을 녹음하고, 다시 누르면 자동으로 메시지를 전송합니다.
- 엔터키는 즉시 전송, `Shift+Enter` 는 줄바꿈으로 동작합니다.
- 각 AI 응답 하단에 프롬프트/응답/총 토큰 사용량을 표기하고, 참조한 컨텍스트 스니펫을 열람할 수 있습니다.

## 향후 확장 포인트

- **LLM 모니터링**: vLLM/Ollama 호출 지표를 수집하고 안전성 필터 및 재시도 정책을 정교화합니다.
- **RAG 데이터 수집 자동화**: 운영 문서를 자동 파싱해 `nodes.json`을 주기적으로 갱신하고, 벡터 DB와 연동합니다.
- **Tooling**: Service Gateway를 실제 온보딩/장애 처리 API와 연결하고, LangGraph 플로우를 LangSmith 등으로 관찰.
- **스토리지**: 대화/미디어를 영속 저장소로 이동하고, 온디바이스 동기화 로직을 추가.
- **테스트**: API 라우터와 오케스트레이터를 대상으로 pytest/httpx 기반 단위 및 통합 테스트 보강.

## 알려진 제약

- MediaRecorder 및 음성 입력은 브라우저 지원 여부에 따라 동작하지 않을 수 있습니다.
- 서버는 현재 로컬 메모리에 상태를 저장하므로 다중 서버나 재시작 시 세션이 유지되지 않습니다.
- 보안/인증, 멀티 테넌시, Proactive 모드는 포함되어 있지 않습니다.
