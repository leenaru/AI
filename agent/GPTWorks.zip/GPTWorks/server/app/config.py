from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path


@dataclass
class AppConfig:
    """Application level configuration derived from environment variables."""

    app_name: str = field(default_factory=lambda: os.getenv("APP_NAME", "GPTWorks On-Demand Agent"))
    api_prefix: str = field(default_factory=lambda: os.getenv("API_PREFIX", "/api"))
    enable_cors: bool = field(default_factory=lambda: os.getenv("ENABLE_CORS", "true").lower() == "true")
    allowed_origins: list[str] = field(
        default_factory=lambda: [
            origin.strip()
            for origin in os.getenv("ALLOWED_ORIGINS", "*").split(",")
            if origin.strip()
        ]
    )
    static_dir: Path = field(
        default_factory=lambda: Path(os.getenv("STATIC_DIR", Path(__file__).resolve().parent / "static"))
    )
    debug: bool = field(default_factory=lambda: os.getenv("DEBUG", "false").lower() == "true")
    token_budget: int = field(default_factory=lambda: int(os.getenv("TOKEN_BUDGET", "2048")))
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "mock"))
    llm_timeout: float = field(default_factory=lambda: float(os.getenv("LLM_TIMEOUT", "30")))
    ollama_endpoint: str = field(default_factory=lambda: os.getenv("OLLAMA_ENDPOINT", "http://localhost:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("OLLAMA_MODEL", "gemma2:2b"))
    vllm_endpoint: str = field(default_factory=lambda: os.getenv("VLLM_ENDPOINT", "http://localhost:8001"))
    vllm_model: str = field(default_factory=lambda: os.getenv("VLLM_MODEL", "gptworks-gemma"))
    openai_api_key: str | None = field(default_factory=lambda: os.getenv("OPENAI_API_KEY"))
    service_gateway_base_url: str | None = field(default_factory=lambda: os.getenv("SERVICE_GATEWAY_BASE_URL"))
    service_gateway_timeout: float = field(default_factory=lambda: float(os.getenv("SERVICE_GATEWAY_TIMEOUT", "10")))
    service_gateway_api_key: str | None = field(default_factory=lambda: os.getenv("SERVICE_GATEWAY_API_KEY"))
    knowledge_store_path: Path | None = field(
        default_factory=lambda: Path(path) if (path := os.getenv("KNOWLEDGE_STORE_PATH")) else None
    )


def load_config() -> AppConfig:
    """Helper for loading application config while keeping dependency injection simple."""

    return AppConfig()
