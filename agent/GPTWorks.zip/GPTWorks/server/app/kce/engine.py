from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass
from math import log, sqrt
from pathlib import Path
from threading import RLock
from typing import Dict, Iterable, List, Mapping, Sequence

from ..orchestration.types import ContextItem


@dataclass
class KnowledgeNode:
    node_id: str
    source: str
    content: str
    tags: Sequence[str]
    neighbors: Sequence[str]


class PseudoVectorizer:
    """Lightweight hash-based vectorizer that emulates embedding similarity."""

    def __init__(self, dim: int = 64) -> None:
        self.dim = dim

    def encode(self, text: str) -> List[float]:
        vector = [0.0] * self.dim
        for token in KnowledgeContextEngine._tokenize(text):
            index = hash(token) % self.dim
            vector[index] += 1.0
        norm = sqrt(sum(value * value for value in vector)) or 1.0
        return [value / norm for value in vector]

    @staticmethod
    def cosine_similarity(vec_a: Sequence[float], vec_b: Sequence[float]) -> float:
        return sum(a * b for a, b in zip(vec_a, vec_b))


DEFAULT_NODES: Sequence[dict[str, object]] = [
    {
        "id": "onboarding-checklist",
        "source": "onboarding/checklist.md",
        "content": (
            "Ensure the device is powered, within Wi-Fi range, and that the mobile app has camera, Bluetooth, "
            "and location permissions. Guide the user to scan the device QR code when prompted."
        ),
        "tags": ["onboarding", "device", "wifi", "qr", "camera"],
        "neighbors": ["onboarding-troubleshoot", "device-manual"],
    },
    {
        "id": "onboarding-troubleshoot",
        "source": "troubleshooting/error-codes.md",
        "content": (
            "Common LED error codes: three red blinks indicate Wi-Fi authentication failure; two amber blinks signal "
            "firmware update required. Offer step-by-step recovery instructions."
        ),
        "tags": ["error", "led", "wifi", "firmware", "code"],
        "neighbors": ["onboarding-checklist", "support-fallback", "offline-diagnostics"],
    },
    {
        "id": "voc-intake",
        "source": "voc/intake.md",
        "content": (
            "When capturing VOC, confirm customer identity, gather device model, firmware version, and recent changes. "
            "Log the issue category and severity for follow-up workflows."
        ),
        "tags": ["voc", "support", "customer", "device", "issue"],
        "neighbors": ["support-fallback", "device-manual", "post-purchase-registration"],
    },
    {
        "id": "offline-continuity",
        "source": "offline/continuity.md",
        "content": (
            "If offline, cache user requests locally. Sync actions to the server once connectivity is restored, ensuring "
            "idempotent retries to avoid duplicated actions."
        ),
        "tags": ["offline", "sync", "cache", "continuity"],
        "neighbors": ["support-fallback", "offline-diagnostics"],
    },
    {
        "id": "device-manual",
        "source": "manuals/device-guide.md",
        "content": (
            "Provide step-by-step device manuals, including installation diagrams, maintenance schedules, and QR code "
            "shortcuts to advanced diagnostics."
        ),
        "tags": ["manual", "guide", "installation", "maintenance"],
        "neighbors": ["onboarding-checklist", "voc-intake", "purchase-guide"],
    },
    {
        "id": "support-fallback",
        "source": "support/fallback-options.md",
        "content": (
            "If AI troubleshooting fails, offer quick access to FAQ search, connect to human support, or schedule a "
            "technician visit. Confirm contact information and preferred call back window."
        ),
        "tags": ["fallback", "faq", "support", "technician"],
        "neighbors": ["onboarding-troubleshoot", "voc-intake", "offline-continuity", "recommendation-engine"],
    },
    {
        "id": "purchase-guide",
        "source": "commerce/purchase-guide.md",
        "content": (
            "Present device bundles based on household size, required features, and budget. Highlight warranty coverage "
            "and installation services when available."
        ),
        "tags": ["purchase", "bundle", "pricing", "warranty"],
        "neighbors": ["device-manual", "recommendation-engine"],
    },
    {
        "id": "recommendation-engine",
        "source": "commerce/recommendation-engine.md",
        "content": (
            "Leverage prior purchases, device usage patterns, and user feedback to suggest complementary products. "
            "Ensure recommendations respect privacy and opt-out preferences."
        ),
        "tags": ["recommendation", "personalization", "commerce"],
        "neighbors": ["purchase-guide", "support-fallback"],
    },
    {
        "id": "post-purchase-registration",
        "source": "customer/registration.md",
        "content": (
            "After purchase, prompt the user to register the device with model, serial number, and installation date. "
            "Automate warranty activation and notify the onboarding workflow."
        ),
        "tags": ["registration", "warranty", "post-purchase"],
        "neighbors": ["voc-intake", "onboarding-checklist"],
    },
    {
        "id": "offline-diagnostics",
        "source": "diagnostics/offline.md",
        "content": (
            "For offline troubleshooting, instruct the user to record LED patterns, capture device logs locally, and "
            "perform hardware reset steps. Queue the transcript for upload once online."
        ),
        "tags": ["offline", "diagnostics", "logs", "led"],
        "neighbors": ["onboarding-troubleshoot", "offline-continuity"],
    },
]


class KnowledgeContextEngine:
    """
    Knowledge Context Engine that simulates GraphRAG + FAISS + BM25 + RRF, backed by a file-based knowledge store.

    The implementation keeps everything in-memory while mirroring the ranking stages:
    1. BM25-style lexical ranking
    2. Hash-based vector similarity (FAISS placeholder)
    3. Graph propagation over knowledge nodes (GraphRAG flavor)
    4. Reciprocal Rank Fusion to blend the ranked lists
    """

    def __init__(self, store_path: Path | None = None) -> None:
        self._lock = RLock()
        self._store_path = store_path
        self._vectorizer = PseudoVectorizer()

        self._nodes: Dict[str, KnowledgeNode] = {}
        self._doc_terms: Dict[str, Dict[str, int]] = {}
        self._doc_vecs: Dict[str, List[float]] = {}
        self._doc_length: Dict[str, int] = {}
        self._doc_freq: Dict[str, int] = defaultdict(int)
        self._avg_doc_len = 1.0

        self.reload()

    def reload(self) -> None:
        """Reload knowledge nodes from disk, defaulting to built-in seeds."""

        with self._lock:
            self._nodes.clear()
            self._doc_terms.clear()
            self._doc_vecs.clear()
            self._doc_length.clear()
            self._doc_freq.clear()

            nodes = self._load_nodes_from_store()
            for node in nodes:
                self._register_node(node)

            self._avg_doc_len = sum(self._doc_length.values()) / max(len(self._doc_length), 1)

    def info(self) -> dict[str, object]:
        with self._lock:
            return {
                "store_path": str(self._store_path) if self._store_path else None,
                "node_count": len(self._nodes),
                "vocabulary_size": len(self._doc_freq),
            }

    def retrieve(self, query: str, limit: int = 3) -> Sequence[ContextItem]:
        if not query.strip():
            return []

        with self._lock:
            tokens = list(self._tokenize(query))
            lexical_scores = self._bm25(tokens)
            vector_scores = self._vector_similarity(query)
            graph_scores = self._graph_propagation(lexical_scores)

        fused = self._reciprocal_rank_fusion([lexical_scores, vector_scores, graph_scores])
        ranked = sorted(fused.items(), key=lambda item: item[1], reverse=True)[:limit]

        results: List[ContextItem] = []
        with self._lock:
            for node_id, score in ranked:
                node = self._nodes.get(node_id)
                if not node:
                    continue
                results.append(
                    ContextItem(
                        source=node.source,
                        content=node.content,
                        score=round(score, 4),
                    )
                )
        return results

    def _load_nodes_from_store(self) -> Sequence[KnowledgeNode]:
        if self._store_path and self._store_path.exists():
            try:
                data = json.loads(self._store_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as error:  # noqa: PERF203
                raise ValueError(f"Invalid knowledge store JSON: {error}") from error
        else:
            data = DEFAULT_NODES

        nodes: List[KnowledgeNode] = []
        for entry in data:
            node = KnowledgeNode(
                node_id=str(entry["id"]),
                source=str(entry.get("source", entry["id"])),
                content=str(entry.get("content", "")),
                tags=tuple(entry.get("tags", [])),
                neighbors=tuple(entry.get("neighbors", [])),
            )
            nodes.append(node)
        return nodes

    def _register_node(self, node: KnowledgeNode) -> None:
        tokens = list(self._tokenize(node.content))
        term_freq: Dict[str, int] = defaultdict(int)
        for token in tokens:
            term_freq[token] += 1

        self._nodes[node.node_id] = node
        self._doc_terms[node.node_id] = term_freq
        self._doc_length[node.node_id] = len(tokens)

        for token in term_freq:
            self._doc_freq[token] += 1

        self._doc_vecs[node.node_id] = self._vectorizer.encode(node.content + " " + " ".join(node.tags))

    def _bm25(self, query_tokens: Sequence[str], k1: float = 1.5, b: float = 0.75) -> Dict[str, float]:
        scores: Dict[str, float] = defaultdict(float)
        doc_count = len(self._nodes) or 1

        for term in query_tokens:
            if term not in self._doc_freq:
                continue
            idf = max(0.0, self._idf(term, doc_count))

            for node_id, term_freqs in self._doc_terms.items():
                freq = term_freqs.get(term, 0)
                if freq == 0:
                    continue
                doc_len = self._doc_length.get(node_id, 1)
                norm = freq * (k1 + 1) / (freq + k1 * (1 - b + b * doc_len / (self._avg_doc_len or 1)))
                scores[node_id] += idf * norm

        return scores

    def _vector_similarity(self, query: str) -> Dict[str, float]:
        query_vec = self._vectorizer.encode(query)
        return {
            node_id: PseudoVectorizer.cosine_similarity(query_vec, vec)
            for node_id, vec in self._doc_vecs.items()
        }

    def _graph_propagation(self, lexical_scores: Mapping[str, float]) -> Dict[str, float]:
        if not lexical_scores:
            return {}

        ranked_seeds = sorted(lexical_scores.items(), key=lambda item: item[1], reverse=True)[:3]
        scores: Dict[str, float] = defaultdict(float)

        for rank, (node_id, base_score) in enumerate(ranked_seeds, start=1):
            boost = 1.0 / rank
            scores[node_id] += base_score * boost
            node = self._nodes.get(node_id)
            if not node:
                continue
            for neighbor_id in node.neighbors:
                scores[neighbor_id] += base_score * 0.6 * boost

        return scores

    @staticmethod
    def _reciprocal_rank_fusion(score_dicts: Sequence[Mapping[str, float]], k: int = 60) -> Dict[str, float]:
        fused: Dict[str, float] = defaultdict(float)
        for score_dict in score_dicts:
            ranked_items = sorted(score_dict.items(), key=lambda item: item[1], reverse=True)
            for rank, (key, _) in enumerate(ranked_items, start=1):
                fused[key] += 1 / (k + rank)
        return fused

    def _idf(self, term: str, doc_count: int) -> float:
        term_doc_freq = self._doc_freq.get(term, 0)
        numerator = max(0.0, doc_count - term_doc_freq + 0.5)
        denominator = term_doc_freq + 0.5
        ratio = numerator / denominator if denominator else 0.0
        return log(ratio + 1.0)

    @staticmethod
    def _tokenize(text: str) -> Iterable[str]:
        return [token.strip().lower() for token in text.split() if token.strip()]
