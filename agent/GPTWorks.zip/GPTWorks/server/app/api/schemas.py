from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class AttachmentSchema(BaseModel):
    kind: str
    name: str
    description: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class MessageSchema(BaseModel):
    role: str
    content: str
    created_at: datetime
    attachments: List[AttachmentSchema] = []

    model_config = ConfigDict(from_attributes=True)


class TokenUsageSchema(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ContextItemSchema(BaseModel):
    source: str
    content: str
    score: float

    model_config = ConfigDict(from_attributes=True)


class ChatResponseSchema(BaseModel):
    session_id: str
    message: MessageSchema
    token_usage: TokenUsageSchema
    context_items: List[ContextItemSchema]
