from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from ..config import AppConfig
from ..dependencies import get_config, get_knowledge_engine
from ..kce.engine import KnowledgeContextEngine

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/status")
async def get_status(
    config: AppConfig = Depends(get_config),
    knowledge_engine: KnowledgeContextEngine = Depends(get_knowledge_engine),
) -> dict[str, object]:
    knowledge_info = knowledge_engine.info()
    return {
        "llm": {
            "provider": config.llm_provider,
            "ollama_endpoint": config.ollama_endpoint,
            "ollama_model": config.ollama_model,
            "vllm_endpoint": config.vllm_endpoint,
            "vllm_model": config.vllm_model,
        },
        "service_gateway": {
            "base_url": config.service_gateway_base_url,
            "timeout": config.service_gateway_timeout,
            "api_key_configured": bool(config.service_gateway_api_key),
        },
        "knowledge": knowledge_info,
    }


@router.post("/knowledge/reload", status_code=status.HTTP_204_NO_CONTENT)
async def reload_knowledge(
    knowledge_engine: KnowledgeContextEngine = Depends(get_knowledge_engine),
) -> None:
    try:
        knowledge_engine.reload()
    except ValueError as error:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=str(error)) from error
