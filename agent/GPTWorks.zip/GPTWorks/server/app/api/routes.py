from __future__ import annotations

from typing import Annotated, Sequence
from uuid import uuid4

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from ..dependencies import get_on_demand_orchestrator
from ..orchestration.orchestrator import OnDemandOrchestrator
from ..orchestration.types import Attachment, OnDemandResult, UserTurn
from .schemas import ChatResponseSchema, ContextItemSchema, MessageSchema, TokenUsageSchema


router = APIRouter(tags=["on-demand"])


@router.get("/health")
async def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@router.post("/chat/messages", response_model=ChatResponseSchema)
async def create_message(
    session_id: Annotated[str | None, Form(None)],
    text: Annotated[str | None, Form("")],
    image_files: Annotated[list[UploadFile] | None, File(None)],
    audio_file: Annotated[UploadFile | None, File(None)],
    orchestrator: OnDemandOrchestrator = Depends(get_on_demand_orchestrator),
) -> ChatResponseSchema:
    if not session_id:
        session_id = uuid4().hex
    if text is None:
        text = ""
    if not text and not image_files and not audio_file:
        raise HTTPException(status_code=400, detail="텍스트, 음성, 이미지 중 최소 하나는 제공되어야 합니다.")

    attachments = _map_attachments(image_files or [], audio_file)
    user_turn = UserTurn(session_id=session_id, text=text, attachments=attachments)

    result: OnDemandResult = orchestrator.handle_turn(user_turn)

    message_schema = MessageSchema.model_validate(result.assistant_message)
    token_schema = TokenUsageSchema(
        prompt_tokens=result.token_usage.prompt_tokens,
        completion_tokens=result.token_usage.completion_tokens,
        total_tokens=result.token_usage.total_tokens,
    )
    context_schema: Sequence[ContextItemSchema] = [
        ContextItemSchema.model_validate(item) for item in result.context_items
    ]

    return ChatResponseSchema(
        session_id=session_id,
        message=message_schema,
        token_usage=token_schema,
        context_items=list(context_schema),
    )


def _map_attachments(image_files: Sequence[UploadFile], audio_file: UploadFile | None) -> Sequence[Attachment]:
    attachments: list[Attachment] = []
    for upload in image_files:
        attachments.append(
            Attachment(
                kind="image",
                name=upload.filename or "image",
                content_type=upload.content_type,
                description="사용자 첨부 이미지",
                extra={"field": "image_files"},
            )
        )

    if audio_file:
        attachments.append(
            Attachment(
                kind="audio",
                name=audio_file.filename or "audio",
                content_type=audio_file.content_type,
                description="사용자 음성 입력",
                extra={"field": "audio_file"},
            )
        )

    return attachments
