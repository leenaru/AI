from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional, Sequence

MessageRole = Literal["user", "assistant", "system"]
AttachmentKind = Literal["image", "audio", "text", "unknown"]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class Attachment:
    """Represents a user supplied attachment such as an image or audio sample."""

    kind: AttachmentKind
    name: str
    content_type: Optional[str] = None
    size: Optional[int] = None
    description: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ConversationMessage:
    """Internal representation of a single turn in a conversation."""

    role: MessageRole
    content: str
    created_at: datetime = field(default_factory=utcnow)
    attachments: Sequence[Attachment] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0


@dataclass(slots=True)
class TokenUsage:
    prompt_tokens: int
    completion_tokens: int

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass(slots=True)
class ContextItem:
    """Represents knowledge snippets retrieved for the LLM prompt."""

    source: str
    content: str
    score: float


@dataclass(slots=True)
class OnDemandResult:
    """Aggregates the final response from the on-demand flow."""

    assistant_message: ConversationMessage
    token_usage: TokenUsage
    context_items: Sequence[ContextItem]
    policies_triggered: Sequence[str] = field(default_factory=list)


@dataclass(slots=True)
class UserTurn:
    session_id: str
    text: str
    attachments: Sequence[Attachment] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
