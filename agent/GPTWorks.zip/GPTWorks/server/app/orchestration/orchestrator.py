from __future__ import annotations

import json
from typing import Iterable, Sequence

from ..adapters.model_adapter import BaseModelAdapter, MockModelAdapter, ModelRequest, ModelResponse
from ..config import AppConfig
from ..kce.engine import KnowledgeContextEngine
from ..services.service_gateway import ServiceGateway
from ..services.token_counter import TokenCounter
from .conversation_store import ConversationStore
from .types import ConversationMessage, ContextItem, OnDemandResult, TokenUsage, UserTurn


class OnDemandOrchestrator:
    """Coordinates the on-demand conversational flow."""

    def __init__(
        self,
        config: AppConfig,
        token_counter: TokenCounter,
        store: ConversationStore,
        knowledge_engine: KnowledgeContextEngine,
        model_adapter: BaseModelAdapter,
        service_gateway: ServiceGateway,
        fallback_adapter: MockModelAdapter | None = None,
    ) -> None:
        self._config = config
        self._token_counter = token_counter
        self._store = store
        self._knowledge_engine = knowledge_engine
        self._model_adapter = model_adapter
        self._service_gateway = service_gateway
        self._fallback_adapter = fallback_adapter or MockModelAdapter(token_counter=token_counter)

    def handle_turn(self, turn: UserTurn) -> OnDemandResult:
        history = self._store.get(turn.session_id)
        trimmed_history = self._trim_history_if_needed(history, turn)

        user_tokens = self._token_counter.count_text(turn.text)
        user_message = ConversationMessage(
            role="user",
            content=turn.text,
            attachments=turn.attachments,
            prompt_tokens=user_tokens,
            completion_tokens=0,
        )
        self._store.replace(turn.session_id, trimmed_history + [user_message])

        context_items = self._knowledge_engine.retrieve(turn.text)

        model_request = ModelRequest(
            system_prompt=self._build_system_prompt(),
            user_prompt=turn.text,
            conversation_summary=self._summarize_history(trimmed_history),
            context_items=context_items,
            attachments=turn.attachments,
        )
        model_response = self._generate_with_fallback(model_request)

        message_text = model_response.text
        if model_response.warnings:
            warning_lines = "\n".join(f"- {warning}" for warning in model_response.warnings)
            message_text = f"{message_text}\n\n[시스템 경고]\n{warning_lines}"

        assistant_message = ConversationMessage(
            role="assistant",
            content=message_text,
            attachments=[],
            prompt_tokens=model_response.prompt_tokens,
            completion_tokens=model_response.completion_tokens,
        )
        self._store.append(turn.session_id, assistant_message)

        token_usage = TokenUsage(
            prompt_tokens=user_tokens + model_response.prompt_tokens,
            completion_tokens=model_response.completion_tokens,
        )

        # Placeholder for rule-based or service triggered actions.
        self._invoke_actions_if_required(turn, assistant_message, context_items)

        return OnDemandResult(
            assistant_message=assistant_message,
            token_usage=token_usage,
            context_items=context_items,
        )

    def _generate_with_fallback(self, request: ModelRequest) -> ModelResponse:
        try:
            return self._model_adapter.generate(request)
        except Exception as error:  # noqa: BLE001
            fallback_response = self._fallback_adapter.generate(request)
            warning = f"LLM 호출 실패로 Mock 응답을 제공합니다: {type(error).__name__} - {error}"
            fallback_response.warnings.append(warning)
            return fallback_response

    def _trim_history_if_needed(self, history: Sequence[ConversationMessage], turn: UserTurn) -> Sequence[ConversationMessage]:
        budget = self._token_counter.safe_margin(self._config.token_budget)
        total_tokens = self._token_counter.count_messages(history) + self._token_counter.count_text(turn.text)

        if total_tokens <= budget:
            return history

        trimmed = list(history)
        while trimmed and self._token_counter.count_messages(trimmed) + self._token_counter.count_text(turn.text) > budget:
            trimmed.pop(0)
        return trimmed

    def _summarize_history(self, history: Sequence[ConversationMessage], limit: int = 8) -> str:
        relevant_history = history[-limit:]
        lines = []
        for message in relevant_history:
            prefix = "사용자" if message.role == "user" else "AI"
            lines.append(f"{prefix}: {message.content}")
        return "\n".join(lines)

    def _build_system_prompt(self) -> str:
        return (
            "당신은 IoT 기기의 설치, 온보딩, 트러블슈팅을 지원하는 고객지원 AI 에이전트입니다. "
            "간결하지만 단계별로 안내하고, 필요한 경우 사용자에게 추가 정보를 질문하세요. "
            "개인정보는 수집하지 말고, 민감정보가 포함되면 마스킹하게 안내하세요."
        )

    def _invoke_actions_if_required(
        self,
        turn: UserTurn,
        assistant_message: ConversationMessage,
        context_items: Iterable[ContextItem],
    ) -> None:
        actions = self._detect_actions(turn.text)
        if not actions:
            return

        notes: list[str] = []
        for action in actions:
            result = self._service_gateway.execute_action(action, query=turn.text, metadata=turn.metadata)
            if result.success:
                detail = self._format_service_payload(result.payload)
                notes.append(f"- {action}: {detail}")
            else:
                reason = result.explanation or "서비스 호출에 실패했습니다."
                notes.append(f"- {action}: 실패 ({reason})")

        if notes:
            assistant_message.content += "\n\n[서비스 연동 결과]\n" + "\n".join(notes)

    def _detect_actions(self, text: str) -> list[str]:
        lowered = text.lower()
        actions: list[str] = []

        onboarding_keywords = ("onboarding", "설치", "추가", "등록", "연결")
        if any(keyword in lowered for keyword in onboarding_keywords):
            actions.append("device_onboarding_checklist")

        troubleshooting_keywords = ("error", "에러", "코드", "led", "blink", "알람")
        if any(keyword in lowered for keyword in troubleshooting_keywords):
            actions.append("error_code_lookup")

        voc_keywords = ("voc", "문의", "불만", "접수", "ticket")
        if any(keyword in lowered for keyword in voc_keywords):
            actions.append("voc_intake")

        return actions

    @staticmethod
    def _format_service_payload(payload: dict[str, object]) -> str:
        if not payload:
            return "응답 없음"
        summary_fields = ("summary", "message", "description", "result")
        for field in summary_fields:
            value = payload.get(field)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return json.dumps(payload, ensure_ascii=False, indent=2)
