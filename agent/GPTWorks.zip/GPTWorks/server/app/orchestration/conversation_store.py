from __future__ import annotations

from threading import Lock
from typing import Dict, Iterable, List

from .types import ConversationMessage


class ConversationStore:
    """Thread-safe in-memory store for conversation history by session."""

    def __init__(self) -> None:
        self._conversations: Dict[str, List[ConversationMessage]] = {}
        self._lock = Lock()

    def get(self, session_id: str) -> List[ConversationMessage]:
        with self._lock:
            return list(self._conversations.get(session_id, []))

    def append(self, session_id: str, message: ConversationMessage) -> None:
        with self._lock:
            conversation = self._conversations.setdefault(session_id, [])
            conversation.append(message)

    def extend(self, session_id: str, messages: Iterable[ConversationMessage]) -> None:
        with self._lock:
            conversation = self._conversations.setdefault(session_id, [])
            conversation.extend(messages)

    def replace(self, session_id: str, messages: Iterable[ConversationMessage]) -> None:
        with self._lock:
            self._conversations[session_id] = list(messages)

    def clear(self, session_id: str) -> None:
        with self._lock:
            self._conversations.pop(session_id, None)
