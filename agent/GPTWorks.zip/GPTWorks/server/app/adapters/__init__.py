# Package marker for LLM and embedding adapters.
