from __future__ import annotations
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import httpx

from ..config import AppConfig
from ..orchestration.types import Attachment, ContextItem
from ..services.token_counter import TokenCounter


@dataclass(slots=True)
class ModelRequest:
    system_prompt: str
    user_prompt: str
    conversation_summary: str
    context_items: Sequence[ContextItem]
    attachments: Sequence[Attachment]


@dataclass(slots=True)
class ModelResponse:
    text: str
    prompt_tokens: int
    completion_tokens: int
    warnings: List[str] = field(default_factory=list)


class BaseModelAdapter(ABC):
    """Abstract base adapter for all model providers."""

    def __init__(self, token_counter: TokenCounter) -> None:
        self._token_counter = token_counter

    @abstractmethod
    def generate(self, request: ModelRequest) -> ModelResponse:
        raise NotImplementedError

    def _estimate_prompt_tokens(self, request: ModelRequest) -> int:
        prompt = "\n".join(
            [
                request.system_prompt,
                request.conversation_summary,
                self._build_context_section(request.context_items),
                request.user_prompt,
            ]
        )
        return self._token_counter.count_text(prompt)

    def _estimate_completion_tokens(self, text: str) -> int:
        return self._token_counter.count_text(text)

    @staticmethod
    def _build_context_section(context_items: Sequence[ContextItem]) -> str:
        return "\n".join(f"- ({item.source}) {item.content}" for item in context_items)

    @staticmethod
    def _describe_attachments(attachments: Sequence[Attachment]) -> str:
        if not attachments:
            return ""
        lines = []
        for attachment in attachments:
            detail = f"{attachment.kind.upper()} - {attachment.name}"
            if attachment.description:
                detail += f" — {attachment.description}"
            lines.append(detail)
        return "\n".join(lines)


class MockModelAdapter(BaseModelAdapter):
    """Fallback adapter that emits deterministic, structured responses."""

    def generate(self, request: ModelRequest) -> ModelResponse:
        context_text = self._build_context_section(request.context_items)
        attachment_text = self._describe_attachments(request.attachments)

        response_parts = [
            "[확인] 문제가 확인되었습니다. 아래 단계를 따라 진행해 주세요:",
            request.user_prompt.strip() or "사용자 입력 없음",
        ]

        if context_text:
            response_parts.append("\n[참고 지식]\n" + context_text)

        if attachment_text:
            response_parts.append("\n[첨부 정보]\n" + attachment_text)

        helpful_tips = (
            "필요한 경우 앱이 안내하는 카메라 가이드를 따라 QR을 스캔하고, 문제가 지속되면 VOC 접수를 진행해 주세요."
        )
        response_parts.append("\n[추가 팁]\n" + helpful_tips)

        text = "\n\n".join(response_parts)

        prompt_tokens = self._estimate_prompt_tokens(request)
        completion_tokens = self._estimate_completion_tokens(text)

        return ModelResponse(text=text, prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)


class OllamaModelAdapter(BaseModelAdapter):
    """LLM adapter that targets the Ollama HTTP API."""

    def __init__(self, token_counter: TokenCounter, endpoint: str, model: str, timeout: float = 30.0) -> None:
        super().__init__(token_counter)
        self._endpoint = endpoint.rstrip("/")
        self._model = model
        self._timeout = timeout

    def generate(self, request: ModelRequest) -> ModelResponse:
        prompt = self._compose_prompt(request)
        payload = {
            "model": self._model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.3},
        }

        url = f"{self._endpoint}/api/generate"
        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(url, json=payload)
            response.raise_for_status()
            data = response.json()

        text = data.get("response") or data.get("output") or ""
        if not text:
            raise RuntimeError("Ollama 응답에 텍스트가 없습니다.")

        prompt_tokens = self._estimate_prompt_tokens(request)
        completion_tokens = self._estimate_completion_tokens(text)

        return ModelResponse(text=text, prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)

    def _compose_prompt(self, request: ModelRequest) -> str:
        sections = [
            f"System:\n{request.system_prompt}",
        ]
        if request.conversation_summary:
            sections.append(f"Conversation Summary:\n{request.conversation_summary}")
        context = self._build_context_section(request.context_items)
        if context:
            sections.append(f"Context:\n{context}")
        attachment_text = self._describe_attachments(request.attachments)
        if attachment_text:
            sections.append(f"Attachments:\n{attachment_text}")
        sections.append(f"User:\n{request.user_prompt}")
        sections.append("Answer in Korean with step-by-step guidance.")
        return "\n\n".join(sections)


class VLLMModelAdapter(BaseModelAdapter):
    """Adapter for OpenAI-compatible vLLM deployments."""

    def __init__(
        self,
        token_counter: TokenCounter,
        endpoint: str,
        model: str,
        timeout: float = 30.0,
        api_key: str | None = None,
    ) -> None:
        super().__init__(token_counter)
        self._endpoint = endpoint.rstrip("/")
        self._model = model
        self._timeout = timeout
        self._api_key = api_key

    def generate(self, request: ModelRequest) -> ModelResponse:
        url = f"{self._endpoint}/v1/chat/completions"
        messages = self._build_messages(request)
        payload = {
            "model": self._model,
            "messages": messages,
            "temperature": 0.25,
            "stream": False,
        }

        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(url, headers=headers, content=json.dumps(payload))
            response.raise_for_status()
            data = response.json()

        choices = data.get("choices", [])
        if not choices:
            raise RuntimeError("vLLM 응답에 choices 가 없습니다.")

        text = choices[0].get("message", {}).get("content", "")
        if not text:
            raise RuntimeError("vLLM 응답에 텍스트가 없습니다.")

        usage = data.get("usage", {})
        prompt_tokens = int(usage.get("prompt_tokens") or self._estimate_prompt_tokens(request))
        completion_tokens = int(usage.get("completion_tokens") or self._estimate_completion_tokens(text))

        return ModelResponse(text=text, prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)

    def _build_messages(self, request: ModelRequest) -> List[Mapping[str, str]]:
        messages: List[Mapping[str, str]] = [{"role": "system", "content": request.system_prompt}]
        if request.conversation_summary:
            messages.append(
                {
                    "role": "system",
                    "content": f"Conversation Summary:\n{request.conversation_summary}",
                }
            )
        context = self._build_context_section(request.context_items)
        if context:
            messages.append({"role": "system", "content": f"Context:\n{context}"})

        attachment_text = self._describe_attachments(request.attachments)
        if attachment_text:
            messages.append({"role": "system", "content": f"Attachments:\n{attachment_text}"})

        messages.append({"role": "user", "content": request.user_prompt})
        return messages


class SafeModelAdapter(BaseModelAdapter):
    """
    Wrapper that delegates to a primary adapter and falls back to a secondary one
    if an exception occurs.
    """

    def __init__(self, primary: BaseModelAdapter, fallback: BaseModelAdapter) -> None:
        super().__init__(fallback._token_counter)
        self._primary = primary
        self._fallback = fallback

    def generate(self, request: ModelRequest) -> ModelResponse:
        try:
            return self._primary.generate(request)
        except Exception as error:  # noqa: BLE001
            fallback_response = self._fallback.generate(request)
            warning = (
                f"기본 LLM 호출에 실패하여 Mock 응답으로 대체했습니다: {type(error).__name__} - {error}"
            )
            fallback_response.warnings.append(warning)
            return fallback_response


def create_model_adapter(config: AppConfig, token_counter: TokenCounter) -> BaseModelAdapter:
    provider = config.llm_provider.lower()
    mock_adapter = MockModelAdapter(token_counter=token_counter)

    if provider == "ollama":
        primary = OllamaModelAdapter(
            token_counter=token_counter,
            endpoint=config.ollama_endpoint,
            model=config.ollama_model,
            timeout=config.llm_timeout,
        )
        return SafeModelAdapter(primary=primary, fallback=mock_adapter)

    if provider == "vllm":
        primary = VLLMModelAdapter(
            token_counter=token_counter,
            endpoint=config.vllm_endpoint,
            model=config.vllm_model,
            timeout=config.llm_timeout,
            api_key=config.openai_api_key,
        )
        return SafeModelAdapter(primary=primary, fallback=mock_adapter)

    return mock_adapter
