from __future__ import annotations

from functools import lru_cache

from .adapters.model_adapter import BaseModelAdapter, create_model_adapter, MockModelAdapter
from .config import AppConfig, load_config
from .kce.engine import KnowledgeContextEngine
from .orchestration.conversation_store import ConversationStore
from .orchestration.orchestrator import OnDemandOrchestrator
from .services.service_gateway import ServiceGateway
from .services.token_counter import TokenCounter


@lru_cache(maxsize=1)
def get_config() -> AppConfig:
    return load_config()


@lru_cache(maxsize=1)
def get_token_counter() -> TokenCounter:
    return TokenCounter()


@lru_cache(maxsize=1)
def get_conversation_store() -> ConversationStore:
    return ConversationStore()


@lru_cache(maxsize=1)
def get_knowledge_engine() -> KnowledgeContextEngine:
    config = get_config()
    return KnowledgeContextEngine(store_path=config.knowledge_store_path)


@lru_cache(maxsize=1)
def get_service_gateway() -> ServiceGateway:
    return ServiceGateway(config=get_config())


@lru_cache(maxsize=1)
def get_mock_model_adapter() -> MockModelAdapter:
    return MockModelAdapter(token_counter=get_token_counter())


@lru_cache(maxsize=1)
def get_model_adapter() -> BaseModelAdapter:
    config = get_config()
    token_counter = get_token_counter()
    return create_model_adapter(config=config, token_counter=token_counter)


@lru_cache(maxsize=1)
def get_on_demand_orchestrator() -> OnDemandOrchestrator:
    return OnDemandOrchestrator(
        config=get_config(),
        token_counter=get_token_counter(),
        store=get_conversation_store(),
        knowledge_engine=get_knowledge_engine(),
        model_adapter=get_model_adapter(),
        service_gateway=get_service_gateway(),
        fallback_adapter=get_mock_model_adapter(),
    )
