const chatThread = document.getElementById("chat-thread");
const composerInput = document.getElementById("composer-input");
const sendBtn = document.getElementById("send-btn");
const voiceBtn = document.getElementById("voice-btn");
const attachBtn = document.getElementById("attach-btn");
const imageInput = document.getElementById("image-input");
const attachmentTray = document.getElementById("attachment-tray");
const statusHint = document.getElementById("status-hint");
const newSessionBtn = document.getElementById("new-session-btn");
const sessionStats = document.getElementById("session-stats");

const state = {
  sessionId: restoreSessionId(),
  selectedImages: [],
  pendingAudio: null,
  pendingRequest: null,
  recorder: null,
  mediaStream: null,
  audioChunks: [],
  recordingStart: null,
  objectUrls: new Set(),
  totalPromptTokens: 0,
  totalCompletionTokens: 0,
};

const API_ENDPOINT = "/api/chat/messages";

function restoreSessionId() {
  const stored = window.localStorage.getItem("gptworks_session_id");
  if (stored) return stored;
  const generated = generateSessionId();
  window.localStorage.setItem("gptworks_session_id", generated);
  return generated;
}

function generateSessionId() {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }
  return `session-${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
}

function setSessionId(sessionId) {
  state.sessionId = sessionId;
  window.localStorage.setItem("gptworks_session_id", sessionId);
}

function appendMessage(role, options) {
  const { text = "", images = [], audio = null, pending = false, meta = null } = options;
  const messageEl = document.createElement("article");
  messageEl.className = `message ${role}`;
  messageEl.dataset.role = role;

  const bubble = document.createElement("div");
  bubble.className = "bubble";

  if (pending) {
    messageEl.dataset.state = "pending";
    bubble.appendChild(buildTypingIndicator());
  } else {
    bubble.innerHTML = formatText(text);
  }

  messageEl.appendChild(bubble);

  if (images.length > 0) {
    const preview = document.createElement("div");
    preview.className = "attachment-preview";
    images.forEach((src) => {
      const img = document.createElement("img");
      img.src = src;
      img.alt = "첨부 이미지 미리보기";
      preview.appendChild(img);
    });
    messageEl.appendChild(preview);
  }

  if (audio) {
    const audioWrapper = document.createElement("audio");
    audioWrapper.controls = true;
    audioWrapper.src = audio;
    messageEl.appendChild(audioWrapper);
  }

  if (meta) {
    const metaEl = document.createElement("div");
    metaEl.className = "meta";
    metaEl.innerHTML = meta;
    messageEl.appendChild(metaEl);
  }

  chatThread.appendChild(messageEl);
  chatThread.scrollTop = chatThread.scrollHeight;
  return messageEl;
}

function buildTypingIndicator() {
  const wrapper = document.createElement("span");
  wrapper.className = "typing-indicator";
  for (let i = 0; i < 3; i += 1) {
    const dot = document.createElement("span");
    dot.className = "typing-dot";
    wrapper.appendChild(dot);
  }
  return wrapper;
}

function formatText(text) {
  return escapeHtml(text).replace(/\n/g, "<br/>");
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderAttachmentTray() {
  attachmentTray.innerHTML = "";
  const hasItems = state.selectedImages.length > 0 || state.pendingAudio;
  attachmentTray.hidden = !hasItems;
  if (!hasItems) return;

  state.selectedImages.forEach((item, index) => {
    const chip = document.createElement("div");
    chip.className = "attachment-chip";
    chip.textContent = `이미지 ${index + 1}`;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "x";
    remove.addEventListener("click", () => removeImageAttachment(index));
    chip.appendChild(remove);
    attachmentTray.appendChild(chip);
  });

  if (state.pendingAudio) {
    const chip = document.createElement("div");
    chip.className = "attachment-chip";
    chip.textContent = `음성 ${state.pendingAudio.duration.toFixed(1)}초`;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "x";
    remove.addEventListener("click", removeAudioAttachment);
    chip.appendChild(remove);
    attachmentTray.appendChild(chip);
  }
}

function removeImageAttachment(index) {
  const [removed] = state.selectedImages.splice(index, 1);
  if (removed?.url) {
    URL.revokeObjectURL(removed.url);
    state.objectUrls.delete(removed.url);
  }
  renderAttachmentTray();
}

function removeAudioAttachment() {
  if (state.pendingAudio?.url) {
    URL.revokeObjectURL(state.pendingAudio.url);
    state.objectUrls.delete(state.pendingAudio.url);
  }
  state.pendingAudio = null;
  renderAttachmentTray();
}

async function sendMessage() {
  if (state.pendingRequest) return;

  const text = composerInput.value.trim();
  if (!text && state.selectedImages.length === 0 && !state.pendingAudio) {
    updateStatus("보낼 내용이 없습니다.");
    return;
  }

  disableComposer(true);

  const imageUrls = state.selectedImages.map((item) => item.url);
  const audioUrl = state.pendingAudio?.url ?? null;

  const userDisplayText =
    text ||
    (state.pendingAudio ? `음성 메시지 ${state.pendingAudio.duration.toFixed(1)}초` : "첨부 메시지");

  appendMessage("user", { text: userDisplayText, images: imageUrls, audio: audioUrl });
  const assistantPlaceholder = appendMessage("assistant", { pending: true });

  try {
    const payload = buildFormData(text);
    const response = await fetch(API_ENDPOINT, {
      method: "POST",
      body: payload,
    });
    if (!response.ok) {
      throw new Error(`서버 오류: ${response.status}`);
    }
    const data = await response.json();
    applyAssistantResult(assistantPlaceholder, data);
  } catch (error) {
    console.error(error);
    assistantPlaceholder.dataset.state = "error";
    const bubble = assistantPlaceholder.querySelector(".bubble");
    bubble.textContent = "응답을 불러오지 못했습니다. 다시 시도해 주세요.";
  } finally {
    resetComposer();
    disableComposer(false);
    state.pendingRequest = null;
  }
}

function buildFormData(text) {
  const formData = new FormData();
  formData.append("session_id", state.sessionId);
  if (text) {
    formData.append("text", text);
  }
  state.selectedImages.forEach((item) => {
    formData.append("image_files", item.file, item.file.name);
  });
  if (state.pendingAudio?.blob) {
    const audioFile = new File([state.pendingAudio.blob], "voice-input.webm", {
      type: state.pendingAudio.blob.type || "audio/webm",
    });
    formData.append("audio_file", audioFile);
  }
  return formData;
}

function applyAssistantResult(element, data) {
  element.dataset.state = "completed";

  const rawContent = data.message.content;
  decorateAssistantMessage(element, rawContent);

  const tokens = data.token_usage;
  state.totalPromptTokens += tokens.prompt_tokens;
  state.totalCompletionTokens += tokens.completion_tokens;
  updateSessionStats();

  const metaContent = `이번 응답 토큰: 프롬프트 ${tokens.prompt_tokens} / 응답 ${tokens.completion_tokens} / 총 ${tokens.total_tokens}`;

  let metaEl = element.querySelector(".meta");
  if (!metaEl) {
    metaEl = document.createElement("div");
    metaEl.className = "meta";
    element.appendChild(metaEl);
  }
  metaEl.textContent = metaContent;

  const existingPanel = element.querySelector(".context-panel");
  if (existingPanel) {
    existingPanel.remove();
  }

  if (Array.isArray(data.context_items) && data.context_items.length > 0) {
    const details = document.createElement("details");
    details.className = "context-panel";
    details.open = data.context_items.length === 1;
    const summary = document.createElement("summary");
    summary.textContent = `참고 컨텍스트 (${data.context_items.length})`;
    details.appendChild(summary);
    const list = document.createElement("ul");
    data.context_items.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = `${item.source} - ${item.content}`;
      list.appendChild(li);
    });
    details.appendChild(list);
    element.appendChild(details);
  }

  chatThread.scrollTop = chatThread.scrollHeight;
}

function decorateAssistantMessage(messageEl, rawText) {
  const bubble = messageEl.querySelector(".bubble");
  if (!bubble) return;

  const sections = parseSectionedText(rawText);
  if (sections.length === 0) {
    bubble.innerHTML = formatText(rawText);
    return;
  }

  bubble.innerHTML = "";
  sections.forEach((section) => {
    const block = renderSectionBlock(section);
    bubble.appendChild(block);
  });
}

function parseSectionedText(rawText) {
  const sections = [];
  const pattern = /\[([^\]]+)\]\s*\n([\s\S]*?)(?=\n\[[^\]]+\]\s*\n|$)/g;
  let match;
  let lastIndex = 0;
  let matchedAny = false;

  while ((match = pattern.exec(rawText)) !== null) {
    matchedAny = true;
    if (match.index > lastIndex) {
      const leading = rawText.slice(lastIndex, match.index).trim();
      if (leading) {
        sections.push({ title: "응답", body: leading });
      }
    }
    sections.push({ title: match[1].trim(), body: match[2].trim() });
    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < rawText.length) {
    const trailing = rawText.slice(lastIndex).trim();
    if (trailing) {
      sections.push({ title: matchedAny ? "응답" : "본문", body: trailing });
    }
  }

  if (!matchedAny) {
    return [];
  }

  return sections;
}

function renderSectionBlock(section) {
  const block = document.createElement("section");
  const slug = slugify(section.title);
  block.className = `section-block section-${slug || "default"}`;

  if (section.title !== "응답" && section.title !== "본문") {
    const heading = document.createElement("h4");
    heading.textContent = section.title;
    block.appendChild(heading);
  } else {
    block.classList.add("section-default");
  }

  const trimmedBody = section.body.trim();
  const lines = trimmedBody.split("\n").map((line) => line.trim()).filter(Boolean);
  const hasLines = lines.length > 0;
  const shouldRenderList =
    hasLines &&
    (section.title === "서비스 연동 결과" ||
      section.title === "시스템 경고" ||
      lines.every((line) => line.startsWith("-")));

  if (section.title === "서비스 연동 결과") {
    block.classList.add("section-service");
    const isStructuredJson = trimmedBody.startsWith("{") || trimmedBody.startsWith("[");
    if (isStructuredJson) {
      const pre = document.createElement("pre");
      pre.textContent = trimmedBody;
      block.appendChild(pre);
      return block;
    }
  }
  if (section.title === "시스템 경고") {
    block.classList.add("section-warning");
  }

  if (shouldRenderList) {
    const list = document.createElement("ul");
    lines.forEach((line) => {
      const item = document.createElement("li");
      item.textContent = line.replace(/^-+\s*/, "").trim();
      list.appendChild(item);
    });
    block.appendChild(list);
  } else {
    const paragraph = document.createElement("p");
    paragraph.innerHTML = formatText(section.body);
    block.appendChild(paragraph);
  }

  return block;
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function disableComposer(disabled) {
  sendBtn.disabled = disabled;
  voiceBtn.disabled = disabled && !state.recorder;
  composerInput.disabled = disabled;
  state.pendingRequest = disabled ? true : null;
}

function resetComposer() {
  composerInput.value = "";
  composerInput.style.height = "auto";
  while (state.selectedImages.length > 0) {
    removeImageAttachment(0);
  }
  const hadAudio = Boolean(state.pendingAudio);
  if (hadAudio) {
    removeAudioAttachment();
  }
  imageInput.value = "";
  if (!hadAudio) {
    renderAttachmentTray();
  }
}

function updateStatus(message) {
  statusHint.textContent = message;
}

function updateSessionStats() {
  if (!sessionStats) return;
  const total = state.totalPromptTokens + state.totalCompletionTokens;
  sessionStats.textContent = `프롬프트 ${state.totalPromptTokens} / 응답 ${state.totalCompletionTokens} / 총 ${total}`;
}

composerInput.addEventListener("input", () => {
  composerInput.style.height = "auto";
  composerInput.style.height = `${composerInput.scrollHeight}px`;
});

composerInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});

sendBtn.addEventListener("click", () => {
  sendMessage();
});

attachBtn.addEventListener("click", () => {
  imageInput.click();
});

imageInput.addEventListener("change", (event) => {
  const files = Array.from(event.target.files || []);
  files.forEach((file) => {
    const url = URL.createObjectURL(file);
    state.selectedImages.push({ file, url });
    state.objectUrls.add(url);
  });
  renderAttachmentTray();
});

voiceBtn.addEventListener("click", async () => {
  if (state.recorder) {
    await stopRecording();
  } else {
    await startRecording();
  }
});

newSessionBtn.addEventListener("click", () => {
  setSessionId(generateSessionId());
  revokeAllObjectUrls();
  chatThread.innerHTML = "";
  state.totalPromptTokens = 0;
  state.totalCompletionTokens = 0;
  updateSessionStats();
  updateStatus("새 대화를 시작했어요.");
});

async function startRecording() {
  if (!navigator.mediaDevices?.getUserMedia) {
    updateStatus("이 브라우저는 음성 입력을 지원하지 않습니다.");
    return;
  }
  try {
    state.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.recorder = new MediaRecorder(state.mediaStream);
    state.audioChunks = [];
    state.recordingStart = Date.now();

    state.recorder.addEventListener("dataavailable", (event) => {
      if (event.data.size > 0) {
        state.audioChunks.push(event.data);
      }
    });

    state.recorder.addEventListener("stop", async () => {
      voiceBtn.classList.remove("recording");
      if (state.mediaStream) {
        state.mediaStream.getTracks().forEach((track) => track.stop());
      }

      const blob = new Blob(state.audioChunks, { type: "audio/webm" });
      const duration = (Date.now() - state.recordingStart) / 1000;
      const url = URL.createObjectURL(blob);
      state.pendingAudio = { blob, url, duration };
      state.objectUrls.add(url);
      renderAttachmentTray();
      updateStatus(`음성 ${duration.toFixed(1)}초가 추가되었습니다.`);
      await sendMessage();
      state.recorder = null;
      state.mediaStream = null;
      state.audioChunks = [];
      state.recordingStart = null;
    });

    state.recorder.start();
    voiceBtn.classList.add("recording");
    updateStatus("녹음 중... 다시 누르면 전송합니다.");
  } catch (error) {
    console.error(error);
    updateStatus("마이크 권한을 확인해 주세요.");
  }
}

async function stopRecording() {
  if (state.recorder && state.recorder.state !== "inactive") {
    state.recorder.stop();
  }
}

window.addEventListener("beforeunload", () => {
  revokeAllObjectUrls();
});

updateSessionStats();

// Greet the user
appendMessage("assistant", {
  text: "안녕하세요! IoT 기기의 설치, 온보딩, 트러블슈팅을 도와드릴 GPTWorks 에이전트입니다. 궁금하신 내용을 말씀해 주세요.",
});

function revokeAllObjectUrls() {
  state.objectUrls.forEach((url) => URL.revokeObjectURL(url));
  state.objectUrls.clear();
  state.selectedImages = [];
  state.pendingAudio = null;
  renderAttachmentTray();
}
