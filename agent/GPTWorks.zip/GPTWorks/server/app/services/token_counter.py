from __future__ import annotations

import math
import re
from typing import Iterable

from ..orchestration.types import ConversationMessage

_TOKEN_PATTERN = re.compile(r"\w+|[^\w\s]", re.UNICODE)


class TokenCounter:
    """Light-weight heuristic token estimator."""

    def count_text(self, text: str | None) -> int:
        if not text:
            return 0
        return len(_TOKEN_PATTERN.findall(text))

    def count_messages(self, messages: Iterable[ConversationMessage]) -> int:
        return sum(self.count_text(message.content) for message in messages)

    def safe_margin(self, budget: int, safety_ratio: float = 0.9) -> int:
        return math.floor(budget * safety_ratio)
