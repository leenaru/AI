from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import httpx

from ..config import AppConfig


@dataclass(slots=True)
class ServiceExecutionResult:
    action: str
    success: bool
    payload: Dict[str, Any]
    explanation: Optional[str] = None


@dataclass(slots=True)
class ServiceRoute:
    action: str
    method: str
    path: str
    description: Optional[str] = None
    requires_auth: bool = False


class ServiceGateway:
    """HTTP-based gateway that proxies safe service calls with graceful fallback."""

    def __init__(self, config: AppConfig) -> None:
        self._base_url = (config.service_gateway_base_url or "").rstrip("/") or None
        self._timeout = config.service_gateway_timeout
        self._api_key = config.service_gateway_api_key
        self._routes: Dict[str, ServiceRoute] = {}
        self._register_defaults()

    def register_route(self, route: ServiceRoute) -> None:
        self._routes[route.action] = route

    def execute_action(self, action: str, **payload: Any) -> ServiceExecutionResult:
        route = self._routes.get(action)

        if not self._base_url or not route:
            return ServiceExecutionResult(
                action=action,
                success=True,
                payload={"mode": "mock", "request": payload},
                explanation="ServiceGateway is running in mock mode.",
            )

        url = f"{self._base_url}/{route.path.lstrip('/')}"
        headers = {"Content-Type": "application/json"}
        if route.requires_auth and self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            with httpx.Client(timeout=self._timeout) as client:
                response = client.request(route.method.upper(), url, json=payload, headers=headers)
                response.raise_for_status()
                data = response.json() if response.content else {}
        except httpx.HTTPError as error:
            return ServiceExecutionResult(
                action=action,
                success=False,
                payload={},
                explanation=f"Service call failed: {error}",
            )

        return ServiceExecutionResult(
            action=action,
            success=True,
            payload=data,
            explanation=route.description,
        )

    def _register_defaults(self) -> None:
        self.register_route(
            ServiceRoute(
                action="device_onboarding_checklist",
                method="POST",
                path="/onboarding/checklist",
                description="Fetches the latest onboarding checklist for the device family.",
                requires_auth=True,
            )
        )
        self.register_route(
            ServiceRoute(
                action="error_code_lookup",
                method="POST",
                path="/troubleshooting/error-codes/resolve",
                description="Resolves a device error code into remediation steps.",
                requires_auth=True,
            )
        )
        self.register_route(
            ServiceRoute(
                action="voc_intake",
                method="POST",
                path="/voc",
                description="Creates a VOC ticket with captured customer details.",
                requires_auth=True,
            )
        )
