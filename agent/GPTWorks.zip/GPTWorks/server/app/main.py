from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import load_config
from .api.routes import router as api_router
from .api.admin import router as admin_router


def create_app() -> FastAPI:
    """Application factory responsible for wiring middleware and routes."""

    config = load_config()
    app = FastAPI(title=config.app_name, debug=config.debug)

    if config.enable_cors:
        allow_origins = config.allowed_origins or ["*"]
        if "*" in allow_origins:
            allow_origins = ["*"]
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allow_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    app.include_router(api_router, prefix=config.api_prefix)
    app.include_router(admin_router, prefix=config.api_prefix)

    static_dir: Path = config.static_dir
    if static_dir.exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

    return app


app = create_app()
