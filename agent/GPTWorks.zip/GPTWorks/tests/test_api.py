from __future__ import annotations

import os
from pathlib import Path

from fastapi.testclient import TestClient

PROJECT_ROOT = Path(__file__).resolve().parent.parent
knowledge_path = PROJECT_ROOT / "data/knowledge/nodes.json"
os.environ.setdefault("KNOWLEDGE_STORE_PATH", str(knowledge_path))

from server.app.main import app  # noqa: E402  (import after env setup)

client = TestClient(app)


def test_health_endpoint() -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_chat_requires_content() -> None:
    response = client.post("/api/chat/messages", data={"session_id": "test"})
    assert response.status_code == 400


def test_chat_with_text_triggers_service_gateway() -> None:
    response = client.post(
        "/api/chat/messages",
        data={
            "session_id": "test-session",
            "text": "기기 설치 온보딩을 도와줘",
        },
    )
    assert response.status_code == 200
    data = response.json()

    message = data["message"]["content"]
    assert "[서비스 연동 결과]" in message
    assert data["token_usage"]["total_tokens"] >= 0
    assert isinstance(data["context_items"], list)


def test_admin_status_reports_configuration() -> None:
    response = client.get("/api/admin/status")
    assert response.status_code == 200
    payload = response.json()
    assert payload["knowledge"]["node_count"] >= 1
    assert payload["llm"]["provider"]


def test_admin_reload_knowledge() -> None:
    response = client.post("/api/admin/knowledge/reload")
    assert response.status_code == 204
