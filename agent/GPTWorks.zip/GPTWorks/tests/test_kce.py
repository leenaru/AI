from __future__ import annotations

from pathlib import Path

from server.app.kce.engine import KnowledgeContextEngine

PROJECT_ROOT = Path(__file__).resolve().parent.parent
KNOWLEDGE_PATH = PROJECT_ROOT / "data/knowledge/nodes.json"


def test_knowledge_engine_returns_ranked_items() -> None:
    engine = KnowledgeContextEngine(store_path=KNOWLEDGE_PATH)
    results = engine.retrieve("Wi-Fi error code blinking led")
    assert results
    top_sources = {item.source for item in results}
    assert "troubleshooting/error-codes.md" in top_sources
